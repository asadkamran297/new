<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Answer extends Model
{
 use SoftDeletes;

	/**
  * The table associated with the model.
  *
  * @var string
  */
  protected $table = "answers";


  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
   protected $fillable = [
	"content", "question_id", "is_true",
   ];


	public function questions()
	{
		return $this->belongsTo('App\Question','question_id','id');
	}

	public function attempts()
	{
		return $this->hasOne('App\Attempt','answer_id','id');
	}
}
