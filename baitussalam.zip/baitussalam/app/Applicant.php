<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Applicant extends Model
{
  use SoftDeletes;

	/**
  * The table associated with the model.
  *
  * @var string
  */
  protected $table = "applicants";


  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
   protected $fillable = [
	"user_id", "class_id", "class_selection", "name", "father_name", "dob", "city", "phone", "address", "permanent_address", "cnic", "islamic_education", "previous_institute_name", "previous_institute_left_reason", "basic_education", "is_submitted","is_allowed",
   ];


	   public function gaurdians()
    {
        return $this->hasOne('App\Guardian','applicant_id','id');
    }

        public function classes()
	{
		return $this->belongsTo('App\ClassModel','class_id');
	}

	    public function applicant_answers()
	{
		return $this->hasMany('App\ApplicantAnswer','applicant_id','id');
	}


    public function user()
	{
		return $this->belongsTo('App\User');
	}
}