<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ApplicantAnswer extends Model
{
	use SoftDeletes;

	/**
  * The table associated with the model.
  *
  * @var string
  */
  protected $table = "applicant_answers";


  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
   protected $fillable = [
	"applicant_id", "applicant_answer",
   ];

     public function applicants()
    {
        return $this->belongsTo('App\Applicant','applicant_id','id');
    }
}
