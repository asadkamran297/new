<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\EntryTest;


class Attempt extends Model
{
	use SoftDeletes;

	/**
  * The table associated with the model.
  *
  * @var string
  */
  protected $table = "attempts";


  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
   protected $fillable = [
	"entry_test_id", "question_id","answer_id","is_true",
   ];

    public function entry_test()
	{
		return $this->belongsTo(EntryTest::class);
	}

	public function question()
	{
		return $this->belongsTo('App\Question');
	}

	public function answer()
	{
		return $this->belongsTo('App\Answer');
	}
}
