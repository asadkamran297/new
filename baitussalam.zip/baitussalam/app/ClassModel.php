<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class ClassModel extends Model
{
  use SoftDeletes;
    /**
      * The table associated with the model.
      *
      * @var string
    */
    protected $table = "classes";

    /**
      * The attributes that are mass assignable.
      *
      * @var array
    */
    protected $fillable = [
      "class_name", "minimum_age_limit","maximum_age_limit","quiz_time","is_active","random_question","question_limit"
    ];

    public function subjects()
    {
      return $this->hasMany('App\Subject','class_id');
    }    

    public function applicants()
    {
      return $this->hasMany('App\Applicant','class_id');
    }

    public function entry_tests()
    {
      return $this->hasMany('App\EntryTest', 'class_id');
    }

    public function actiteSubjects()
    {
      return $this->hasMany('App\Subject','class_id')->where('is_active',1);
    }

    public function quiz_questions()
    {
      return $this->hasMany(ClassQuizQuestions::class,'class_id');
    } 

  }
