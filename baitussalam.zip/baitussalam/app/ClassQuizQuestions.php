<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClassQuizQuestions extends Model
{
    /**
    * The table associated with the model.
    *
    * @var string
    */
    protected $table = "class_quiz_questions";

    /**
    * The attributes that are mass assignable.
    *
    * @var array
    */
    protected $fillable = [
        "class_id", "question_id"
    ];

    /**
    * Time stamp attribute
    *
    * @var string
    */
    public $timestamps = false;
}
