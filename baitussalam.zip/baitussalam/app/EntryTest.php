<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EntryTest extends Model
{

    use SoftDeletes;

    /**
    * The table associated with the model.
    *
    * @var string
    */
    protected $table = "entry_tests";


    /**
    * The attributes that are mass assignable.
    *
    * @var array
    */
    protected $fillable = [
        "class_id", "user_id","is_quiz_start","quiz_end","is_auto_end","quiz_end_date","quiz_start_time","current_day"
    ];

    public function attempts()
    {
        return $this->hasMany(Attempt::class);
    }

    public function users(){
        return $this->belongsTo('App\User','user_id');
    }
}
