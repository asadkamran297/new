<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Guardian extends Model
{
 use SoftDeletes;

    /**
  * The table associated with the model.
  *
  * @var string
  */
  protected $table = "guardians";


  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
   protected $fillable = [
    "applicant_id", "guardian_name","guardian_f_name","city","applicant_relation","occupation","position","phone","father_cnic","address","another_guardian_name",
   ];

    public function applicants()
	{
		return $this->belongsTo('App\Applicant','applicant_id','id');
	}

}
             	