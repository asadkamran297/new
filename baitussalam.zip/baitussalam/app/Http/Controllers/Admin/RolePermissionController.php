<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\{
    Role,
    Permission,
    RolePermission
};

class RolePermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Gate::allows('userroleIndex','39')) {
        $data['roles'] = Role::orderBy('id','asc')->get(['id','title','is_active','created_at']);
        $data['permissions'] = Permission::orderBy('id','desc')->get(['id','title','is_active','created_at']);
        return view('admin.role_permissions.index',$data);
    }else {
        return redirect()->back()->with('error_msg','Not authorised');
    }

}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (Gate::allows('userroleUpdate','40')) {
        $rp = RolePermission::where('role_id',$request->role_id)->get();
        if(count($rp)<=0){
            foreach ($request->permissions as $key => $permission) {
                $role_permission = new RolePermission;
                $role_permission->role_id = $request->role_id;
                $role_permission->permission_id = $permission;
                $role_permission->save();
            }
        }
        if(count($rp)>0){
            foreach ($rp as $key => $r_perm) {
                $r_perm->delete();
            }
            foreach ($request->permissions as $key => $permission) {
                $role_permission = new RolePermission;
                $role_permission->role_id = $request->role_id;
                $role_permission->permission_id = $permission;
                $role_permission->save();
            }
        }
        return redirect()->back()->with('success','Permissions updated successfully');


    }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }  
      
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
