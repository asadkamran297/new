<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Auth;
use App\{
    User,
    Role
};

class UserController extends Controller
{
    public function __construct()
    {
        // dd('inside constant');
    }

    protected $per_page = 15;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Gate::allows('userIndex','30')) {
         $data['users'] = User::orderBy('id','desc')->paginate($this->per_page,['id','name','email','role_id','is_active','created_at']);
         $data['roles'] = Role::orderBy('id','desc')->get();
         return view('admin.users.index',$data); 
     }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        dd('inside edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateStatus(Request $request)
    {
        if (Gate::allows('userStatusUpdate','31')) {
            try{
                $is_active = isset($request->status) && $request->status=='true' ? 1 : 0;
                User::where('id',$request->user_id)->update(['is_active'=>$is_active]);
                return true;
            }catch(Exception $ex){
                return false;
                return redirect()->back()->with('error',$ex->getMessage());
            }
        }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateRole(Request $request)
    {
        if (Gate::allows('userRoleUpdate','32')) {
        try{
            $admin_count = User::where('role_id',1)->get();
            if(count($admin_count)>=3 && $request->role_id==1){
                return response()->json(['status'=>0,'message'=>'Only 3 admins are allowed at a time']);
            }
            User::where('id',$request->user_id)->update(['role_id'=>$request->role_id]);
            return response()->json(['status'=>1,'message'=>'Successfully updated']);
        }catch(Exception $ex){
            return response()->json(['status'=>0,'message'=>'Error while updating role']);
        }

    }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }

    }
}
