<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Gate;
use Auth;
use Exception;
use App\{
	Applicant,
	ApplicantAnswer,
	Guardian,
	ClassModel,
	Http\Requests\AdmissionFormRequest
};

class AdmissionController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth');
	}

	public function index()
	{
		if (Gate::allows('applicantIndex','21')) {
			try{
				if(!auth()->check()){
					throw new Exception("Admin not loggin.", 1);
				}
				$data['applicants'] = Applicant::get();

				return view('admin.admission.applicant-listing',$data);
			}catch (Exception $e) {
				return redirect()->back()->with('error_msg', $e->getMessage());
			}
		}
		else {
			return redirect()->back()->with('error_msg','Not authorised');
		}
	}

	public function applicant_allowed_quiz(Request $req)
	{
		if (Gate::allows('applicantAdd','26')) {
			$status = isset($req->status) && $req->status=='true' ? 1 : 0;
			Applicant::where('id', $req->applicant_id)->update(['is_allowed'=>$status]);
		}else {
			return redirect()->back()->with('error_msg','Not authorised');
		}
	}

	public function admission_form()
	{
		if (Gate::allows('applicantAdd','22')) {
			try{
			if(!auth()->check()){
				throw new Exception("You must be login first.");
			}

			if(isset(auth()->user()->role_id) && auth()->user()->role_id == 2 && isset(auth()->user()->applicants->id)){
				return redirect()->route('admission_form',['id'=>Auth::user()->applicants->id]);
			}

			if(isset(auth()->user()->role_id) && auth()->user()->role_id == 1){
				return redirect()->route('applicants');
			}

			if(isset(auth()->user()->role_id) && auth()->user()->role_id == 3){
				return redirect()->route('class');
			}
			$data['classes'] = ClassModel::get();
			return view('admin.admission.form',$data);
		}catch (Exception $e) {
			return redirect()->back()->with('error_msg', $e->getMessage());
		}
		}
		else {
			return redirect()->back()->with('error_msg','Not authorised');
		}
	}


	public function admission_submit_form(Request $req)
	{   
		if (Gate::allows('applicantStore','24')) {
			try{

				$rules = [
					"class_selection" => "required",
					"name" => "required",
					"f_name" =>"required",
					"dob" =>"required",
					"class_id" =>"required",
					"city" =>"required",
					"mobile_no" =>"required",
					"present_address" =>"required",
					"permanent_address" =>"required",
					"islamic_education" =>"required",
					"previous_institute" =>"required",
					"basic_education" =>"required",
					"father_name" =>"required",
					"applicant_relation" =>"required",
					"occupation" =>"required",
					"contact_no" =>"required",
					"guardian_cnic" =>"required",
					"another_guardian_name" =>"required",
				];

				$message =[
					"class_selection.required"=>"Select Anyone",
					"name.required" => "Please add your name",
					"f_name.required" => "Please add father name",
					"dob.required" => "Please add Date of Birth",
					"class_id.required" => "Please select a class",
					"city.required" => "Please add City Name",
					"mobile_no.required" => "Please add Mobile Number",
					"present_address.required" => "Please add present address",
					"permanent_address.required" => "Please add permament address",
					"islamic_education.required" => "Please add Islamic Education",
					"previous_institute.required" => "Please add Institute Name",
					"basic_education.required" => "Please add Basic Education",
					"father_name.required" => "Please add your father name",
					"applicant_relation.required" => "Please add reation with Applicant",
					"occupation.required" => "Please add Profession",
					"contact_no.required" => "Please add father's number",
					"guardian_cnic.required" => "Please add Guardian Cnic",
					"another_guardian_name.required" => "Please add Another Guardian Name",

				];

				$validator = Validator::make($req->all(),$rules,$message);

				if ($validator->fails()) {
					return \Redirect::back()->withInput()->withErrors($validator);
					// return \Redirect::back()->withInput($req->all())->withErrors($validator);
				}  

				if($req->has('class_selection') && $req->class_selection)
				{
					$class = implode(',',$req->class_selection);
				}
				$applicant = new Applicant;
				$applicant->user_id = auth()->user()->id;
				$applicant->name = isset($req->name)?$req->name:'';
				$applicant->father_name = isset($req->f_name)?$req->f_name:'';
				$applicant->class_selection = isset($class)?$class:'';
				$applicant->dob = isset($req->dob)?$req->dob:'';
				$applicant->islamic_education = isset($req->islamic_education)?$req->islamic_education:'';
				$applicant->city = isset($req->city)?$req->city:'';
				$applicant->class_id =  isset($req->class_id)?$req->class_id:'';
				$applicant->phone = isset($req->mobile_no)?$req->mobile_no:'';
				$applicant->address = isset($req->present_address)?$req->present_address:'';
				$applicant->permanent_address = isset($req->permanent_address)?$req->permanent_address:'';
				$applicant->cnic = isset($req->student_cnic)?$req->student_cnic:'';
				$applicant->previous_institute_name = isset($req->previous_institute)?$req->previous_institute:'';
				$applicant->previous_institute_left_reason = isset($req->previous_institute_left_reason)?$req->previous_institute_left_reason:'';
				$applicant->basic_education = isset($req->basic_education)?$req->basic_education:'';
     // $applicant->save();
				if($applicant->save()){
					$guardian = new Guardian;
					$guardian->guardian_name = isset($req->name)?$req->name:'';
					$guardian->guardian_f_name	 = isset($req->father_name)?$req->father_name:'';
					$guardian->city = isset($req->city)?$req->city:'';
					$guardian->applicant_relation = isset($req->applicant_relation)?$req->applicant_relation:'';
					$guardian->occupation = isset($req->occupation)?$req->occupation:'';
					$guardian->position = isset($req->position)?$req->position:'';
					$guardian->phone = isset($req->contact_no)?$req->contact_no:'';
					$guardian->father_cnic = isset($req->guardian_cnic)?$req->guardian_cnic:'';
					$guardian->address = isset($req->p_address)?$req->p_address:'';
					$guardian->another_guardian_name = isset($req->another_guardian_name)?$req->another_guardian_name:'';
					$guardian->mobile_no = isset($req->mobile_no)?$req->mobile_no:'';
					$guardian->applicant_id = isset($applicant->id)?$applicant->id:'';
					$guardian->save();
				}
				if(isset($req->question_ans)){
					foreach($req->question_ans as $ans){
						$app_answer = new ApplicantAnswer;
						$app_answer->applicant_id = $applicant->id ?? "";
						$app_answer->applicant_answer = isset($ans) ? $ans : "NoAns";
						$app_answer->save(); 
					}

				}
				return redirect()->back()->with('success', 'Submit Form Successfully ');
			}catch(Exception $ex) {
				return redirect()->back()->with('error_msg', $ex->getMessage());
			}
		}else {
			return redirect()->back()->with('error_msg','Not authorised');
		}
		

	}

	function edit_admission_form($applicant_id)
	{
		if (Gate::allows('applicantEdit','23')) {
			try{
				if(!auth()->check()){
					throw new Exception("Admin not loggin.");
				}

				$applicants = Applicant::all();  
				$cm = ClassModel::all();
				$app = Applicant::with('gaurdians','applicant_answers','classes')->find($applicant_id);
				if(isset($app)){
					$edt =['app'=>$app,'applicant_id'=>$app->id,'applicants'=>$applicants,'classes'=>$cm];
					return view('admin.admission.edit-admission-form',$edt);
				}
				else{
					return abort(404);
				}
			}catch(Exception $ex) {
				return redirect()->back()->with('error_msg', $ex->getMessage());
			}
		}else {
			return redirect()->back()->with('error_msg','Not authorised');
		}
		
	}

	function edit_admission_form_applicant($applicant_id)
	{
		try{
			if(!auth()->check()){
				throw new Exception("User not loggin.");
			}


			$applicants = Applicant::all();  
			$cm = ClassModel::all();
			$app = Applicant::with('gaurdians','applicant_answers','classes')->find($applicant_id);
			if(isset($app)){
				$edt =['app'=>$app,'applicant_id'=>$app->id,'applicants'=>$applicants,'classes'=>$cm];
				return view('admin.admission.edit-admission-form-applicant',$edt);
			}
			else{
				return abort(404);
			}
		}catch(Exception $ex) {
			return redirect()->back()->with('error_msg', $ex->getMessage());
		}
	}

	public function update_admission_form(Request $req)
	{
		if (Gate::allows('applicantUpdate','25')) {
			try{

				$rules = [
					"class_selection" => "required",
					"n_name" => "required",
					"f_name" =>"required",
					"dob" =>"required",
					"class_id" =>"required",
					"city" =>"required",
					"mobile_no" =>"required",
					"present_address" =>"required",
					"permanent_address" =>"required",
					"islamic_education" =>"required",
					"previous_institute" =>"required",
					"basic_education" =>"required",
					"f_name" =>"required",
					"applicant_relation" =>"required",
					"occupation" =>"required",
					"contact_no" =>"required",
					"guardian_cnic" =>"required",
					"another_guardian_name" =>"required",
				];

				$message =[
					"class_selection.required"=>"Select Anyone",
					"name.required" => "Please add your name",
					"f_name.required" => "Please add father name",
					"dob.required" => "Please add Date of Birth",
					"class_id.required" => "Please select a class",
					"city.required" => "Please add City Name",
					"mobile_no.required" => "Please add Mobile Number",
					"present_address.required" => "Please add present address",
					"permanent_address.required" => "Please add permament address",
					"islamic_education.required" => "Please add Islamic Education",
					"previous_institute.required" => "Please add Institute Name",
					"basic_education.required" => "Please add Basic Education",
					"father_name.required" => "Please add your father name",
					"applicant_relation.required" => "Please add reation with Applicant",
					"occupation.required" => "Please add Profession",
					"contact_no.required" => "Please add father's number",
					"guardian_cnic.required" => "Please add Guardian Cnic",
					"another_guardian_name.required" => "Please add Another Guardian Name",

				];

				$validator = Validator::make($req->all(),$rules,$message);

				if($validator->fails()) {
					return \Redirect::back()->withErrors($validator);
				}

				if($req->has('class_selection') && $req->class_selection)
				{
					$class = implode(',',$req->class_selection);
				}
				$applicant = Applicant::find($req->applicant_id);
				$applicant->user_id = $applicant->user_id;
				$applicant->name = isset($req->n_name) ? $req->n_name : '';
				$applicant->father_name = isset($req->f_name)?$req->f_name:'';
				$applicant->class_selection = isset($class)?$class:'';
				$applicant->dob = isset($req->dob)?$req->dob:'';
				$applicant->islamic_education = isset($req->islamic_education)?$req->islamic_education:'';
				$applicant->city = isset($req->city)?$req->city:'';
				$applicant->class_id =  isset($req->class_id)?$req->class_id:'';
				$applicant->phone = isset($req->mobile_no)?$req->mobile_no:'';
				$applicant->address = isset($req->present_address)?$req->present_address:'';
				$applicant->permanent_address = isset($req->permanent_address)?$req->permanent_address:'';
				$applicant->cnic = isset($req->student_cnic)?$req->student_cnic:'';
				$applicant->previous_institute_name = isset($req->previous_institute)?$req->previous_institute:'';
				$applicant->previous_institute_left_reason = isset($req->previous_institute_left_reason)?$req->previous_institute_left_reason:'';
				$applicant->basic_education = isset($req->basic_education)?$req->basic_education:'';
				if($applicant->save()){
					$guardian = Guardian::where('applicant_id',$req->applicant_id)->first();
					$guardian->guardian_name = isset($req->u_f_name)?$req->u_f_name:'';
					$guardian->guardian_f_name	 = isset($req->u_father_name)?$req->u_father_name:'';
					$guardian->city = isset($req->u_city)?$req->u_city:'';
					$guardian->applicant_relation = isset($req->applicant_relation)?$req->applicant_relation:'';
					$guardian->occupation = isset($req->occupation)?$req->occupation:'';
					$guardian->position = isset($req->position)?$req->position:'';
					$guardian->phone = isset($req->contact_no)?$req->contact_no:'';
					$guardian->father_cnic = isset($req->guardian_cnic)?$req->guardian_cnic:'';
					$guardian->address = isset($req->p_address)?$req->p_address:'';
					$guardian->another_guardian_name = isset($req->another_guardian_name)?$req->another_guardian_name:'';
					$guardian->mobile_no = isset($req->mobile_no)?$req->mobile_no:'';
					$guardian->applicant_id = isset($applicant->id)?$applicant->id:'';
					$guardian->save();
				}

				$app_answer =ApplicantAnswer::where('applicant_id',$req->applicant_id)->get();
				foreach($app_answer as $key => $ans){
					$ans->applicant_id = $req->applicant_id;
					$ans->applicant_answer = $req->question_ans[$key];
					$ans->save();
				}

				return redirect()->back()->with('success', 'Update Form Successfully ');

			}catch(Exception $ex) {
				return redirect()->back()->with('error_msg', $ex->getMessage());
			}
		}else {
			return redirect()->back()->with('error_msg','Not authorised');
		}
		}

	

	public function result()
	{
		return view('results');
	}

	public function detailed_result()
	{
		return view('detail-result');
	}

	public function correct_question()
	{
		return view('correct-question');
	}


}
