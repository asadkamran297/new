<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Applicant;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
       protected $redirectTo = RouteServiceProvider::HOME;
   

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Handle an authentication attempt.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return Response
    */
    public function login(Request $request)
    {
        if(Auth::attempt(['email'=>$request->email,'password'=>$request->password,'is_active'=>0],$request->remember)){
            Auth::logout();
            return redirect()->back()->with('error_msg','Your account was disabled by admin contact with admin for further details');
        }
        if(Auth::attempt(['email'=>$request->email,'password'=>$request->password,'is_active'=>1],$request->remember)){
            return redirect('AdmissionForm')->with('success','Welcome to Baitussalam');
        }
        else{
            return redirect()->back()->with('error_msg','Wrong Credentials');
        }
    }
}
