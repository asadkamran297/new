<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Gate;
use App\{
    ClassModel,
    Permission,
    ClassQuizQuestions
};

class ClassController extends Controller
{   
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        if (Gate::allows('classIndex','1')) {
            $data['consumerdata'] =  ClassModel::get();
            return view('admin.class.classes',$data);
        } 
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function create()
    {
        if (Gate::allows('classCreate','2')) {
            return view('admin.class.add-class');
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }
    public function edits($id)
    {
        if (Gate::allows('classEdit','3')) {
            $class =  ClassModel::with('subjects','subjects.questions','quiz_questions')->where('id','=',$id)->first();
            if(isset($class)){
                return view('admin.class.update-class',compact('class'));
            }else{
                return abort(404);
            }
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function store(Request $req)
    {
        if (Gate::allows('classSave','4')) {
            try{
                $rules = [
                    "class_name" => "required|unique:classes",
                    "question_limit" => "required"
                ];

                $validator = Validator::make($req->all(), $rules);

                if ($validator->fails()) {
                    return \Redirect::back()->withErrors($validator);
                }  

                $class = new ClassModel;
                $class->class_name = isset($req->class_name)?$req->class_name:'';
                $class->minimum_age_limit = isset($req->minimum_age_limit)?$req->minimum_age_limit:'';
                $class->maximum_age_limit = isset($req->maximum_age_limit)?$req->maximum_age_limit:'';
                $class->quiz_time = isset($req->quiz_time) ? $req->quiz_time : "01:00";
                $class->random_question = isset($req->random_question) ? 1 : 0;
                $class->question_limit = isset($req->question_limit) ? $req->question_limit : 20;
                $class->save();

                return redirect('admin/class')->with('success', 'Add Class Successfully ');
            }catch(Exception $ex) {
                return redirect()->back()->with('error_msg', $ex->getMessage());
            } 
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        } 
    }


    public function update(Request $request,$id)
    {
        if (Gate::allows('classUpdate','5')) {
            try{
                $data = [
                    'class_name'=>$request->class_name,
                    'minimum_age_limit'=>$request->minimum_age_limit,
                    'maximum_age_limit'=>$request->maximum_age_limit,
                    'quiz_time' => isset($request->quiz_time) ? $request->quiz_time : "01:00",
                    'question_limit' => isset($request->question_limit) ? $request->question_limit : 20,
                    'random_question' => isset($request->random_question) ? 1 : 0,
                ];
                ClassModel::where('id','=',$id)->update($data);

                if(isset($request->quiz_questions) && count($request->quiz_questions)){
                    $old_quiz_quest = ClassQuizQuestions::where('class_id',$id)->get();
                    if(isset($old_quiz_quest) && count($old_quiz_quest)){
                        foreach ($old_quiz_quest as $key => $old_ques) {
                            $old_ques->delete();
                        }
                    }
                    foreach ($request->quiz_questions as $key => $question) {
                        ClassQuizQuestions::create(['class_id'=>$id,'question_id'=>$question]);
                    }
                }
                return redirect('admin/class')->with('success', 'Update Class Successfully ');
            }catch(Exception $ex) {
                return redirect()->back()->with('error_msg', $ex->getMessage());
            }
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }


    public function destroy($id)
    {
        if (Gate::allows('classDelete','6')) {
            ClassModel::where('id','=',$id)->delete();
            return redirect('admin/class');
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function updateStatus(Request $request)
    {
        // if (Gate::allows('subjectStatusUpdate','13')) {
        $status = isset($request->status) && $request->status=='true' ? 1 : 0;
        ClassModel::where('id', $request->class_id)->update(['is_active'=>$status]);
        return response()->json(['status'=>1,'message'=>'Updated Successfully']);
        // }
        // else {
            // return response()->json(['status'=>0,'message'=>'Not authorised']);
        // }
    }

    public function showResult($id=null)
    {
        $user = auth()->user();

        if(empty($user) &&  $user->entryTest==NULL || $user->entryTest==NULL ){
            return redirect()->back()->with('error_msg','No record found');
        }

        try {
            $entry_test_id = $user->entryTest->id;
            if(empty($entry_test_id) || empty($user->id)){
                throw new Exception("Entry Test id is mandatory.", 1);
            }
            $test = \App\EntryTest::where(['id'=>$entry_test_id, 'user_id'=>$user->id])->first();
            if(is_null($test)){
                throw new Exception("Entry Test not found", 1);
            }

            $data_arr = [];
            if($test->attempts()->count() > 0){
                foreach($test->attempts()->get() as $att){
                    $dt = [];
                    $dt['question'] = isset($att->question->id) ? $att->question->question_content : '';
                    $dt['attempt_answer'] = isset($att->answer->id) ? $att->answer->content : '';
                    $dt['correct_answer'] = isset($att->question->id) && $att->question->answers()->where('is_true', 1)->count() > 0 ? $att->question->answers()->where('is_true', 1)->first()->content : '';
                    $dt['is_true'] = isset($att->is_true) ? $att->is_true : '';
                    $data_arr[] = $dt;
                }
            }
            return view('admin/results/results_detail', ['data_arr'=>$data_arr]);

        } catch (Exception $e) {
            return redirect()->back()->with('error_msg', $e->getMessage());
        }
    }

    // public function quizOptions($id)
    // {
    //     $data['class'] = ClassModel::with('actiteSubjects')->find($id);
    //     return view('admin.class.quiz_options',$data);
    // }

    // public function quizOptionsUp(Request $request)
    // {
    //     if(!isset($request->class_id) && empty($request->class_id) && $request->class_id==0){
    //         return redirect()->back()->with('error_msg','Class id is required');
    //     }
    //     $class = ClassModel::find($request->class_id);
    //     dd($class);
    //     return view('admin.class.quiz_options',$data);
    // }
}