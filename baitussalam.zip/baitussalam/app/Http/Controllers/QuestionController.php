<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\{
  Question,
  Answer,
  Subject,
  EntryTest,
  PreviousQuizAttempt
};

class QuestionController extends Controller
{

  public function __construct()
  {
    $this->middleware('auth');
  }

  public function index()
  {
    if (Gate::allows('questionIndex','14')) {
    $data['questions'] = Question::orderBy('id','desc')->get();

    return view('admin.question.question-selection',$data);
  }else {
    return redirect()->back()->with('error_msg','Not authorised');
  }
  }

  public function is_active_question(Request $req)
  {
     if (Gate::allows('questionStatusUpdate','20')) {
      $status = isset($req->status) && $req->status=='true' ? 1 : 0;
    Question::where('id', $req->question_id)->update(['is_active'=>$status]);
     }else {
    return redirect()->back()->with('error_msg','Not authorised');
  }
    

  }

  public function add_question()
  {
    if (Gate::allows('questionAdd','15')) {
     $data['subjects'] = Subject::get();

   return view('admin.question.add-question',$data);
 }else {
    return redirect()->back()->with('error_msg','Not authorised');
  }
  
 }


  public function save_question(Request $req)
  { 
    if (Gate::allows('questionStore','17')) {
    try{
      $rules = [
        "subject_id" => "required",
        "question_content" => "required",
        "content" => "required",
        "content_chckbx" => "required"
      ];  

      $message = [
        "subject_id.required" => "Subject name is required",
        "question_content.required"=> "Question is required",
        "content.required"=>"Answer is required",
        "content_chckbx.required"=>"One Selected Answer must be required"
      ];

      $validator = Validator::make($req->all(), $rules,$message);

      if ($validator->fails()) {
        return \Redirect::back()->withErrors($validator);
      }

      $ques = new Question;
      $ques->question_content = $req->question_content;
      $ques->subject_id = $req->subject_id;
      $ques->language_code = $req->lang_key;
      $ques->is_active = 1;
      $correct_answer = $req->content_chckbx;
      if($ques->save()){
        if(isset($req->content) && $req->content){
          foreach($req->content as $k => $a){
            $ans = new Answer;
            $ans->question_id =$ques->id;
            $ans->content =isset($a)?$a:'';
            $ans->is_true = isset($correct_answer[$k]) ? 1 : 0;
            $ans->save();
          }
        }
      }
      return redirect('admin/questions')->with('success','Add Question Successfully');
    }catch(Exception $ex) {
      return redirect()->back()->with('error_msg', $ex->getMessage());
    }
  }else {
    return redirect()->back()->with('error_msg','Not authorised');
  }
     
  }

  function edit_question($id)
  {
    if (Gate::allows('questionEdit','23')) {
      $subjects = Subject::all();  
      $ques = Question::with('answers')->find($id);
      if(isset($ques)){
        $edt =['ques'=>$ques,'id'=>$ques->id,'subjects'=>$subjects];
        return view('admin.question.edit-question',$edt);
      }else{
        return abort(404);
      }

    }else {
      return redirect()->back()->with('error_msg','Not authorised');
    }
    
  }

  public function update_question(Request $request)
  {
    if (Gate::allows('questionUpdate','18')) {
      try{
      $rules = [
        "subject_id" => "required",
        "question_content" => "required",
        "content" => "required",
        "content_chckbx" => "required"
      ];  

      $message = [
        "subject_id.required" => "Subject name is required",
        "question_content.required"=> "Question is required",
        "content.required"=>"Answer is required",
        "content_chckbx.required"=>"One Selected Answer must be required"
      ];

      $validator = Validator::make($request->all(), $rules,$message);

      if ($validator->fails()) {
        return \Redirect::back()->withErrors($validator);
      }

      $ques = Question::find($request->id);
      $ques->question_content = isset($request->question_content)?$request->question_content:'';
      $ques->subject_id = isset($request->subject_id)?$request->subject_id:'';
      $ques->language_code =  isset($request->lang_key)?$request->lang_key:'';
      $correct_answer = $request->content_chckbx;
      if($ques->save()){
        if(isset($request->content) && $request->content){
          foreach($request->content as $k => $a){
            $ans = Answer::find($request->ans_id[$k]);
            $ans->question_id =$ques->id;
            $ans->content =isset($a)?$a:'';
            $ans->is_true = isset($correct_answer[$k]) ? 1 : 0;
            $ans->save();
          }
        }    
      }
      return redirect('admin/questions')->with('success', 'Update Question Successfully ');
    }catch(Exception $ex) {
      return redirect()->back()->with('error_msg', $ex->getMessage());
    } 
    }else {
      return redirect()->back()->with('error_msg','Not authorised');
    }
    
  }

  public function destroy($id)
  {
    if (Gate::allows('questionDestroy','19')) {
      Question::where('id','=',$id)->delete();
    return redirect('admin/questions');
    }else {
      return redirect()->back()->with('error_msg','Not authorised');
    }
    
  }

  public function quiz()
  {
    return view('quiz.quiz');
  }

  public function allowReattempt($entry_test_id)
  {
    if(empty($entry_test_id)){
      return redirect()->back()->with('error_msg','Entry test id is required');
    }
    $entry_test = EntryTest::with('attempts')->find($entry_test_id);
    if(isset($entry_test) && count($entry_test['attempts'])){
      foreach($entry_test['attempts'] as $key => $attempt){
        $prev_quiz_attempt = new PreviousQuizAttempt;
        $prev_quiz_attempt->user_id = isset($entry_test->user_id) ? $entry_test->user_id : "";
        $prev_quiz_attempt->class_id = isset($entry_test->class_id) ? $entry_test->class_id : "";
        $prev_quiz_attempt->entry_test_id = $entry_test_id;
        $prev_quiz_attempt->attempt_id = isset($attempt->id) ? $attempt->id : "";
        $prev_quiz_attempt->question_id = isset($attempt->question_id) ? $attempt->question_id : "";
        $prev_quiz_attempt->answer_id = isset($attempt->answer_id) ? $attempt->answer_id : "";
        $prev_quiz_attempt->is_true = isset($attempt->is_true) ? $attempt->is_true : 0;
        $prev_quiz_attempt->save();
      }
      foreach($entry_test['attempts'] as $key => $attempt){
        $attempt->delete();
      }
      $entry_test->delete();
      return redirect()->route('results')->with('success','Allowed re attempt quiz');
    }
    else{
      return redirect()->back()->with('error_msg','No data found');
    }
  }
}
