<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\{
    EntryTest,
    Applicant,
    ClassModel,
    PreviousQuizAttempt
};
use Exception;

class QuizController extends Controller
{
    public function quiz(){
        if (Gate::allows('quizIndex','42')) {
            try {
                if(!auth()->check()){
                    throw new Exception("User not loggin.", 1);
                }
                if(is_null(auth()->user()->applicants)){
                    throw new Exception("Applicant form must be required.", 1);
                } if(!is_null(auth()->user()->applicants) && is_null(auth()->user()->applicants->classes)){
                    throw new Exception("Classes must be required.", 1);
                }
                $classes = auth()->user()->applicants->classes;
                $is_allowed = auth()->user()->applicants->is_allowed;
                return view('quiz/quiz', ['classes'=>$classes,'is_allowed' =>$is_allowed]);
            } catch (Exception $e) {
            //print_r($e->getMessage());
                return redirect()->back()->with('error_msg', $e->getMessage());
            }
        }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
        
    }

    public function add_quiz(Request $req){
        try {
            if($req->has('class')){
                if(empty($req->class)){
                    throw new Exception("Error Processing Request", 1);
                }
                $entry_test_id = 0;
                $entry_exists = EntryTest::where(['class_id'=>$req->class, 'user_id'=>auth()->user()->id])->get('id');
                if(count($entry_exists) == 0){
                    $entry_test_id = EntryTest::insertGetId(['class_id'=>$req->class, 'is_quiz_start'=>1,'quiz_start_time'=>date('h:i'), 'user_id'=>auth()->user()->id, 'created_at'=>date('Y-m-d h:i:s'),'current_day'=>date('d')]);
                } else{
                    $entry_test_id = EntryTest::where(['class_id'=>$req->class, 'user_id'=>auth()->user()->id])->first()->id;
                }
                $time_check = EntryTest::where(['class_id'=>$req->class, 'user_id'=>auth()->user()->id])->first();
                if(isset($time_check) && ($time_check->quiz_start_time==NULL || $time_check->quiz_start_time==null)){
                    EntryTest::where(['class_id'=>$req->class, 'user_id'=>auth()->user()->id])->update(['quiz_start_time'=>date('h:i'),'current_day'=>date('d')]);
                }
            return redirect('start-quiz?entry_id='.base64_encode($entry_test_id).'&class_id='.base64_encode($req->class));
            } else{
                //echo 'All fields are mandatory';
                return redirect()->back()->with('error_msg', 'All fields are mandatory');
            }
        } catch (Exception $e) {
            //print_r($e->getMessage());die();
            return redirect()->back()->with('error_msg', $e->getMessage());
        }
    }

    public function start_quiz(){
        try {
            return view('quiz/start_quiz');
            // $quiz_start = EntryTest::where(['user_id' => auth()->user()->id, 'is_quiz_start' => 1])->count();
            // if($quiz_start > 0){
            //     return view('quiz/start_quiz');
            // } else{
            //     //echo 'Sorry! You are not eligible for this quiz.';die;
            //     return redirect()->back()->with('error_msg', 'Sorry! You are not eligible for this quiz.');
            // }
        } catch (Exception $e) {
            //print_r($e->getMessage());
            return redirect()->back()->with('error_msg', $e->getMessage());
        }
    }

    public function results(){
        if (Gate::allows('resultIndex','27')) {
            try {
            $classes = ClassModel::all();
            if(count($classes) > 0){
                return view('admin/results/results', ['classes'=>$classes]);
            } else{
                return redirect()->back()->with('error_msg', 'No Class found.');
            }
        } catch (Exception $e) {
            //print_r($e->getMessage());
            return redirect()->back()->with('error_msg', $e->getMessage());
        }
        }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
        
    }

    public function results_listing($class_id){
        if (Gate::allows('resultEdit','28')) {
            try {
            if(empty($class_id)){
                throw new Exception("Class is mandatory.", 1);
            }
            $class = ClassModel::find($class_id);
            if(!is_null($class)){
                $subjects = '';
                $data_arr = [];
                if($class->applicants()->count() > 0){
                    foreach($class->applicants()->get() as $app){
                        if(!empty($app->user_id) && isset($app->user->id) && !empty($app->user->id)){

                            $total_attempts = 0;
                            $user_entry_test = $class->entry_tests()->where('user_id', $app->user_id)->first();

                            $num_of_correct = 0;
                            if(!empty($user_entry_test) && $user_entry_test->attempts()->count() > 0){
                                $total_attempts = $user_entry_test->attempts()->count();
                                foreach ($user_entry_test->attempts as $key => $value) {
                                    if(isset($value) && $value->is_true==1){
                                        $num_of_correct+=1;
                                    }
                                }
                            }

                            $no_of_questions = 0;
                            if($class->subjects()->where('is_active', 1)->count() > 0){
                                foreach($class->subjects()->where('is_active', 1)->get() as $subj){
                                    $no_of_questions += $subj->questions()->count();
                                }
                            }

                            if($total_attempts > 0){
                                $arr = [];
                                $arr['class_id'] = isset($class_id) ? $class_id : '';
                                $arr['user_id'] = isset($app->user_id) ? $app->user_id : '';
                                $arr['name'] = isset($app->user->name) ? $app->user->name : '';
                                $arr['entry_test_id'] = isset($user_entry_test->id) ? $user_entry_test->id : 0;
                                $arr['no_of_questions'] = $no_of_questions;
                                $arr['total_attempts'] = $total_attempts;
                                $arr['num_of_correct'] = $num_of_correct ?? 0;
                                $data_arr[] = $arr;
                            }
                        }
                        else{
                            //throw new Exception("No applicant user found", 1);
                            //break;
                        }
                    }
                    if(count($data_arr) == 0){
                        throw new Exception("No Results found in class.", 1);
                    }
                    //print_r($data_arr);die;
                    return view('admin/results/results_listing', ['data_arr'=>$data_arr]);
                } else{
                    throw new Exception("No applicant record found", 1);
                }
            } else{
                return redirect()->back()->with('error_msg', 'No Class record found.');
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error_msg', $e->getMessage());
        }
        }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
        
    }

    public function results_detail($entry_test_id, $user_id){
        if (Gate::allows('resultDetail','41')) {
            try {
            if(empty($entry_test_id)){
                throw new Exception("Entry Test id is mandatory.", 1);
            }

            $test = EntryTest::where(['id'=>$entry_test_id, 'user_id'=>$user_id])->first();
            if(is_null($test)){
                throw new Exception("Entry Test not found", 1);
            }

            $data_arr = [];
            if($test->attempts()->count() > 0){
                foreach($test->attempts()->get() as $att){
                    $dt = [];
                    $dt['question'] = isset($att->question->id) ? $att->question->question_content : '';
                    $dt['attempt_answer'] = isset($att->answer->id) ? $att->answer->content : '';
                    $dt['correct_answer'] = isset($att->question->id) && $att->question->answers()->where('is_true', 1)->count() > 0 ? $att->question->answers()->where('is_true', 1)->first()->content : '';
                    $dt['is_true'] = isset($att->is_true) ? $att->is_true : '';
                    $data_arr[] = $dt;
                    //print_r($dt);die;
                }
            }
            //print_r($data_arr);die;
            return view('admin/results/results_detail', ['data_arr'=>$data_arr]);

        } catch (Exception $e) {
            /*print_r($e->getLine());
            echo ' --- ';
            print_r($e->getMessage());
            die;*/
            return redirect()->back()->with('error_msg', $e->getMessage());
        }
        }else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
        
    }

    public function session_flush(){
        request()->session()->get('questions_ids');
    }

    public function quizHistory(Request $request,$id)
    {
        $data['quizes'] = EntryTest::onlyTrashed()->where('user_id',$id)->get();
        return view('admin.results.quiz_history',$data);
    }

    public function quizHistoryDetail($id)
    {
        $data['attempts'] = PreviousQuizAttempt::with('entry_test','question','answer')->where('entry_test_id',$id)->get();
        return view('admin.results.quiz_history_detail',$data);
    }

    public function updateQuizTime(Request $request)
    {
        dd($request->quiz_start_time);
        EntryTest::find($request->entry_test_id)->update(['quiz_start_time'=>$request->quiz_start_time]);
        return response()->json(['status'=>1,'message'=>'time updated']);
    }
}


/*foreach($class->subjects()->get() as $subj){
    $subjects .= $subj . ' | ';
}
$subjects = rtrim($subjects, ' | ');*/