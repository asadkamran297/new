<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Gate;
use App\{
    Subject,
    ClassModel
};

class SubjectController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        if (Gate::allows('subjectIndex','7')) {
            $data['subjectdata'] = Subject::get();
            return view('admin.subject.subjects',$data);
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function create()
    {
        if (Gate::allows('subjectAdd','8')) {
            $data['classes'] = ClassModel::get();
            return view('admin.subject.add-subject',$data);
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function edits($id)
    {
        if (Gate::allows('subjectEdit','9')) {
            $cm = ClassModel::all();
            $sub = Subject::find($id);
            if(isset($sub)){
                $edits =['subjects'=>$sub,'id'=>$sub->id,'classes'=>$cm]; 
                return view('admin.subject.update-subject',$edits);
            }
            else{
                return abort(404);
            }
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function store(Request $req)
    {
        if (Gate::allows('subjectStore','10')) {
            try{
                $rules = [
                    "class_id" => "required",
                    "title" =>"required",
                ];

                $message =[
                    "class_id.required" => "Please select a class",
                    "title.required" => "Please add subject",
                ];

                $validator = Validator::make($req->all(),$rules,$message);

                if ($validator->fails()) {
                    return \Redirect::back()->withErrors($validator);
                }  
                $subject = new Subject;
                $subject->title = isset($req->title)?$req->title:'';
                $subject->class_id = isset($req->class_id)?$req->class_id:'';
                $subject->is_active = 1;
                $subject->save();

                return redirect('admin/subject')->with('success','Add Subject Successfully');
            }catch(Exception $ex) {
                return redirect()->back()->with('error_msg', $ex->getMessage());
            }
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function update(Request $request,$id)
    {
        if (Gate::allows('subjectUpdate','11')) {
            try{
                $rules = [
                    "class_id" => "required",
                    "title" =>"required",
                ];

                $message =[

                    "class_id.required" => "Class is required",
                    "title.required" => "Subject is required",
                ];

                $validator = Validator::make($request->all(),$rules,$message);

                if ($validator->fails()) {
                    return \Redirect::back()->withErrors($validator);
                }  

                $data = [
                    'title'=>$request->title,
                    'class_id'=>$request->class_id,
                ];

                Subject::where('id','=',$id)->update($data);
                return redirect('admin/subject')->with('success','Update Subject Successfully');
            }catch(Exception $ex) {
                return redirect()->back()->with('error_msg', $ex->getMessage());
            }
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function destroy($id)
    {
        if (Gate::allows('subjectDestroy','12')) {
            Subject::where('id','=',$id)->delete();
            return redirect('admin/subject');
        }
        else {
            return redirect()->back()->with('error_msg','Not authorised');
        }
    }

    public function is_active_subject(Request $req)
    {
        if (Gate::allows('subjectStatusUpdate','13')) {
            $status = isset($req->status) && $req->status=='true' ? 1 : 0;
            Subject::where('id', $req->subject_id)->update(['is_active'=>$status]);
            return response()->json(['status'=>1,'message'=>'Updated Successfully']);
        }
        else {
            return response()->json(['status'=>0,'message'=>'Not authorised']);
        }
    }
}