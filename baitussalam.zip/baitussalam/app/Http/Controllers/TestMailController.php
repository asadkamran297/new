<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Mail;
use App\Mail\TestLeadTemplate;
use Auth;
use Exception;
use App\{
	Applicant,
	ApplicantAnswer,
	Guardian,
	ClassModel
};

class TestMailController extends Controller
{

 function send_test_temp(Request $req)
  {
    try {
      $customer_name = 'Danish';
      $customer_email = 'saeed.abdullah@dwtltd.com';
      if($customer_email != '') {
        $backup = Mail::getSwiftMailer();  
        Mail::to($customer_email, $customer_name)
        ->bcc('saeed.abdullah513@gmail.com','AB')
        ->send(new TestLeadTemplate());
        Mail::setSwiftMailer($backup);        
      }
      echo "Sent";
    } catch (Exception $ex) {
      echo $ex->getMessage();
      // return redirect()->back()->with('redirect_error_fl_message', $ex->getMessage()); 
    }
  
}

}

























 