<?php

namespace App\Http\Livewire;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use App\{
	Question,
	ClassModel,
	EntryTest,
	Attempt
};
use Exception;

class StartQuiz extends Component
{
	public $questions_index = 0;
	public $user_id = 1; //auth()->user()->id;
	
	/* Entry Variables */
	public $entry_test_id = 1;
	public $entry_test_class_id = 0;
	//public $subject_id = 0;
	/* Entry Variables */

	public $end_attempt = false;
	public $ans_select_opt = false;
	public $selected_answer_id = 0;
	public $debug = [];
	public $random_questions = [];
	public $hours = 1;
	public $minutes = 2;
	public $seconds = 3;
	//public $txt = 'umer';


	//$this->debug = $this->random_questions['assigned_questions']['id'];

	public function next_question($attempt='remaining')
	{
		if($this->selected_answer_id > 0){
			if(isset($this->random_questions['assigned_questions']['id']) && isset($this->random_questions['assigned_questions']['id'])){
				DB::table('attempts')->updateOrInsert(
					['question_id' => $this->random_questions['assigned_questions']['id'], 'entry_test_id'=>$this->entry_test_id],
					['answer_id'=>$this->selected_answer_id, 'created_at'=>date('Y-m-d h:i:s'), 'updated_at'=>date('Y-m-d h:i:s')]
				);
			}
			$this->selected_answer_id = 0;
		}

		if($attempt == 'end'){
			$this->end_attempt = true;
		}
		$this->questions_index++;
		request()->session()->put('q_index', $this->questions_index);
		request()->session()->save();
	}

	public function previous_question()
	{
		$this->questions_index--;
	}

	public function end_attempted($timer='is_manual')
	{
		$end_quiz = EntryTest::where(['id'=>$this->entry_test_id, 'quiz_end'=>1])->count();
		if($end_quiz > 0){
			return redirect('thank-you');
		}

		if($this->selected_answer_id > 0){
			if(isset($this->random_questions['assigned_questions']['id']) && isset($this->random_questions['assigned_questions']['id'])){
				DB::table('attempts')->updateOrInsert(
					['question_id' => $this->random_questions['assigned_questions']['id'], 'entry_test_id'=>$this->entry_test_id],
					['answer_id'=>$this->selected_answer_id, 'created_at'=>date('Y-m-d h:i:s'), 'updated_at'=>date('Y-m-d h:i:s')]
				);
			}
			$this->selected_answer_id = 0;
		}

		if(isset($this->entry_test_id) && !empty($this->entry_test_id)){
			$etz = EntryTest::where('id', $this->entry_test_id)->get();
			if(count($etz) > 0){
				$is_auto = 0;
				if($timer == 'is_auto'){
					$is_auto = 1;
				}
				EntryTest::where('id', $this->entry_test_id)->update(['quiz_end'=>1, 'is_auto_end'=>$is_auto, 'quiz_end_date'=>date('Y-m-d h:i:s')]);
			}
		}
		return redirect('thank-you');
	}

	public function assigned_questions()
	{
		/*$class = ClassModel::find($this->entry_test_class_id);
		if(is_null($class)){
			return ['error'=>109, 'msg'=>'No Class found'];
		}*/

		//print_r($this->entry_test_class_id);die;
		$class = ClassModel::find($this->entry_test_class_id);
		if(is_null($class)){
			return ['error'=>108, 'msg'=>'No Class found'];
    		//return redirect('/quiz')->back()->with('error_msg', 'No Class found');
		}

		if($class->subjects()->count() > 0){

	    	//$subject_ids = $class->subjects()->where('is_active', 1)->get('id')->toArray();
	    	//$quiz_subject = $class->subjects()->whereIn('id', $subject_ids)->get();

			$quiz_subject = $class->subjects()->where('is_active', 1)->get();
			if(count($quiz_subject) == 0){
				return ['error'=>100, 'msg'=>'No Subject found'];
	    		//return redirect('/quiz')->back()->with('error_msg', 'No Subject found');
			}

	    	/*if($quiz_subject->questions()->count() == 0){
	    		return ['error'=>101, 'msg'=>'No Question found'];
	    	}*/
	    	// If questions are not store in session then store Starts
	    	if(!request()->session()->exists('questions_ids')) {
	    		$questions_ids_session = [];

	    		foreach($quiz_subject as $sb){
	    			$qq = $sb->questions()->where('is_active', 1)->inRandomOrder()->limit(5)->get('id');
	    			foreach($qq as $qr){
	    				$questions_ids_session[] = $qr->id;
	    			}
	    		}
	    		
		    	//print_r($questions_ids_session);die;
	    		request()->session()->put('questions_ids', $questions_ids_session);
	    		request()->session()->save();
	    	}
	    	// If questions are not store in session then store Ends

	    	$assigned_questions = [];
	    	$assigned_questions = Question::whereIn('id', request()->session()->get('questions_ids'))->get();
	    	// $assigned_questions = Question::whereIn('id', request()->session()->get('questions_ids'))->get();
	    	/*foreach($quiz_questions as $q){
	    		$assigned_questions[] = $q;
	    	}*/
	    	
	    	if(!isset($assigned_questions[$this->questions_index])){
	    		return ['error'=>102, 'msg'=>'Question Ends'];
	    		//return redirect('/quiz')->back()->with('error_msg', 'Question Ends');
	    	}

	    	$next_status = 'remaining';
	    	if(!isset($assigned_questions[$this->questions_index+1])){
	    		$next_status = 'end';
	    	}

	    	$previous_status = 'remaining';
	    	if(!isset($assigned_questions[$this->questions_index-1])){
	    		$previous_status = 'end';
	    	}

	    		// dd(request()->session()->get('q_index'));
	    	$q_index = 0;
	    	if(request()->session()->get('q_index')){
	    		$q_index = request()->session()->get('q_index');	
	    	}

	    	// dd($q_index);

	    	$questions = $assigned_questions[$q_index];
	    	// dd($questions);
	    	// dd($this->questions_index);

	    	$ans_arr = [];
	    	foreach ($questions->answers()->get() as $key => $ans) {

	    		$curr_ans_arr = [
	    			'id' => $ans->id,
	    			'content' => $ans->content,
	    			'selected' => false
	    		];
	    		$current_attempt = Attempt::where(['entry_test_id'=>$this->entry_test_id,'question_id'=>$ans->question_id,'answer_id'=>$ans->id])->first();

	    		if(!is_null($current_attempt)){
	    			$this->ans_select_opt = true;
	    			$curr_ans_arr['selected'] = true;
	    		}
	    		$ans_arr[] = $curr_ans_arr;
	    	}
	    	return ['error'=>0, 'assigned_questions'=>$questions, 'answers'=>$ans_arr, 'next_status'=>$next_status, 'previous_status'=>$previous_status];
	    } else{
	    	return ['error'=>103, 'msg'=>'Class not assigned to any subject'];
    		//return redirect('/quiz')->back()->with('error_msg', 'Class not assigned to any subject');
	    }
	}

	public function mount(Request $req)
	{

		if($req->has('entry_id') && !empty($req->entry_id)){

			$this->entry_test_id = base64_decode($req->entry_id);

			$end_quiz = EntryTest::where(['id'=>$this->entry_test_id, 'quiz_end'=>1])->count();
			if($end_quiz > 0){
				return redirect('/quiz')->back()->with('error_msg', 'Sorry! quiz already completed.');
			}

			if($req->has('class_id') && !empty($req->class_id)){
				$this->entry_test_class_id = base64_decode($req->class_id);
			}
    		// print_r($this->questions_index);die;
    		// print_r($this->assigned_questions());die;

			if(empty($this->entry_test_class_id)){
				return redirect()->back()->with('error_msg', 'Class id is mandatory');
			} if(empty($this->entry_test_id)){
				return redirect()->back()->with('error_msg', 'Entry Test id is mandatory');
			} /*if(empty($this->subject_id)){
				echo 'Subject id is mandatory';die;
			}*/

		} else{
			return redirect()->back()->with('error_msg', 'Token is mandatory');
		}
	}

	public function updatedSelectedAnswerId(){
		$this->ans_select_opt = false;
	}

	public function render()
	{
		try {

			$this->random_questions = $this->assigned_questions();

    		// print_r($this->random_questions);die;

			if(isset($this->random_questions['error']) && $this->random_questions['error'] > 0){
				print_r($this->random_questions['msg']);die;
				return view('quiz.quiz')->with('error_msg', $this->random_questions['msg']);
			}
			return view('livewire.start-quiz');
		} catch (Exception $e) {
    		//return ['error'=>100, 'msg'=>$e->getMessage()];
			return redirect()->back()->with('error_msg', $e->getMessage());
		}
	}
}
