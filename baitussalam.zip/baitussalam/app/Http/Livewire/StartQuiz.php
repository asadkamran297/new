<?php

namespace App\Http\Livewire;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\ResultTemplate;
use Livewire\Component;
use App\{
	Question,
	ClassModel,
	EntryTest,
	Attempt,
	ClassQuizQuestions
};
use Exception;

class StartQuiz extends Component
{
	public $questions_index = 0;
	public $user_id = 1; //auth()->user()->id;
	
	/* Entry Variables */
	public $entry_test_id = 1;
	public $entry_test_class_id = 0;
	//public $subject_id = 0;
	/* Entry Variables */

	public $end_attempt = false;
	public $ans_select_opt = false;
	public $selected_answer_id = 0;
	public $debug = [];
	public $random_questions = [];
	public $hours = 1;
	public $minutes = 2;
	public $seconds = 3;
	public $correct_ans = 0;
	//public $txt = 'umer';
	public $page_refresh = 0;

	public function next_question($attempt='remaining')
	{
		foreach($this->random_questions['answers'] as $ann){
			if($ann['id'] == $this->selected_answer_id){
				$this->correct_ans = $ann['is_true'];
				break;
			}
		}

		// dd($this->selected_answer_id);
		if($this->selected_answer_id > 0){
			if(isset($this->random_questions['assigned_questions']['id']) && isset($this->random_questions['assigned_questions']['id'])){
				DB::table('attempts')->updateOrInsert(
					['question_id' => $this->random_questions['assigned_questions']['id'], 'entry_test_id'=>$this->entry_test_id],
					['answer_id'=>$this->selected_answer_id, 'is_true'=>$this->correct_ans, 'created_at'=>date('Y-m-d h:i:s'), 'updated_at'=>date('Y-m-d h:i:s')]
				);
			}
			$this->selected_answer_id = 0;
		}

		if($attempt == 'end'){
			$this->end_attempt = true;
		}
		$this->questions_index++;
		$this->page_refresh = 1;
	}

	public function previous_question()
	{
		$this->questions_index--;
		$this->page_refresh = 1;
	}

	public function end_attempted($timer='is_manual')
	{
		$end_quiz = EntryTest::where(['id'=>$this->entry_test_id, 'quiz_end'=>1])->count();
		if($end_quiz > 0){
			return redirect('thank-you');
		}

		foreach($this->random_questions['answers'] as $ann){
			if($ann['id'] == $this->selected_answer_id){
				$this->correct_ans = $ann['is_true'];
				break;
			}
		}

		if($this->selected_answer_id > 0){
			if(isset($this->random_questions['assigned_questions']['id']) && isset($this->random_questions['assigned_questions']['id'])){
				DB::table('attempts')->updateOrInsert(
					['question_id' => $this->random_questions['assigned_questions']['id'], 'entry_test_id'=>$this->entry_test_id],
					['answer_id'=>$this->selected_answer_id, 'is_true'=>$this->correct_ans, 'created_at'=>date('Y-m-d h:i:s'), 'updated_at'=>date('Y-m-d h:i:s')]
				);
			}
			$this->selected_answer_id = 0;
		}

		if(isset($this->entry_test_id) && !empty($this->entry_test_id)){
			$etz = EntryTest::where('id', $this->entry_test_id)->get();
			if(count($etz) > 0){
				$is_auto = 0;
				if($timer == 'is_auto'){
					$is_auto = 1;
				}
				EntryTest::where('id', $this->entry_test_id)->update(['quiz_end'=>1, 'is_auto_end'=>$is_auto, 'quiz_end_date'=>date('Y-m-d h:i:s')]);
			}
		}

		$test = EntryTest::where(['id'=>$this->entry_test_id, 'user_id'=>Auth::user()->id])->first();
		$data_arr = [];
		if(isset($test->attempts) && $test->attempts()->count() > 0){
			foreach($test->attempts()->get() as $att){
				$dt = [];
				$dt['question'] = isset($att->question->id) ? $att->question->question_content : '';
				$dt['attempt_answer'] = isset($att->answer->id) ? $att->answer->content : '';
				$dt['correct_answer'] = isset($att->question->id) && $att->question->answers()->where('is_true', 1)->count() > 0 ? $att->question->answers()->where('is_true', 1)->first()->content : '';
				$dt['is_true'] = isset($att->is_true) ? $att->is_true : '';
				$data_arr[] = $dt;

			}
		}

		$customer_name = isset(Auth::user()->name)? Auth::user()->name:'';
		$customer_email =isset(Auth::user()->email)? Auth::user()->email:'';
		if($customer_email != '') {
			$backup = Mail::getSwiftMailer();  
			Mail::to($customer_email, $customer_name)
			->bcc('saeed.abdullah513@gmail.com','AB')
			->send(new ResultTemplate($data_arr));
			Mail::setSwiftMailer($backup);   
		}

		return redirect('thank-you');
	}

	public function assigned_questions()
	{
		$class = ClassModel::with('quiz_questions')->find($this->entry_test_class_id);
		if(is_null($class)){
			return ['error'=>108, 'msg'=>'No Class found'];
		}	

		if(isset($class) && $class->random_question && $class->random_question==1){
			if(!count($class['quiz_questions'])){
				return ['error'=>108, 'msg'=>'Questions not foud contact with admin'];
			}
			$questions_ids_session = [];
			foreach($class['quiz_questions'] as $sb){
				$questions_ids_session[] = $sb->question_id;
			}

			$assigned_questions = [];
			$assigned_questions = Question::whereIn('id', $questions_ids_session)->get();

			if(!isset($assigned_questions[$this->questions_index])){
				return ['error'=>102, 'msg'=>'Question Ends'];
			}

			$next_status = 'remaining';
			if(!isset($assigned_questions[$this->questions_index+1])){
				$next_status = 'end';
			}

			$previous_status = 'remaining';
			if(!isset($assigned_questions[$this->questions_index-1])){
				$previous_status = 'end';
			}
			
			$current_attempt = Attempt::where(['entry_test_id'=>$this->entry_test_id])->orderBy('id','desc')->get();
			if($this->page_refresh == 0 && isset($current_attempt) && count($current_attempt) && in_array($current_attempt[0]->question_id,$questions_ids_session)){
				$this->questions_index = count($current_attempt);
			}

			$questions = $assigned_questions[$this->questions_index];
			$quiz_hour = '0';
			$quiz_minutes = '59';
			$quiz_seconds = '59';

			$r_t = '';
			if($class->entry_tests()->orderBy('id','desc')->get()[0]['current_day']==date('d')){
				if(isset($class->entry_tests) && count($class->entry_tests) && isset($class->entry_tests()->orderBy('id','desc')->get()[0])){




						$end = strtotime(date('h:i'));
					    $start= strtotime($class->entry_tests()->orderBy('id','desc')->get()[0]['quiz_start_time']);

					    $hours = intval(($end - $start)/3600);
					    // echo $hours.' hours'; //in hours

					    //If you want it in minutes, you can divide the difference by 60 instead
					    $mins = (int)(($end - $start) / 60);
					    echo $mins.' minutues'.'<br>';

					      die;








					$r_t = date('h:i',(strtotime(date('h:i'))-strtotime($class->entry_tests()->orderBy('id','desc')->get()[0]['quiz_start_time'])));
					dd($r_t,date('h:i'),$class->entry_tests()->orderBy('id','desc')->get()[0]['quiz_start_time']);
					if(isset($r_t) && $r_t>=0){
						$remaining_time = ((strtotime($class->quiz_time))-(strtotime("00:".$r_t)))/60;
						$rem_time = "00:".$remaining_time;
						if(isset($rem_time) && $rem_time>=0){
							$q_t = explode(':', $rem_time);
							$quiz_hour = isset($q_t[0]) ? $q_t[0] : '0';
							$quiz_minutes = isset($q_t[1]) ? $q_t[1] : '59';
						}
					}
					else{
						$q_t = explode(':', $class->quiz_time);
						$quiz_hour = isset($q_t[0]) ? $q_t[0] : '0';
						$quiz_minutes = isset($q_t[1]) ? $q_t[1] : '59';
					}
				}
			}
			else{
				return ['error'=>102, 'msg'=>'Your quiz date time has been expired'];
			}
			$ans_arr = [];
			foreach ($questions->answers()->get() as $key => $ans) {
				$curr_ans_arr = [
					'id' => $ans->id,
					'content' => 	$ans->content,
					'selected' => false,
					'is_true' => $ans->is_true
				];
				$current_attempt = Attempt::where(['entry_test_id'=>$this->entry_test_id,'question_id'=>$ans->question_id,'answer_id'=>$ans->id])->first();

				if(!is_null($current_attempt)){
					$this->ans_select_opt = true;
					$curr_ans_arr['selected'] = true;
				}
				$ans_arr[] = $curr_ans_arr;
			}
			$lang = 'en';
			if(isset($questions) && isset($questions->language_code) && $questions->language_code=='ur'){
				$lang = 'ur';
			}

			return ['error'=>0, 'language'=>$lang, 'assigned_questions'=>$questions, 'answers'=>$ans_arr, 'next_status'=>$next_status, 'previous_status'=>$previous_status,'quiz_hour'=>$quiz_hour,'quiz_minutes'=>$quiz_minutes,'quiz_seconds'=>$quiz_seconds,'entry_test_id'=>$this->entry_test_id];
		}

		if($class->subjects()->count() > 0){

			$quiz_subject = $class->subjects()->where('is_active', 1)->get();
			if(count($quiz_subject) == 0){
				return ['error'=>100, 'msg'=>'No Subject found'];
			}

	    	// If questions are not store in session then store Starts
			if(!request()->session()->exists('questions_ids')) {
				$questions_ids_session = [];
				foreach($quiz_subject as $sb){
					if(isset($sb->questions) && count($sb->questions)<=0){
						continue;
					}
					$qq = $sb->questions()->where('is_active', 1)->inRandomOrder()->limit($class->question_limit)->get('id');
					foreach($qq as $qr){
						$questions_ids_session[] = $qr->id;
					}
				}

				request()->session()->put('questions_ids', $questions_ids_session);
				request()->session()->save();
			}

	    	// If questions are not store in session then store Ends
			$assigned_questions = [];
			$assigned_questions = Question::whereIn('id', request()->session()->get('questions_ids'))->get();

			if(!isset($assigned_questions[$this->questions_index])){
				return ['error'=>102, 'msg'=>'Question Ends'];
			}

			$next_status = 'remaining';
			if(!isset($assigned_questions[$this->questions_index+1])){
				$next_status = 'end';
			}

			$previous_status = 'remaining';
			if(!isset($assigned_questions[$this->questions_index-1])){
				$previous_status = 'end';
			}


			$current_attempt = Attempt::where(['entry_test_id'=>$this->entry_test_id])->orderBy('id','desc')->get();
			if($this->page_refresh == 0 && isset($current_attempt) && count($current_attempt) && in_array($current_attempt[0]->question_id,request()->session()->get('questions_ids'))){
				$this->questions_index = count($current_attempt);
			}
			$questions = $assigned_questions[$this->questions_index];

			$quiz_hour = '0';
			$quiz_minutes = '59';
			$quiz_seconds = '59';
			// dd($class->entry_tests()->orderBy('id','desc')->get()[0]['current_day']);
			if($class->entry_tests()->orderBy('id','desc')->get()[0]['current_day']==date('d')){
				if(isset($class->entry_tests) && count($class->entry_tests) && isset($class->entry_tests[0]['quiz_start_time'])){
					$r_t = (strtotime(date('h:i'))-strtotime($class->entry_tests[0]['quiz_start_time']))/60;
					if(isset($r_t) && $r_t>=0){
						$remaining_time = ((strtotime($class->quiz_time))-(strtotime("00:".$r_t)))/60;
						$rem_time = "00:".$remaining_time;
						if(isset($rem_time)){
							$q_t = explode(':', $rem_time);
							$quiz_hour = isset($q_t[0]) ? $q_t[0] : '0';
							$quiz_minutes = isset($q_t[1]) ? $q_t[1] : '59';
						}
					}
					else{
						$q_t = explode(':', $class->quiz_time);
						$quiz_hour = isset($q_t[0]) ? $q_t[0] : '0';
						$quiz_minutes = isset($q_t[1]) ? $q_t[1] : '59';
					}
				}
			}
			else{
				return ['error'=>102, 'msg'=>'Your quiz date time has been expired'];
			}

			$ans_arr = [];
			foreach ($questions->answers()->get() as $key => $ans) {
				$curr_ans_arr = [
					'id' => $ans->id,
					'content' => 	$ans->content,
					'selected' => false,
					'is_true' => $ans->is_true
				];
				$current_attempt = Attempt::where(['entry_test_id'=>$this->entry_test_id,'question_id'=>$ans->question_id,'answer_id'=>$ans->id])->first();

				if(!is_null($current_attempt)){
					$this->ans_select_opt = true;
					$curr_ans_arr['selected'] = true;
				}
				$ans_arr[] = $curr_ans_arr;
			}
			$lang = 'en';
			if(isset($questions) && isset($questions->language_code) && $questions->language_code=='ur'){
				$lang = 'ur';
			}

			return ['error'=>0, 'language'=>$lang, 'assigned_questions'=>$questions, 'answers'=>$ans_arr, 'next_status'=>$next_status, 'previous_status'=>$previous_status,'quiz_hour'=>$quiz_hour,'quiz_minutes'=>$quiz_minutes,'quiz_seconds'=>$quiz_seconds,'entry_test_id'=>$this->entry_test_id];

		} else{
			return ['error'=>103, 'msg'=>'Class not assigned to any subject'];
		}
	}

	public function mount(Request $req)
	{

		if($req->has('entry_id') && !empty($req->entry_id)){

			$this->entry_test_id = base64_decode($req->entry_id);

			$end_quiz = EntryTest::where(['id'=>$this->entry_test_id, 'quiz_end'=>1])->count();
			if($end_quiz > 0){
				return redirect('/quiz')->back()->with('error_msg', 'Sorry! quiz already completed.');
			}

			if($req->has('class_id') && !empty($req->class_id)){
				$this->entry_test_class_id = base64_decode($req->class_id);
			}

			if(empty($this->entry_test_class_id)){
				return redirect()->back()->with('error_msg', 'Class id is mandatory');
			} if(empty($this->entry_test_id)){
				return redirect()->back()->with('error_msg', 'Entry Test id is mandatory');
			} /*if(empty($this->subject_id)){
				echo 'Subject id is mandatory';die;
			}*/

		} else{
			return redirect()->back()->with('error_msg', 'Token is mandatory');
		}
	}

	public function updatedSelectedAnswerId(){
		$this->ans_select_opt = false;
	}

	public function render()
	{
		try {

			$this->random_questions = $this->assigned_questions();

    		//print_r($this->random_questions['error']);die;

			if(isset($this->random_questions['error']) && $this->random_questions['error'] > 0){
				print_r($this->random_questions['msg']);die;
				return view('quiz.quiz')->with('error_msg', $this->random_questions['msg']);
			}
			return view('livewire.start-quiz');
		} catch (Exception $e) {
    		//return ['error'=>100, 'msg'=>$e->getMessage()];
			return redirect()->back()->with('error_msg', $e->getMessage());
		}
	}
}
