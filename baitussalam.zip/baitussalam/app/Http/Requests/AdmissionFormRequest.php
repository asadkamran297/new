<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AdmissionFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
       return auth()->check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "name" => "required",
                 "f_name" =>"required",
                 "dob" =>"required",
                 "class_id" =>"required",
                 "city" =>"required",
                 "mobile_no" =>"required",
                 "present_address" =>"required",
                 "permanent_address" =>"required",
                 "islamic_education" =>"required",
                 "previous_institute" =>"required",
                 "basic_education" =>"required",
                 "father_name" =>"required",
                 "applicant_relation" =>"required",
                 "occupation" =>"required",
                 "contact_no" =>"required",
                 "guardian_cnic" =>"required",
                 "another_guardian_name" =>"required"
        ];
    }
}
