<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\User;
use Swift_SmtpTransport;
use Swift_Mailer;

class RegisterMail extends Mailable
{
    use Queueable, SerializesModels;


    public $details;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($details)
    {
        $this->details = $details;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $transport = new Swift_SmtpTransport('mail.zonalgo.com', 587, 'tls');
        $transport->setUsername('saeed.abdullah@dwtltd.com');
        $transport->setPassword('6pgjaSNoUU');
        $mailtrap = new Swift_Mailer($transport);
        Mail::setSwiftMailer($mailtrap);
        return $this->from('saeed.abdullah@dwtltd.com','Bait Us Salam')
                    ->subject('Register Email')   
                    ->view('emails.register-email');
    }
}