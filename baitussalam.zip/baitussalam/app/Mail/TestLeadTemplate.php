<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\User;
use Swift_SmtpTransport;
use Swift_Mailer;


class TestLeadTemplate extends Mailable
{
    use Queueable, SerializesModels;
     //public $details;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    // public function __construct($details)
    // {
    //     $this->details = $details;
    // }

    /**
     * Build the message.
     *
     * @return $this
     */
     public function build()
    {

     $transport = new Swift_SmtpTransport('mail.zonalgo.com', 587, 'tls');
        $transport->setUsername('saeed.abdullah@dwtltd.com');
        $transport->setPassword('6pgjaSNoUU');
        $mailtrap = new Swift_Mailer($transport);
        Mail::setSwiftMailer($mailtrap);   
        $from_email = 'saeed.abdullah@dwtltd.com';    
      
     return $this->from($from_email)
                    ->subject('Dream World Travel')
                    ->view('emails.testing_email_template');
    

    }
}

