<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Permission extends Model
{
	use SoftDeletes;

	/**
	  * The table associated with the model.
	  *
	  * @var string
	*/
	protected $table = "permissions";

	/**
	  * The attributes that are mass assignable.
	  *
	  * @var array
	*/
	protected $fillable = [
		"title", "is_active"
	];

	// /**
 //    * @return \Illiminate\Databse\Eloquent\Relations\HasMany 
 //    */
 //    public function role_permissions(){
 //    	return $this->belongsTo(RolePermission::class,'permission_id','id');
 //    }

    /**
    * @return /Illuminate/Database/Eloquent/Relations/HasMay
    */
    public function permissions_r(){
        return \DB::table('role_permissions')->where('permission_id',$this->id)->get(['role_id','permission_id']);
    }
}
