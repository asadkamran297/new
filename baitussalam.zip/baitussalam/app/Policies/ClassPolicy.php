<?php

namespace App\Policies;

use Illuminate\Auth\Access\HandlesAuthorization;
use App\{
    Role,
    User,
    Permission
};

class ClassPolicy
{
    use HandlesAuthorization;

    private $permission_ids = [];
    public function __construct()
    {
        $this->permission_ids = auth()->user()->role->r_permissions()->pluck('permission_id')->toArray();
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $role
     * @return mixed
     */
    public function view(User $user, Role $role,$id)
    {
        // if(isset($id) && in_array($id, $this->permission_ids)){
        //     return true;
        // }
        // return false;
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can create models.
     *
     * @return mixed
     */
    public function edit(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can create models.
     *
     * @return mixed
     */
    public function save(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Role  $role
     * @return mixed
     */
    public function update(User $user, $id)
    {
         if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $role
     * @return mixed
     */
    public function delete(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $role
     * @return mixed
     */
    public function restore(User $user, Role $role)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $role
     * @return mixed
     */
    public function forceDelete(User $user, Role $role)
    {
        //
    }
}
