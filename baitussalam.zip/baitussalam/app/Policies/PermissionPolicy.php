<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PermissionPolicy
{
    use HandlesAuthorization;

    private $permission_ids = [];

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->permission_ids = auth()->user()->role->r_permissions()->pluck('permission_id')->toArray();
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function index(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function add(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function store(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function edit(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function update(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function destroy(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function statusUpdate(User $user,$id)
    {
        if(isset($id) && in_array($id, $this->permission_ids)){
            return true;
        }
        return false;
    }
}
