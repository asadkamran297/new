<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use Illuminate\Support\Facades\Session;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('*', function ($view){
            $lang_key = 'en';
            $lang_value = '';
            $lang_field = '';
            if(Session::has('locale') && Session::get('locale') == 'ur') {
              $lang_key = 'ur';
              $lang_value = 'urdu-page';
              $lang_field = 'urdu-field';
            } 
            $view->with(['lang_key'=>$lang_key, 'lang_value'=>$lang_value, 'lang_field'=>$lang_field]);    
        });
    }
}
