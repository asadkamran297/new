<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Auth;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        $class_policy = 'App\Policies\ClassPolicy';
        Gate::define('classIndex',$class_policy.'@viewAny');
        Gate::define('classCreate',$class_policy.'@create');
        Gate::define('classEdit',$class_policy.'@edit');
        Gate::define('classDelete',$class_policy.'@delete');
        Gate::define('classSave',$class_policy.'@save');
        Gate::define('classUpdate',$class_policy.'@update');

        $subject_policy = 'App\Policies\SubjectPolicy';
        Gate::define('subjectIndex',$subject_policy.'@index');
        Gate::define('subjectAdd',$subject_policy.'@add');
        Gate::define('subjectStore',$subject_policy.'@store');
        Gate::define('subjectEdit',$subject_policy.'@edit');
        Gate::define('subjectUpdate',$subject_policy.'@update');
        Gate::define('subjectDestroy',$subject_policy.'@destroy');
        Gate::define('subjectStatusUpdate',$subject_policy.'@statusUpdate');

        $applicant_policy = 'App\Policies\ApplicantPolicy';
        Gate::define('applicantIndex',$applicant_policy.'@index');
        Gate::define('applicantAdd',$applicant_policy.'@add');
        Gate::define('applicantStore',$applicant_policy.'@store');
        Gate::define('applicantEdit',$applicant_policy.'@edit');
        Gate::define('applicantUpdate',$applicant_policy.'@update');
        Gate::define('applicantDestroy',$applicant_policy.'@destroy');
        Gate::define('applicantStatusUpdate',$applicant_policy.'@statusUpdate');

        $result_policy = 'App\Policies\ResultPolicy';
        Gate::define('resultIndex',$result_policy.'@index');
        Gate::define('resultAdd',$result_policy.'@add');
        Gate::define('resultStore',$result_policy.'@store');
        Gate::define('resultEdit',$result_policy.'@edit');
        Gate::define('resultUpdate',$result_policy.'@update');
        Gate::define('resultDestroy',$result_policy.'@destroy');
        Gate::define('resultDetail',$result_policy.'@results_detail');
        Gate::define('resultStatusUpdate',$result_policy.'@statusUpdate');


        $quiz_policy = 'App\Policies\QuizPolicy';
        Gate::define('quizIndex',$quiz_policy.'@index');
        Gate::define('quizHeaderIndex',$quiz_policy.'@index');

        $users_policy = 'App\Policies\UserPolicy';
        Gate::define('userIndex',$users_policy.'@index');
        Gate::define('userStatusUpdate',$users_policy.'@statusUpdate');
        Gate::define('userRoleUpdate',$users_policy.'@userroleUpdate');

        $user_role_policy = 'App\Policies\UserRolePolicy';
        Gate::define('userroleIndex',$user_role_policy.'@index');
        Gate::define('userroleUpdate',$user_role_policy.'@update');

        $permission_policy = 'App\Policies\PermissionPolicy';
        Gate::define('permissionIndex',$permission_policy.'@index');
        Gate::define('permissionAdd',$permission_policy.'@add');
        Gate::define('permissionStore',$permission_policy.'@store');
        Gate::define('permissionEdit',$permission_policy.'@edit');
        Gate::define('permissionUpdate',$permission_policy.'@update');
        Gate::define('permissionDestroy',$permission_policy.'@destroy');
        Gate::define('permissionStatusUpdate',$permission_policy.'@statusUpdate');

        $role_policy = 'App\Policies\RolePolicy';
        Gate::define('roleIndex',$role_policy.'@index');

        $question_policy = 'App\Policies\QuestionPolicy';
        Gate::define('questionIndex',$question_policy.'@index');
        Gate::define('questionAdd',$question_policy.'@add');
        Gate::define('questionStore',$question_policy.'@store');
        Gate::define('questionEdit',$question_policy.'@edit');
        Gate::define('questionUpdate',$question_policy.'@update');
        Gate::define('questionDestroy',$question_policy.'@destroy');
        Gate::define('questionStatusUpdate',$question_policy.'@statusUpdate');

    }
}
