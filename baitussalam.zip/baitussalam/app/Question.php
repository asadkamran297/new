<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Question extends Model
{

    use SoftDeletes;

    /**
      * The table associated with the model.
      *
      * @var string
    */
    protected $table = "questions";


    /**
      * The attributes that are mass assignable.
      *
      * @var array
    */
    protected $fillable = [
        "class_id", "user_id","is_quiz_start","quiz_end","is_auto_end","quiz_end_date","language_code"
    ];


    public function answers()
    {
        return $this->hasMany('App\Answer','question_id','id');
    }


    public function subjects()
    {
        return $this->belongsTo('App\Subject','subject_id','id');
    }


    public function options()
    {
        return $this->hasMany('App\QuestionOption','question_id','id');
    }
}
