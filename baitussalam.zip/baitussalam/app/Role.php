<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\RolePermission;

class Role extends Model
{
	use SoftDeletes;

    /**
    * The table associated with the model.
      *
      * @var string
    */
    protected $table = "roles";


    /**
      * The attributes that are mass assignable.
      *
      * @var array
    */
    protected $fillable = [
        "title", "is_active",
    ];

    public function users(){
    	return $this->hasMany('App\User','role_id');
    }

    // /**
    // * @return \Illiminate\Databse\Eloquent\Relations\HasMany 
    // */
    // public function role_permissions(){
    //     return $this->belongsToMany(RolePermission::class,'role_permissions','permission_id','role_id');
    // }

    /**
    * @return /Illuminate/Database/Eloquent/Relations/HasMay
    */
    public function r_permissions(){
        return \DB::table('role_permissions')->where('role_id',$this->id)->get(['role_id','permission_id']);
    }


}
