<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RolePermission extends Model
{
    /**
	  * The table associated with the model.
	  *
	  * @var string
	*/
    protected $table = "role_permissions";

	/**
	  * The attributes that are mass assignable.
	  *
	  * @var array
	*/
	protected $fillable = [
		"role_id", "permission_id"
	];

	/**
    * @return \Illiminate\Databse\Eloquent\Relations\HasMany 
    */
	public function role(){
		return $this->hasMany(Role::class);
	}

    /**
    * @return \Illiminate\Databse\Eloquent\Relations\HasMany 
    */
    public function permissions(){
    	return $this->hasMany(Permission::class);
    }
}
