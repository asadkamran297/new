<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Subject extends Model
{
	use SoftDeletes;

    /**
  * The table associated with the model.
  *
  * @var string
  */
    protected $table = "subjects";


  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
   protected $fillable = [
    "title", "class_id","is_active",
    ];


      public function classes()
	{
		return $this->belongsTo('App\ClassModel','class_id');
	}

	  public function questions()
    {
        return $this->hasMany('App\Question','subject_id','id');
    }

}