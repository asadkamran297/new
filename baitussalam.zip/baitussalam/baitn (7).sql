-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 05, 2021 at 05:45 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baitn`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` int(11) NOT NULL,
  `is_true` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `content`, `question_id`, `is_true`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Asad', 1, '0', NULL, '2021-02-24 05:41:47', '2021-02-25 04:01:55'),
(2, 'واح', 1, '1', NULL, '2021-02-24 05:41:47', '2021-02-25 04:01:55'),
(3, 'واح', 1, '0', NULL, '2021-02-24 05:41:47', '2021-02-24 05:41:47'),
(4, 'واح', 1, '0', NULL, '2021-02-24 05:41:47', '2021-02-24 05:41:47'),
(5, 'Karachi', 2, '1', NULL, '2021-02-24 05:42:28', '2021-02-24 05:42:28'),
(6, 'Lahore', 2, '0', NULL, '2021-02-24 05:42:28', '2021-02-24 05:42:28'),
(7, 'Dubai', 2, '0', NULL, '2021-02-24 05:42:28', '2021-02-24 05:42:28'),
(8, 'Islabamad', 2, '0', NULL, '2021-02-24 05:42:28', '2021-02-24 05:42:28'),
(9, 'Anum Estate', 3, '0', NULL, '2021-02-24 05:43:38', '2021-02-24 05:43:38'),
(10, 'Anum Empire', 3, '1', NULL, '2021-02-24 05:43:38', '2021-02-24 11:29:40'),
(11, 'Anum Blessing', 3, '0', NULL, '2021-02-24 05:43:38', '2021-02-24 05:43:38'),
(12, 'Anum Wah wah', 3, '0', NULL, '2021-02-24 05:43:38', '2021-02-24 05:43:38'),
(13, 'Afghanistan', 4, '0', NULL, '2021-02-24 05:44:25', '2021-03-01 05:39:13'),
(14, 'India', 4, '1', NULL, '2021-02-24 05:44:25', '2021-03-01 05:39:13'),
(15, 'Iran', 4, '0', NULL, '2021-02-24 05:44:25', '2021-03-01 05:39:13'),
(16, 'UAE', 4, '0', NULL, '2021-02-24 05:44:25', '2021-03-01 05:39:13'),
(17, 'Islamabad', 5, '0', NULL, '2021-02-24 05:51:55', '2021-03-01 05:38:31'),
(18, 'Karachi', 5, '0', NULL, '2021-02-24 05:51:55', '2021-03-01 05:38:31'),
(19, 'Sydney', 5, '0', NULL, '2021-02-24 05:51:55', '2021-03-01 05:38:31'),
(20, 'None of the above', 5, '1', NULL, '2021-02-24 05:51:55', '2021-03-01 05:38:31'),
(21, 'Asia', 6, '1', NULL, '2021-02-24 05:53:27', '2021-03-01 05:37:41'),
(22, 'Africa', 6, '0', NULL, '2021-02-24 05:53:27', '2021-03-01 05:37:41'),
(23, 'Europe', 6, '0', NULL, '2021-02-24 05:53:27', '2021-03-01 05:37:41'),
(24, 'none of above', 6, '0', NULL, '2021-02-24 05:53:27', '2021-03-01 05:37:41'),
(25, 'Asad', 7, '0', NULL, '2021-02-24 05:54:06', '2021-02-24 05:54:06'),
(26, 'Url0awrtRY', 7, '0', NULL, '2021-02-24 05:54:06', '2021-02-24 05:54:06'),
(27, 'Url0awrtRY', 7, '1', NULL, '2021-02-24 05:54:06', '2021-02-24 05:54:06'),
(28, 'Asad', 7, '0', NULL, '2021-02-24 05:54:06', '2021-02-24 05:54:06'),
(29, 'wah1', 8, '1', NULL, '2021-02-24 05:55:40', '2021-02-24 05:58:47'),
(30, 'wah2', 8, '0', NULL, '2021-02-24 05:55:40', '2021-02-24 05:58:35'),
(31, 'wah3', 8, '0', NULL, '2021-02-24 05:55:40', '2021-02-24 05:58:35'),
(32, 'wah4', 8, '0', NULL, '2021-02-24 05:55:40', '2021-02-24 05:58:47'),
(33, 'آساد', 9, '0', NULL, '2021-02-25 07:24:25', '2021-02-25 07:24:25'),
(34, 'خاراچحی', 9, '1', NULL, '2021-02-25 07:24:25', '2021-02-25 07:24:25'),
(35, 'آنءم ٰستاتع', 9, '0', NULL, '2021-02-25 07:24:25', '2021-02-25 07:24:25'),
(36, 'واح واح واحج', 9, '0', NULL, '2021-02-25 07:24:25', '2021-02-25 07:24:25'),
(37, 'German', 10, '0', NULL, '2021-03-01 08:19:10', '2021-03-01 08:19:10'),
(38, 'Latin', 10, '1', NULL, '2021-03-01 08:19:10', '2021-03-01 08:19:10'),
(39, 'French', 10, '0', NULL, '2021-03-01 08:19:10', '2021-03-01 08:19:10'),
(40, 'Arabic', 10, '0', NULL, '2021-03-01 08:19:10', '2021-03-01 08:19:10'),
(41, 'Charles Babbage', 11, '1', NULL, '2021-03-01 08:19:38', '2021-03-01 08:19:38'),
(42, 'Simur Cray', 11, '0', NULL, '2021-03-01 08:19:38', '2021-03-01 08:19:38'),
(43, 'Augusta Adaming', 11, '0', NULL, '2021-03-01 08:19:38', '2021-03-01 08:19:38'),
(44, 'Allen Turing', 11, '0', NULL, '2021-03-01 08:19:38', '2021-03-01 08:19:38'),
(45, 'Storage and relative', 12, '0', NULL, '2021-03-01 08:20:11', '2021-03-01 08:20:11'),
(46, 'Logical operation', 12, '0', NULL, '2021-03-01 08:20:11', '2021-03-01 08:20:11'),
(47, 'Arithmetic operation', 12, '0', NULL, '2021-03-01 08:20:11', '2021-03-01 08:20:11'),
(48, 'All the above', 12, '1', NULL, '2021-03-01 08:20:11', '2021-03-01 08:20:11'),
(49, 'Martin Cooper', 13, '0', NULL, '2021-03-01 08:20:57', '2021-03-01 08:48:26'),
(50, 'Denis Riche', 13, '0', NULL, '2021-03-01 08:20:57', '2021-03-01 08:49:02'),
(51, 'Vint Cerf', 13, '1', NULL, '2021-03-01 08:20:57', '2021-03-01 08:49:08'),
(52, 'Chares Babbage', 13, '0', NULL, '2021-03-01 08:20:57', '2021-03-01 08:49:08');

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `class_selection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `islamic_education` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_institute_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_institute_left_reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `basic_education` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_allowed` tinyint(4) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`id`, `user_id`, `class_id`, `class_selection`, `name`, `father_name`, `dob`, `city`, `phone`, `address`, `permanent_address`, `cnic`, `islamic_education`, `previous_institute_name`, `previous_institute_left_reason`, `basic_education`, `is_allowed`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 2, 4, 'Dars-e-Nizami,Matric', 'king tms', 'dsfsf', 'dsfds', 'khi', '0356-4564561', 'dsfds', 'dsfdsf', '43543-6456456-4', 'sdfdsf', 'sdfdsf', 'sdfdsf', 'sdfdsf', 1, NULL, '2021-02-24 03:52:51', '2021-03-05 07:37:05'),
(2, 6, 2, 'Dars-e-Nizami,Matric', 'abc', '123', '03/01/2002', 'khi', '0303-3123456', 'khi abc 123', 'fsd 123 abc', '12344-5678956-4', 'no edy', 'n/a', 'n/axVO4KeBoGY', 'n/a', 0, NULL, '2021-03-01 08:37:07', '2021-03-01 10:05:35'),
(3, 7, 4, 'Dars-e-Nizami', 'ZTWwUEDyZA', 'sfnMX2ioDO', 'eoPqPnm5GH', 'd7EOGiRWyJ', '0077386950', '8zy2kd0eIL', 'DrnsFRF4Ds', '64674-5634123-1', 'RjzF4E5rVd', 'XjEBS1Qu6w', 'SzGrtiMMbd', 'd62fSOZPuW', 1, NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:35');

-- --------------------------------------------------------

--
-- Table structure for table `applicant_answers`
--

CREATE TABLE `applicant_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `applicant_answer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `applicant_answers`
--

INSERT INTO `applicant_answers` (`id`, `applicant_id`, `applicant_answer`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'esrewrew', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(2, 1, 'wrewrwe', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(3, 1, 'ewrewr', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(4, 1, 'werewr', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(5, 1, 'ewrewrw', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(6, 1, 'werewrew', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(7, 1, 'werewr', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(8, 2, 'no', NULL, '2021-03-01 08:37:07', '2021-03-01 10:05:41'),
(9, 2, 'ni', NULL, '2021-03-01 08:37:07', '2021-03-01 10:05:46'),
(10, 2, 'no', NULL, '2021-03-01 08:37:07', '2021-03-01 10:05:53'),
(11, 2, 'yes', NULL, '2021-03-01 08:37:07', '2021-03-01 10:06:15'),
(12, 2, '123', NULL, '2021-03-01 08:37:07', '2021-03-01 10:06:24'),
(13, 2, 'abc', NULL, '2021-03-01 08:37:07', '2021-03-01 10:06:24'),
(14, 2, '123', NULL, '2021-03-01 08:37:07', '2021-03-01 10:06:24'),
(15, 3, 'RZRpC6ISNZ', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05'),
(16, 3, 'kUQcVrjC9V', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05'),
(17, 3, 'NETa45v93q', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05'),
(18, 3, 'pTPRcFvn2B', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05'),
(19, 3, 'NQONDGjNDU', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05'),
(20, 3, 'cVuGaw3AKa', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05'),
(21, 3, 'rzgg3cgpz6', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05');

-- --------------------------------------------------------

--
-- Table structure for table `attempts`
--

CREATE TABLE `attempts` (
  `id` int(10) UNSIGNED NOT NULL,
  `entry_test_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  `is_true` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attempts`
--

INSERT INTO `attempts` (`id`, `entry_test_id`, `question_id`, `answer_id`, `is_true`, `deleted_at`, `created_at`, `updated_at`) VALUES
(19, 6, 1, 1, 0, '2021-03-01 07:19:55', '2021-03-01 07:16:14', '2021-03-01 07:19:55'),
(20, 6, 2, 5, 1, '2021-03-01 07:19:55', '2021-03-01 07:16:16', '2021-03-01 07:19:55'),
(21, 7, 1, 1, 0, '2021-03-01 07:23:37', '2021-03-01 07:20:03', '2021-03-01 07:23:37'),
(22, 7, 2, 5, 1, '2021-03-01 07:23:37', '2021-03-01 07:20:05', '2021-03-01 07:23:37'),
(23, 7, 3, 10, 1, '2021-03-01 07:23:37', '2021-03-01 07:20:07', '2021-03-01 07:23:37'),
(24, 7, 4, 13, 0, '2021-03-01 07:23:37', '2021-03-01 07:20:10', '2021-03-01 07:23:37'),
(25, 7, 5, 17, 0, '2021-03-01 07:23:37', '2021-03-01 07:20:14', '2021-03-01 07:23:37'),
(26, 7, 6, 21, 1, '2021-03-01 07:23:37', '2021-03-01 07:20:16', '2021-03-01 07:23:37'),
(27, 7, 7, 25, 0, '2021-03-01 07:23:37', '2021-03-01 07:20:18', '2021-03-01 07:23:37'),
(28, 7, 8, 29, 1, '2021-03-01 07:23:37', '2021-03-01 07:20:20', '2021-03-01 07:23:37'),
(29, 7, 9, 34, 1, '2021-03-01 07:23:37', '2021-03-01 07:20:22', '2021-03-01 07:23:37'),
(30, 9, 1, 1, 0, NULL, '2021-03-01 07:39:35', '2021-03-01 07:39:35'),
(31, 9, 2, 5, 1, NULL, '2021-03-01 07:40:11', '2021-03-01 07:40:11'),
(32, 9, 3, 9, 0, NULL, '2021-03-01 07:40:14', '2021-03-01 07:40:14'),
(33, 9, 4, 13, 0, NULL, '2021-03-01 07:40:16', '2021-03-01 07:40:16'),
(34, 9, 5, 17, 0, NULL, '2021-03-01 07:40:18', '2021-03-01 07:40:18'),
(35, 9, 6, 21, 1, NULL, '2021-03-01 07:40:23', '2021-03-01 07:40:23'),
(36, 10, 1, 1, 0, '2021-03-01 07:54:39', '2021-03-01 07:46:07', '2021-03-01 07:54:39'),
(37, 10, 2, 5, 1, '2021-03-01 07:54:39', '2021-03-01 07:46:11', '2021-03-01 07:54:39'),
(38, 10, 3, 10, 1, '2021-03-01 07:54:39', '2021-03-01 07:46:39', '2021-03-01 07:54:39'),
(39, 10, 4, 13, 0, '2021-03-01 07:54:39', '2021-03-01 07:46:41', '2021-03-01 07:54:39'),
(40, 10, 5, 17, 0, '2021-03-01 07:54:39', '2021-03-01 07:46:43', '2021-03-01 07:54:39'),
(41, 10, 6, 21, 1, '2021-03-01 07:54:39', '2021-03-01 07:46:48', '2021-03-01 07:54:39'),
(42, 10, 7, 25, 0, '2021-03-01 07:54:39', '2021-03-01 07:49:39', '2021-03-01 07:54:39'),
(43, 10, 8, 29, 1, '2021-03-01 07:54:39', '2021-03-01 07:49:40', '2021-03-01 07:54:39'),
(44, 10, 9, 33, 0, '2021-03-01 07:54:39', '2021-03-01 07:49:42', '2021-03-01 07:54:39'),
(45, 11, 1, 1, 0, '2021-03-01 07:55:12', '2021-03-01 07:54:49', '2021-03-01 07:55:12'),
(46, 11, 4, 13, 0, '2021-03-01 07:55:12', '2021-03-01 07:54:51', '2021-03-01 07:55:12'),
(47, 11, 5, 17, 0, '2021-03-01 07:55:12', '2021-03-01 07:54:52', '2021-03-01 07:55:12'),
(48, 11, 6, 21, 1, '2021-03-01 07:55:12', '2021-03-01 07:54:54', '2021-03-01 07:55:12'),
(49, 11, 7, 25, 0, '2021-03-01 07:55:12', '2021-03-01 07:54:57', '2021-03-01 07:55:12'),
(50, 11, 8, 30, 0, '2021-03-01 07:55:12', '2021-03-01 07:54:59', '2021-03-01 07:55:12'),
(51, 11, 9, 33, 0, '2021-03-01 07:55:12', '2021-03-01 07:55:01', '2021-03-01 07:55:12'),
(52, 12, 1, 1, 0, '2021-03-01 07:56:45', '2021-03-01 07:55:52', '2021-03-01 07:56:45'),
(53, 12, 2, 5, 1, '2021-03-01 07:56:45', '2021-03-01 07:55:54', '2021-03-01 07:56:45'),
(54, 12, 3, 10, 1, '2021-03-01 07:56:45', '2021-03-01 07:55:56', '2021-03-01 07:56:45'),
(55, 12, 4, 13, 0, '2021-03-01 07:56:45', '2021-03-01 07:55:59', '2021-03-01 07:56:45'),
(56, 12, 5, 17, 0, '2021-03-01 07:56:45', '2021-03-01 07:56:00', '2021-03-01 07:56:45'),
(57, 12, 6, 21, 1, '2021-03-01 07:56:45', '2021-03-01 07:56:08', '2021-03-01 07:56:45'),
(58, 13, 1, 1, 0, NULL, '2021-03-01 07:57:25', '2021-03-01 07:57:25'),
(59, 13, 2, 5, 1, NULL, '2021-03-01 07:57:27', '2021-03-01 07:57:27'),
(60, 13, 3, 9, 0, NULL, '2021-03-01 07:57:53', '2021-03-01 07:57:53'),
(61, 13, 4, 13, 0, NULL, '2021-03-01 07:57:55', '2021-03-01 07:57:55'),
(62, 13, 5, 17, 0, NULL, '2021-03-01 07:57:57', '2021-03-01 07:57:57'),
(63, 13, 6, 21, 1, NULL, '2021-03-01 07:58:00', '2021-03-01 07:58:00'),
(64, 14, 1, 1, 0, '2021-03-05 02:43:09', '2021-02-28 21:10:44', '2021-03-05 02:43:09'),
(65, 14, 10, 38, 1, '2021-03-05 02:43:09', '2021-02-28 21:21:07', '2021-03-05 02:43:09'),
(66, 14, 12, 48, 1, '2021-03-05 02:43:09', '2021-02-28 21:21:10', '2021-03-05 02:43:09'),
(67, 14, 13, 51, 1, '2021-03-05 02:43:09', '2021-02-28 21:21:19', '2021-03-05 02:43:09'),
(68, 15, 10, 37, 0, '2021-03-02 10:51:19', '2021-03-01 22:49:38', '2021-03-02 10:51:19'),
(69, 15, 11, 44, 0, '2021-03-02 10:51:19', '2021-03-01 22:49:44', '2021-03-02 10:51:19'),
(70, 15, 12, 48, 1, '2021-03-02 10:51:19', '2021-03-01 22:49:49', '2021-03-02 10:51:19'),
(71, 15, 13, 51, 1, '2021-03-02 10:51:19', '2021-03-01 22:49:54', '2021-03-02 10:51:19'),
(72, 16, 10, 37, 0, NULL, '2021-03-01 22:51:23', '2021-03-01 22:51:23'),
(73, 16, 11, 44, 0, NULL, '2021-03-01 22:51:25', '2021-03-01 22:51:25'),
(74, 16, 12, 48, 1, NULL, '2021-03-01 22:51:28', '2021-03-01 22:51:28'),
(75, 16, 13, 52, 0, NULL, '2021-03-01 22:51:30', '2021-03-01 22:51:30'),
(76, 17, 10, 37, 0, '2021-03-05 02:48:39', '2021-03-05 02:43:18', '2021-03-05 02:48:39'),
(77, 17, 11, 42, 0, '2021-03-05 02:48:39', '2021-03-05 02:43:32', '2021-03-05 02:48:39'),
(78, 17, 12, 45, 0, '2021-03-05 02:48:39', '2021-03-05 02:43:35', '2021-03-05 02:48:39'),
(79, 17, 13, 49, 0, '2021-03-05 02:48:39', '2021-03-05 02:48:17', '2021-03-05 02:48:39'),
(80, 18, 10, 37, 0, '2021-03-05 02:52:59', '2021-03-05 02:49:41', '2021-03-05 02:52:59'),
(81, 18, 11, 41, 1, '2021-03-05 02:52:59', '2021-03-05 02:49:47', '2021-03-05 02:52:59'),
(82, 18, 12, 48, 1, '2021-03-05 02:52:59', '2021-03-05 02:49:50', '2021-03-05 02:52:59'),
(83, 18, 13, 49, 0, '2021-03-05 02:52:59', '2021-03-05 02:51:28', '2021-03-05 02:52:59'),
(84, 19, 1, 1, 0, '2021-03-05 07:37:47', '2021-03-05 02:53:11', '2021-03-05 07:37:47'),
(85, 19, 2, 5, 1, '2021-03-05 07:37:47', '2021-03-05 02:53:13', '2021-03-05 07:37:47'),
(86, 19, 3, 10, 1, '2021-03-05 07:37:47', '2021-03-05 02:53:15', '2021-03-05 07:37:47'),
(87, 19, 4, 13, 0, '2021-03-05 07:37:47', '2021-03-05 03:02:04', '2021-03-05 07:37:47'),
(88, 19, 5, 42, 0, '2021-03-05 07:37:47', '2021-03-05 03:21:21', '2021-03-05 07:37:47'),
(89, 19, 6, 45, 0, '2021-03-05 07:37:47', '2021-03-05 03:23:10', '2021-03-05 07:37:47'),
(90, 19, 10, 38, 1, '2021-03-05 07:37:47', '2021-03-05 03:04:56', '2021-03-05 07:37:47'),
(91, 19, 12, 48, 1, '2021-03-05 07:37:47', '2021-03-05 03:21:25', '2021-03-05 07:37:47'),
(92, 19, 13, 49, 0, '2021-03-05 07:37:47', '2021-03-05 03:23:15', '2021-03-05 07:37:47'),
(93, 20, 1, 1, 0, '2021-03-05 09:12:14', '2021-03-04 20:02:57', '2021-03-05 09:12:14'),
(94, 20, 2, 5, 1, '2021-03-05 09:12:14', '2021-03-04 20:04:19', '2021-03-05 09:12:14'),
(95, 20, 3, 10, 1, '2021-03-05 09:12:14', '2021-03-04 20:05:17', '2021-03-05 09:12:14'),
(96, 20, 4, 14, 1, '2021-03-05 09:12:14', '2021-03-04 21:10:51', '2021-03-05 09:12:14'),
(97, 20, 5, 18, 0, '2021-03-05 09:12:14', '2021-03-04 21:10:53', '2021-03-05 09:12:14'),
(98, 20, 6, 21, 1, '2021-03-05 09:12:14', '2021-03-04 21:10:54', '2021-03-05 09:12:14'),
(99, 20, 10, 37, 0, '2021-03-05 09:12:14', '2021-03-04 21:10:56', '2021-03-05 09:12:14'),
(100, 20, 11, 41, 1, '2021-03-05 09:12:14', '2021-03-04 21:10:58', '2021-03-05 09:12:14'),
(101, 20, 12, 45, 0, '2021-03-05 09:12:14', '2021-03-04 21:10:59', '2021-03-05 09:12:14'),
(102, 20, 13, 49, 0, '2021-03-05 09:12:14', '2021-03-04 21:11:01', '2021-03-05 09:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `class_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum_age_limit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maximum_age_limit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quiz_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `random_question` tinyint(1) NOT NULL DEFAULT 1,
  `question_limit` int(11) NOT NULL DEFAULT 20,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_name`, `minimum_age_limit`, `maximum_age_limit`, `quiz_time`, `is_active`, `random_question`, `question_limit`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'پہلی سطح', 'چار سال', 'آٹھ سال', '12:04', 1, 0, 200, NULL, '2021-02-22 10:08:07', '2021-02-26 05:04:54'),
(2, 'دوسری سطح', 'پانچ سال', 'آٹھ سال', '01:10', 1, 1, 6, NULL, '2021-02-23 09:50:08', '2021-03-01 07:55:41'),
(3, 'چھٹی سطح', 'پانچ سال', 'نو سال', '00:49', 1, 1, 50, NULL, '2021-02-25 06:14:00', '2021-02-26 05:11:21'),
(4, 'چوتھی سطح', 'چار سال', 'دس سال', '01:00', 1, 1, 15, NULL, '2021-03-01 08:05:45', '2021-03-05 07:37:40');

-- --------------------------------------------------------

--
-- Table structure for table `class_quiz_questions`
--

CREATE TABLE `class_quiz_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `class_quiz_questions`
--

INSERT INTO `class_quiz_questions` (`id`, `class_id`, `question_id`) VALUES
(103, 2, 1),
(104, 2, 2),
(105, 2, 3),
(106, 2, 4),
(107, 2, 5),
(108, 2, 6),
(127, 4, 1),
(128, 4, 2),
(129, 4, 3),
(130, 4, 4),
(131, 4, 5),
(132, 4, 6),
(133, 4, 10),
(134, 4, 11),
(135, 4, 12),
(136, 4, 13);

-- --------------------------------------------------------

--
-- Table structure for table `entry_tests`
--

CREATE TABLE `entry_tests` (
  `id` int(10) UNSIGNED NOT NULL,
  `class_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_quiz_start` int(11) NOT NULL DEFAULT 0,
  `current_day` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quiz_end` int(11) NOT NULL DEFAULT 0,
  `is_auto_end` int(11) NOT NULL DEFAULT 0,
  `quiz_start_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quiz_end_date` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `entry_tests`
--

INSERT INTO `entry_tests` (`id`, `class_id`, `user_id`, `is_quiz_start`, `current_day`, `quiz_end`, `is_auto_end`, `quiz_start_time`, `quiz_end_date`, `deleted_at`, `created_at`, `updated_at`) VALUES
(6, 2, 2, 1, '01', 1, 1, '12:15:46', '2021-03-01 12:17:26', '2021-03-01 07:19:55', '2021-03-01 07:15:46', '2021-03-01 07:19:55'),
(7, 2, 2, 1, '01', 1, 0, '12:20:00', '2021-03-01 12:20:22', '2021-03-01 07:23:37', '2021-03-01 07:20:00', '2021-03-01 07:23:37'),
(8, 2, 2, 1, '01', 1, 1, '12:23:40', '2021-03-01 12:25:09', '2021-03-01 12:25:52', '2021-03-01 07:23:40', '2021-03-01 07:25:09'),
(9, 2, 2, 1, '01', 0, 0, '12:26:02', '2021-03-01 12:34:57', '2021-03-01 12:44:55', '2021-03-01 07:26:02', '2021-03-01 07:34:57'),
(10, 2, 2, 1, '01', 1, 1, '12:45:33', '2021-03-01 12:49:42', '2021-03-01 07:54:39', '2021-03-01 07:45:33', '2021-03-01 07:54:39'),
(11, 2, 2, 1, '01', 1, 0, '12:54:43', '2021-03-01 12:55:01', '2021-03-01 07:55:12', '2021-03-01 07:54:43', '2021-03-01 07:55:12'),
(12, 2, 2, 1, '01', 0, 0, '12:55:46', NULL, '2021-03-01 07:56:45', '2021-03-01 07:55:46', '2021-03-01 07:56:45'),
(13, 2, 2, 1, '01', 1, 0, '12:57:23', '2021-03-01 12:58:00', '2021-03-01 14:14:32', '2021-03-01 07:57:23', '2021-03-01 07:58:00'),
(14, 4, 2, 1, '01', 1, 0, '02:20', '2021-03-01 02:21:19', '2021-03-05 02:43:09', '2021-02-28 21:10:40', '2021-03-05 02:43:09'),
(15, 4, 7, 1, '02', 1, 0, '03:42', '2021-03-02 03:49:54', '2021-03-02 10:51:19', '2021-03-01 22:42:39', '2021-03-02 10:51:19'),
(16, 4, 7, 1, '02', 1, 0, '03:51', '2021-03-02 03:51:30', NULL, '2021-03-01 22:51:21', '2021-03-02 10:51:30'),
(17, 4, 2, 1, '05', 1, 0, '07:43', '2021-03-05 07:48:17', '2021-03-05 02:48:39', '2021-03-05 02:43:12', '2021-03-05 02:48:39'),
(18, 4, 2, 1, '05', 1, 0, '07:49', '2021-03-05 07:51:28', '2021-03-05 02:52:59', '2021-03-05 02:49:38', '2021-03-05 02:52:59'),
(19, 4, 2, 1, '05', 1, 0, '07:53', '2021-03-05 08:23:15', '2021-03-05 07:37:47', '2021-03-05 02:53:09', '2021-03-05 07:37:47'),
(20, 4, 2, 1, '05', 1, 0, '12:37', '2021-03-05 02:11:01', '2021-03-05 09:12:14', '2021-03-05 07:37:49', '2021-03-05 09:12:14'),
(21, 4, 2, 1, '05', 0, 0, '02:12', NULL, NULL, '2021-03-04 21:12:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `guardians`
--

CREATE TABLE `guardians` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `guardian_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guardian_f_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicant_relation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_cnic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `another_guardian_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `guardians`
--

INSERT INTO `guardians` (`id`, `applicant_id`, `guardian_name`, `guardian_f_name`, `city`, `applicant_relation`, `occupation`, `position`, `phone`, `father_cnic`, `address`, `another_guardian_name`, `mobile_no`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'king tms', 'sdfds', 'khi', 'sfdsf', 'sdfd', 'sfdsf', '0356-4646456', '98798-7645213-4', 'dsfdsf', 'dsfdsfds', '0356-4564561', NULL, '2021-02-24 03:52:51', '2021-02-24 03:52:51'),
(2, 2, 'name co', 'fatehr name in field', 'user city karachi', 'parent', 'student', 'stufdent123', '0303-3123456', '12345-6789896-2', 'abc', 'bddsdsfcchhyyii', '0303-3123456', NULL, '2021-03-01 08:37:07', '2021-03-01 10:05:35'),
(3, 3, 'ZTWwUEDyZA', 'b1i8W3tAg5', 'd7EOGiRWyJ', 'KVd3Aj6jUC', '4TqDFTYeRc', 'WHrEh9GyZH', '0354-8589291', '56476-5464156-3', 'ft5Ez4s2Zo', 'Ls7PWe6WhH', '0077386950', NULL, '2021-03-02 10:42:05', '2021-03-02 10:42:05');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_01_22_131707_create_table_question', 1),
(5, '2021_01_22_131741_create_table_class', 1),
(6, '2021_01_22_131804_create_table_subject', 1),
(7, '2021_01_22_131823_create_table_answer', 1),
(8, '2021_01_22_131847_create_table_question_quote', 1),
(9, '2021_01_22_132006_create_table_test', 1),
(10, '2021_01_25_121211_create_table_applicants', 1),
(11, '2021_01_25_123002_create_table_guardians', 1),
(12, '2021_01_26_155332_create_question_options', 1),
(13, '2021_01_28_110313_create_sessions_table', 1),
(14, '2021_01_28_152235_entry_tests', 1),
(15, '2021_01_29_142913_attempts', 1),
(16, '2021_02_08_105905_create_roles', 1),
(17, '2021_02_08_124935_create_applicant_answers', 1),
(19, '2021_02_22_110117_create_role_permissions_table', 3),
(23, '2021_02_24_152012_create_previous_quiz_attempts_table', 5),
(24, '2021_02_22_105442_create_permissions_table', 6),
(25, '2021_02_26_095724_create_class_quiz_questions_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `created_at`) VALUES
(1, 'saeed.abdullah@dwtltd.com1', '$2y$10$5VpYakcILTUrmTZep7b5yOy6Mcddu6vSXfZKsvWTSocVTN.jKVkBm', '2021-02-26 04:44:16');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `title`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Class Management', 1, NULL, NULL, NULL),
(2, 'Add Class', 1, NULL, NULL, NULL),
(3, 'Edit Class', 1, NULL, NULL, NULL),
(4, 'Create Class', 1, NULL, NULL, NULL),
(5, 'Update Class', 1, NULL, NULL, NULL),
(6, 'Delete Cass', 1, NULL, NULL, NULL),
(7, 'Subjects', 1, NULL, NULL, NULL),
(8, 'Add Subject', 1, NULL, NULL, NULL),
(9, 'Edit Subject', 1, NULL, NULL, NULL),
(10, 'Create Subject', 1, NULL, NULL, NULL),
(11, 'Update Subject', 1, NULL, NULL, NULL),
(12, 'Delete Subject', 1, NULL, NULL, NULL),
(13, 'Status Update Subject', 1, NULL, NULL, NULL),
(14, 'Questions', 1, NULL, NULL, NULL),
(15, 'Add Question', 1, NULL, NULL, NULL),
(16, 'Edit Question', 1, NULL, NULL, NULL),
(17, 'Create Question', 1, NULL, NULL, NULL),
(18, 'Update Question', 1, NULL, NULL, NULL),
(19, 'Delete Question', 1, NULL, NULL, NULL),
(20, 'Status Update Question', 1, NULL, NULL, NULL),
(21, 'Applicants', 1, NULL, NULL, NULL),
(22, 'Add Applicant', 1, NULL, NULL, NULL),
(23, 'Edit Applicant', 1, NULL, NULL, NULL),
(24, 'Create Applicant', 1, NULL, NULL, NULL),
(25, 'Update Applicant', 1, NULL, NULL, NULL),
(26, 'Status Update Applicant', 1, NULL, NULL, NULL),
(27, 'Results', 1, NULL, NULL, NULL),
(28, 'Edit Result', 1, NULL, NULL, NULL),
(29, 'User Edit Result', 1, NULL, NULL, NULL),
(30, 'Users Management', 1, NULL, NULL, NULL),
(31, 'Status Update User', 1, NULL, NULL, NULL),
(32, 'Role Update User', 1, NULL, NULL, NULL),
(33, 'Roles Management', 1, NULL, NULL, NULL),
(34, 'Permission Management', 1, NULL, NULL, NULL),
(35, 'Add Permission', 1, NULL, NULL, NULL),
(36, 'Edit Permission', 1, NULL, NULL, NULL),
(37, 'Create Permission', 1, NULL, NULL, NULL),
(38, 'Update Permission', 1, NULL, NULL, NULL),
(39, 'Role Permissions Management', 1, NULL, NULL, NULL),
(40, 'Update Role Permission', 1, NULL, NULL, NULL),
(41, 'Result Detail', 1, NULL, NULL, NULL),
(42, 'Start Quiz', 1, NULL, NULL, NULL),
(43, 'Quiz', 1, NULL, '2021-03-02 03:30:28', '2021-03-02 03:30:28');

-- --------------------------------------------------------

--
-- Table structure for table `previous_quiz_attempts`
--

CREATE TABLE `previous_quiz_attempts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `attempt_id` int(11) DEFAULT NULL,
  `entry_test_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer_id` int(11) DEFAULT NULL,
  `is_true` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `previous_quiz_attempts`
--

INSERT INTO `previous_quiz_attempts` (`id`, `user_id`, `class_id`, `attempt_id`, `entry_test_id`, `question_id`, `answer_id`, `is_true`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 9, 1, 1, 1, 0, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(2, 2, 2, 10, 1, 2, 5, 1, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(3, 2, 2, 11, 1, 3, 10, 1, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(4, 2, 2, 12, 1, 4, 14, 1, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(5, 2, 2, 13, 1, 5, 17, 0, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(6, 2, 2, 14, 1, 6, 21, 1, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(7, 2, 2, 15, 1, 7, 26, 0, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(8, 2, 2, 16, 1, 8, 29, 1, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(9, 2, 2, 17, 1, 9, 33, 0, NULL, '2021-03-01 06:53:58', '2021-03-01 06:53:58'),
(10, 2, 2, 1, 2, 1, 1, 0, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(11, 2, 2, 2, 2, 2, 5, 1, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(12, 2, 2, 3, 2, 3, 9, 0, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(13, 2, 2, 4, 2, 4, 13, 0, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(14, 2, 2, 5, 2, 5, 17, 0, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(15, 2, 2, 6, 2, 6, 21, 1, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(16, 2, 2, 7, 2, 7, 26, 0, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(17, 2, 2, 8, 2, 8, 29, 1, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(18, 2, 2, 9, 2, 9, 34, 1, NULL, '2021-03-01 07:05:50', '2021-03-01 07:05:50'),
(19, 2, 2, 19, 6, 1, 1, 0, NULL, '2021-03-01 07:19:55', '2021-03-01 07:19:55'),
(20, 2, 2, 20, 6, 2, 5, 1, NULL, '2021-03-01 07:19:55', '2021-03-01 07:19:55'),
(21, 2, 2, 21, 7, 1, 1, 0, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(22, 2, 2, 22, 7, 2, 5, 1, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(23, 2, 2, 23, 7, 3, 10, 1, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(24, 2, 2, 24, 7, 4, 13, 0, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(25, 2, 2, 25, 7, 5, 17, 0, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(26, 2, 2, 26, 7, 6, 21, 1, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(27, 2, 2, 27, 7, 7, 25, 0, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(28, 2, 2, 28, 7, 8, 29, 1, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(29, 2, 2, 29, 7, 9, 34, 1, NULL, '2021-03-01 07:23:37', '2021-03-01 07:23:37'),
(30, 2, 2, 36, 10, 1, 1, 0, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(31, 2, 2, 37, 10, 2, 5, 1, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(32, 2, 2, 38, 10, 3, 10, 1, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(33, 2, 2, 39, 10, 4, 13, 0, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(34, 2, 2, 40, 10, 5, 17, 0, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(35, 2, 2, 41, 10, 6, 21, 1, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(36, 2, 2, 42, 10, 7, 25, 0, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(37, 2, 2, 43, 10, 8, 29, 1, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(38, 2, 2, 44, 10, 9, 33, 0, NULL, '2021-03-01 07:54:39', '2021-03-01 07:54:39'),
(39, 2, 2, 45, 11, 1, 1, 0, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(40, 2, 2, 46, 11, 4, 13, 0, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(41, 2, 2, 47, 11, 5, 17, 0, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(42, 2, 2, 48, 11, 6, 21, 1, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(43, 2, 2, 49, 11, 7, 25, 0, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(44, 2, 2, 50, 11, 8, 30, 0, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(45, 2, 2, 51, 11, 9, 33, 0, NULL, '2021-03-01 07:55:12', '2021-03-01 07:55:12'),
(46, 2, 2, 52, 12, 1, 1, 0, NULL, '2021-03-01 07:56:45', '2021-03-01 07:56:45'),
(47, 2, 2, 53, 12, 2, 5, 1, NULL, '2021-03-01 07:56:45', '2021-03-01 07:56:45'),
(48, 2, 2, 54, 12, 3, 10, 1, NULL, '2021-03-01 07:56:45', '2021-03-01 07:56:45'),
(49, 2, 2, 55, 12, 4, 13, 0, NULL, '2021-03-01 07:56:45', '2021-03-01 07:56:45'),
(50, 2, 2, 56, 12, 5, 17, 0, NULL, '2021-03-01 07:56:45', '2021-03-01 07:56:45'),
(51, 2, 2, 57, 12, 6, 21, 1, NULL, '2021-03-01 07:56:45', '2021-03-01 07:56:45'),
(52, 7, 4, 68, 15, 10, 37, 0, NULL, '2021-03-02 10:51:19', '2021-03-02 10:51:19'),
(53, 7, 4, 69, 15, 11, 44, 0, NULL, '2021-03-02 10:51:19', '2021-03-02 10:51:19'),
(54, 7, 4, 70, 15, 12, 48, 1, NULL, '2021-03-02 10:51:19', '2021-03-02 10:51:19'),
(55, 7, 4, 71, 15, 13, 51, 1, NULL, '2021-03-02 10:51:19', '2021-03-02 10:51:19'),
(56, 2, 4, 64, 14, 1, 1, 0, NULL, '2021-03-05 02:43:09', '2021-03-05 02:43:09'),
(57, 2, 4, 65, 14, 10, 38, 1, NULL, '2021-03-05 02:43:09', '2021-03-05 02:43:09'),
(58, 2, 4, 66, 14, 12, 48, 1, NULL, '2021-03-05 02:43:09', '2021-03-05 02:43:09'),
(59, 2, 4, 67, 14, 13, 51, 1, NULL, '2021-03-05 02:43:09', '2021-03-05 02:43:09'),
(60, 2, 4, 76, 17, 10, 37, 0, NULL, '2021-03-05 02:48:39', '2021-03-05 02:48:39'),
(61, 2, 4, 77, 17, 11, 42, 0, NULL, '2021-03-05 02:48:39', '2021-03-05 02:48:39'),
(62, 2, 4, 78, 17, 12, 45, 0, NULL, '2021-03-05 02:48:39', '2021-03-05 02:48:39'),
(63, 2, 4, 79, 17, 13, 49, 0, NULL, '2021-03-05 02:48:39', '2021-03-05 02:48:39'),
(64, 2, 4, 80, 18, 10, 37, 0, NULL, '2021-03-05 02:52:59', '2021-03-05 02:52:59'),
(65, 2, 4, 81, 18, 11, 41, 1, NULL, '2021-03-05 02:52:59', '2021-03-05 02:52:59'),
(66, 2, 4, 82, 18, 12, 48, 1, NULL, '2021-03-05 02:52:59', '2021-03-05 02:52:59'),
(67, 2, 4, 83, 18, 13, 49, 0, NULL, '2021-03-05 02:52:59', '2021-03-05 02:52:59'),
(68, 2, 4, 84, 19, 1, 1, 0, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(69, 2, 4, 85, 19, 2, 5, 1, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(70, 2, 4, 86, 19, 3, 10, 1, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(71, 2, 4, 87, 19, 4, 13, 0, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(72, 2, 4, 88, 19, 5, 42, 0, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(73, 2, 4, 89, 19, 6, 45, 0, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(74, 2, 4, 90, 19, 10, 38, 1, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(75, 2, 4, 91, 19, 12, 48, 1, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(76, 2, 4, 92, 19, 13, 49, 0, NULL, '2021-03-05 07:37:47', '2021-03-05 07:37:47'),
(77, 2, 4, 93, 20, 1, 1, 0, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(78, 2, 4, 94, 20, 2, 5, 1, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(79, 2, 4, 95, 20, 3, 10, 1, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(80, 2, 4, 96, 20, 4, 14, 1, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(81, 2, 4, 97, 20, 5, 18, 0, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(82, 2, 4, 98, 20, 6, 21, 1, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(83, 2, 4, 99, 20, 10, 37, 0, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(84, 2, 4, 100, 20, 11, 41, 1, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(85, 2, 4, 101, 20, 12, 45, 0, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14'),
(86, 2, 4, 102, 20, 13, 49, 0, NULL, '2021-03-05 09:12:14', '2021-03-05 09:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question_content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(11) NOT NULL,
  `language_code` enum('en','ur') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `is_active` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_content`, `subject_id`, `language_code`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Ap ka name kia hai?', 1, 'en', '1', NULL, '2021-02-24 05:41:47', '2021-02-24 05:41:51'),
(2, 'Ap kahan se ho?', 1, 'en', '1', NULL, '2021-02-24 05:42:28', '2021-02-24 05:42:28'),
(3, 'Ap ka office kahan hai?', 1, 'en', '1', NULL, '2021-02-24 05:43:38', '2021-02-24 05:43:38'),
(4, 'Pakistan east country is?', 1, 'en', '1', NULL, '2021-02-24 05:44:25', '2021-03-01 05:39:13'),
(5, 'Capital Of Pakistan is?', 1, 'en', '1', NULL, '2021-02-24 05:51:55', '2021-03-01 05:38:31'),
(6, 'Pakistan is located in ??', 1, 'en', '1', NULL, '2021-02-24 05:53:27', '2021-03-01 05:37:41'),
(7, 'Ap ka name kia hai?', 2, 'en', '1', NULL, '2021-02-24 05:54:06', '2021-02-24 05:54:06'),
(8, 'wah kia hai?', 2, 'en', '1', NULL, '2021-02-24 05:55:40', '2021-02-25 04:57:55'),
(9, 'اپ لکا نامع کیا حای؟؟', 1, 'ur', '1', NULL, '2021-02-25 07:24:25', '2021-02-25 07:24:25'),
(10, 'The term ‘Computer’ is derived from?', 5, 'en', '1', NULL, '2021-03-01 08:19:10', '2021-03-01 08:19:10'),
(11, 'Who is the father of Computer?', 5, 'en', '1', NULL, '2021-03-01 08:19:38', '2021-03-01 10:12:52'),
(12, 'The basic operations performed by a computer are__________?', 5, 'en', '1', NULL, '2021-03-01 08:20:11', '2021-03-01 10:12:50'),
(13, 'Who is the father of Internet ?', 5, 'en', '1', NULL, '2021-03-01 08:20:57', '2021-03-01 08:20:57');

-- --------------------------------------------------------

--
-- Table structure for table `question_options`
--

CREATE TABLE `question_options` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `option` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_id` int(11) NOT NULL,
  `is_correct` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question_quotes`
--

CREATE TABLE `question_quotes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `number_of_question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'admin', '1', NULL, '2021-02-22 08:12:12', '2021-02-22 06:42:16'),
(2, 'Student', '1', NULL, '2021-02-22 08:12:35', '2021-02-22 06:42:14'),
(3, 'teacher', '1', NULL, '2021-02-22 08:12:35', '2021-02-22 06:42:14');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(548, 1, 42, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(549, 1, 41, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(550, 1, 40, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(551, 1, 39, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(552, 1, 38, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(553, 1, 37, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(554, 1, 36, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(555, 1, 35, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(556, 1, 34, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(557, 1, 33, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(558, 1, 32, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(559, 1, 31, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(560, 1, 30, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(561, 1, 29, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(562, 1, 28, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(563, 1, 27, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(564, 1, 26, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(565, 1, 25, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(566, 1, 24, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(567, 1, 23, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(568, 1, 22, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(569, 1, 21, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(570, 1, 20, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(571, 1, 19, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(572, 1, 18, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(573, 1, 17, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(574, 1, 16, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(575, 1, 15, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(576, 1, 14, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(577, 1, 13, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(578, 1, 12, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(579, 1, 11, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(580, 1, 10, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(581, 1, 9, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(582, 1, 8, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(583, 1, 7, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(584, 1, 6, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(585, 1, 5, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(586, 1, 4, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(587, 1, 3, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(588, 1, 2, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(589, 1, 1, '2021-02-25 06:41:48', '2021-02-25 06:41:48'),
(706, 2, 43, '2021-03-02 03:48:27', '2021-03-02 03:48:27'),
(707, 2, 42, '2021-03-02 03:48:27', '2021-03-02 03:48:27'),
(708, 2, 41, '2021-03-02 03:48:27', '2021-03-02 03:48:27'),
(709, 2, 24, '2021-03-02 03:48:27', '2021-03-02 03:48:27'),
(710, 2, 22, '2021-03-02 03:48:27', '2021-03-02 03:48:27'),
(711, 2, 21, '2021-03-02 03:48:27', '2021-03-02 03:48:27'),
(741, 3, 39, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(742, 3, 38, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(743, 3, 37, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(744, 3, 24, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(745, 3, 22, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(746, 3, 21, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(747, 3, 20, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(748, 3, 19, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(749, 3, 18, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(750, 3, 17, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(751, 3, 16, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(752, 3, 15, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(753, 3, 14, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(754, 3, 13, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(755, 3, 11, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(756, 3, 10, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(757, 3, 8, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(758, 3, 7, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(759, 3, 6, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(760, 3, 5, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(761, 3, 4, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(762, 3, 3, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(763, 3, 2, '2021-03-02 04:33:01', '2021-03-02 04:33:01'),
(764, 3, 1, '2021-03-02 04:33:01', '2021-03-02 04:33:01');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_id` int(11) NOT NULL,
  `is_active` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `title`, `class_id`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'English', 4, '1', NULL, '2021-02-23 10:07:46', '2021-03-05 02:49:24'),
(2, 'Sindhi', 2, '1', NULL, '2021-02-23 10:22:55', '2021-02-26 04:45:13'),
(3, 'Results', 2, '1', '2021-02-23 10:23:11', '2021-02-23 10:23:04', '2021-02-23 10:23:11'),
(4, 'Mathematics', 4, '1', NULL, '2021-02-25 10:59:38', '2021-03-05 02:49:16'),
(5, 'Computer', 4, '1', NULL, '2021-03-01 08:18:33', '2021-03-01 08:18:33');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `class_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `is_active`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Abdullah Saeed', 'saeed.abdullah@dwtltd.com', '2021-02-22 08:10:00', '$2y$10$OcWi3lUm4mf9vCpLeUotIe1I10y1DPLUjLeR3Mba5SlLD.DDzElw6', 1, 1, 'sCX4O4na6bX5zpFtat3bznZWVsFIKLR32bwK4VLNFvhEo2HmgRGUR2UoiX3z', NULL, '2021-02-22 08:10:00', '2021-02-22 04:42:39'),
(2, 'Asad', 'asad.kamran@dwtltd.com', '2021-02-22 08:10:00', '$2y$10$OcWi3lUm4mf9vCpLeUotIe1I10y1DPLUjLeR3Mba5SlLD.DDzElw6', 2, 1, 'YzPaHp3V2QuPumNOGpaKZPTGBzhnEWiIaQ5Orj0Kzvifhi5pDWYaM69NkXwY', NULL, '2021-02-22 08:10:00', '2021-03-05 07:36:47'),
(3, 'Abdullah2', 'saeed.abdullah@dwtltd.com2', '2021-02-22 08:10:00', '$2y$10$OcWi3lUm4mf9vCpLeUotIe1I10y1DPLUjLeR3Mba5SlLD.DDzElw6', 2, 1, 'OJidHih4eOQJSC0lkziBo6X1dveNCISYa4VlLnnXy6lHkxwAdzG8g0YhWuGH', NULL, '2021-02-22 08:10:00', '2021-02-22 03:54:20'),
(4, 'Abdullah3', 'saeed.abdullah@dwtltd.com3', '2021-02-22 08:10:00', '$2y$10$OcWi3lUm4mf9vCpLeUotIe1I10y1DPLUjLeR3Mba5SlLD.DDzElw6', 2, 1, '3rmGZmkBi8UAufY6W2klhWkpUSfiLKtLZzQzPAnZwKwHRgOCLkNRU6qst0C3', NULL, '2021-02-22 08:10:00', '2021-02-22 03:56:17'),
(5, 'Abdullah4', 'saeed.abdullah@dwtltd.com4', '2021-02-22 08:10:00', '$2y$10$OcWi3lUm4mf9vCpLeUotIe1I10y1DPLUjLeR3Mba5SlLD.DDzElw6', 2, 1, '9u1MUNSa5cHcL7NvVpDUmrqeOZy21fyQgbd1ieGKP55WEyugSAsERtYS0yrG', NULL, '2021-02-22 08:10:00', '2021-03-05 02:41:57'),
(6, 'asad test', 'berehe1111@mailnest.net', NULL, '$2y$10$r9hwNYrlu4hSPCYITXMzuusdnSmlmbMyiyLTUKCREWraAzigcwnGK', 2, 1, '17hq49vYcs1jUwvOm5Nc4DmpKPALrCG8TuP9D5tOZfAUGhKUfLcGTgAIY6j1', NULL, '2021-03-01 08:27:01', '2021-03-05 02:42:00'),
(7, 'jivaji1572@netjook.com', 'jivaji1572@netjook.com', NULL, '$2y$10$JR8AN.Nylrtp6ZJkwtZfN.bL/QSlKVyFaswilYj2oMoUasSh3EZ.i', 2, 1, NULL, NULL, '2021-03-02 10:40:38', '2021-03-02 10:40:38'),
(8, 'test@gmail.com', 'test@gmail.com', NULL, '$2y$10$.WqyyxrA6BRmXL7JbgEtBuI0/srNyuslGmR8AURzdGHG1yNfaCtHO', 2, 1, NULL, NULL, '2021-03-05 03:30:56', '2021-03-05 03:30:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `applicant_answers`
--
ALTER TABLE `applicant_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attempts`
--
ALTER TABLE `attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_quiz_questions`
--
ALTER TABLE `class_quiz_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entry_tests`
--
ALTER TABLE `entry_tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guardians`
--
ALTER TABLE `guardians`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `previous_quiz_attempts`
--
ALTER TABLE `previous_quiz_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_options`
--
ALTER TABLE `question_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_quotes`
--
ALTER TABLE `question_quotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `applicant_answers`
--
ALTER TABLE `applicant_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `attempts`
--
ALTER TABLE `attempts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `class_quiz_questions`
--
ALTER TABLE `class_quiz_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `entry_tests`
--
ALTER TABLE `entry_tests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guardians`
--
ALTER TABLE `guardians`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `previous_quiz_attempts`
--
ALTER TABLE `previous_quiz_attempts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `question_options`
--
ALTER TABLE `question_options`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `question_quotes`
--
ALTER TABLE `question_quotes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=765;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
