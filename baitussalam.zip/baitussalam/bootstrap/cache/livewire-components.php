<?php return array (
  'start-quiz' => 'App\\Http\\Livewire\\StartQuiz',
);