<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableApplicants extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applicants', function (Blueprint $table) {
            $table->id();
            $table->Integer('user_id');
            $table->Integer('class_id');
            $table->string('class_selection');
            $table->string('name');
            $table->string('father_name');
            $table->string('dob');
            $table->string('city');
            $table->string('phone');
            $table->string('address');
            $table->string('permanent_address');
            $table->string('cnic');
            $table->string('islamic_education');
            $table->string('previous_institute_name');
            $table->string('previous_institute_left_reason');
            $table->string('basic_education');
            $table->tinyInteger('is_allowed')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
   public function down()
    {
        Schema::dropIfExists('applicants');
    }
}
