<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableGuardians extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('guardians', function (Blueprint $table) {
            $table->id();
            $table->Integer('applicant_id');
            $table->string('guardian_name');
            $table->string('guardian_f_name');
            $table->string('city');
            $table->string('applicant_relation');
            $table->string('occupation');
            $table->string('position');
            $table->string('phone');
            $table->string('father_cnic');
            $table->string('address');
            $table->string('another_guardian_name');
            $table->string('mobile_no');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('guardians');
    }
}
