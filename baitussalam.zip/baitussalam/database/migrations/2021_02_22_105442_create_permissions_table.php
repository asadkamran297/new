<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePermissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->boolean('is_active')->default(1);
            $table->softDeletes();
            $table->timestamps();
        });

        /*Insert data*/
        DB::table('permissions')->insert([
            [
                'title' => 'Class Management',
                'is_active' => '1'
            ],

            [
                'title' => 'Add Class',
                'is_active' => '1'
            ],

            [
                'title' => 'Edit Class',
                'is_active' => '1'
            ],
            [
                'title' => 'Create Class',
                'is_active' => '1'
            ],
            [
                'title' => 'Update Class',
                'is_active' => '1'
            ],
            [
                'title' => 'Delete Cass',
                'is_active' => '1'
            ],
            [
                'title' => 'Subjects',
                'is_active' => '1'
            ],
            [
                'title' => 'Add Subject',
                'is_active' => '1'
            ],[
                'title' => 'Edit Subject',
                'is_active' => '1'
            ],[
                'title' => 'Create Subject',
                'is_active' => '1'
            ],[
                'title' => 'Update Subject',
                'is_active' => '1'
            ],[
                'title' => 'Delete Subject',
                'is_active' => '1'
            ],[
                'title' => 'Status Update Subject',
                'is_active' => '1'
            ],[
                'title' => 'Questions',
                'is_active' => '1'
            ],[
                'title' => 'Add Question',
                'is_active' => '1'
            ],[
                'title' => 'Edit Question',
                'is_active' => '1'
            ],[
                'title' => 'Create Question',
                'is_active' => '1'
            ],[
                'title' => 'Update Question',
                'is_active' => '1'
            ],[
                'title' => 'Delete Question',
                'is_active' => '1'
            ],[
                'title' => 'Status Update Question',
                'is_active' => '1'
            ],[
                'title' => 'Applicants',
                'is_active' => '1'
            ],[
                'title' => 'Add Applicant',
                'is_active' => '1'
            ],[
                'title' => 'Edit Applicant',
                'is_active' => '1'
            ],[
                'title' => 'Create Applicant',
                'is_active' => '1'
            ],[
                'title' => 'Update Applicant',
                'is_active' => '1'
            ],[
                'title' => 'Status Update Applicant',
                'is_active' => '1'
            ],[
                'title' => 'Results',
                'is_active' => '1'
            ],[
                'title' => 'Edit Result',
                'is_active' => '1'
            ],[
                'title' => 'User Edit Result',
                'is_active' => '1'
            ],[
                'title' => 'Users Management',
                'is_active' => '1'
            ],[
                'title' => 'Status Update User',
                'is_active' => '1'
            ],[
                'title' => 'Role Update User',
                'is_active' => '1'
            ],[
                'title' => 'Roles Management',
                'is_active' => '1'
            ],[
                'title' => 'Permission Management',
                'is_active' => '1'
            ],[
                'title' => 'Add Permission',
                'is_active' => '1'
            ],[
                'title' => 'Edit Permission',
                'is_active' => '1'
            ],[
                'title' => 'Create Permission',
                'is_active' => '1'
            ],[
                'title' => 'Update Permission',
                'is_active' => '1'
            ],[
                'title' => 'Role Permissions Management',
                'is_active' => '1'
            ],[
                'title' => 'Update Role Permission',
                'is_active' => '1'
            ],[
                'title' => 'Result Detail',
                'is_active' => '1'
            ],[
                'title' => 'Start Quiz',
                'is_active' => '1'
            ],
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('permissions');
    }
}
