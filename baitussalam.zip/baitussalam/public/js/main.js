document.querySelector('.menu-short').addEventListener('click', (e) => {
    if (!document.querySelector('.custom-navbar').classList.contains('active')) {
        document.querySelector('.shortm-arrow').classList.remove('fa-arrow-right');
        document.querySelector('.shortm-arrow').classList.add('fa-arrow-left');
        document.querySelector('.custom-navbar').classList.add('active');
    } else {
        document.querySelector('.shortm-arrow').classList.remove('fa-arrow-left');
        document.querySelector('.shortm-arrow').classList.add('fa-arrow-right');
        document.querySelector('.custom-navbar').classList.remove('active');
    }
})