@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>{{__('lang.applicant_data')}}</h4>
        {{-- @can('applicantAdd', '22')
        <a class="btn btn-primary btn-global" href="{{url('AdmissionForm')}}">{{__('lang.add_applicant_form')}}</a>
        @endcan --}}
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{ __('lang.id')}}</th>
                                <th>{{ __('lang.class_name')}}</th>
                                <th>{{ __('lang.name')}}</th>
                                <th>{{ __('lang.father_name')}}</th>
                                <th>{{ __('lang.city')}}</th>
                                <th>{{ __('lang.phone_number')}}</th>
                                <th>{{ __('lang.cnic')}}</th>
                                <th>{{ __('lang.date')}}</th>
                                @can('applicantStatusUpdate','26')
                                <th>{{ __('lang.allow_applicant')}}</th>
                                @endcan
                                @can('applicantEdit', '23')
                                <th></th>
                                @endcan
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($applicants as $row)
                            <tr>
                                <th>{{isset($row->id)?$row->id:''}}</th>
                                <td>{{isset($row->classes->class_name)?$row->classes->class_name:''}}</td>
                                <td>{{isset($row->name)?$row->name:''}}</td>
                                <td>{{isset($row->father_name)?$row->father_name:''}}</td>
                                <td>{{isset($row->city)?$row->city:''}}</td>
                                <td>{{isset($row->phone)?$row->phone:''}}</td>
                                <td>{{isset($row->cnic)?$row->cnic:''}}</td>
                                <td>{{date('d-m-Y',strtotime($row->created_at))}}</td>
                                 @can('applicantStatusUpdate','26')
                                <td>
                                    @if($row->is_allowed==1)
                                    <span class="badge badge-success">{{__('lang.active')}}</span>
                                    @else 
                                    <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                                    @endif
                                    <input type="checkbox" id="myCheck" onclick='is_allowed("{{$row->id}}",this)' {{(isset($row->is_allowed) && $row->is_allowed == 1 )?'checked':'' }}>
                                </td>
                                @endcan
                                @can('applicantEdit', '23')
                                <td>
                                    <a class="btn btn-primary btn-global-icon-outline" href="edit-admission-form/{{$row->id}}" title="{{__('lang.edit')}}"><i class="fa fa-pencil"></i></a> 
                                </td>
                                @endcan
                            </tr>
                            @endforeach                  
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
@parent
<script>
    function is_allowed(applicant_id,instance){
        var checkBox = $(instance).is(':checked'); 
        $.ajax({
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            type: "GET",
            url: '{{url('/admin/is-allowed')}}',
            data: { status  :checkBox,applicant_id: applicant_id }, 
            success: function( msg ) {
                location.reload();
            }
        }); 
    } 
</script>
@endsection         
