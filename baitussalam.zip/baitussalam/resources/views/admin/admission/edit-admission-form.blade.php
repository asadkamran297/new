@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>{{__('lang.admission_heading')}}</h4>
    </div>
    <div class="container admissionf-page">
        <div class="card">
            <div class="card-body">
                <form method="post" action="{{url('admin/update-admission-form')}}" autocomplete="off">
                  <input type="hidden" name="applicant_id" value="{{$applicant_id}}">
                    @csrf
                    <div class="form-row">
                      @php
                      $c_sec = explode(',',$app->class_selection);
                      @endphp
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.dars_nizami')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.dars_nizami')}}" {{ in_array(__('lang.dars_nizami'),$c_sec) ? "checked" : "" }}>
                                @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.matric')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.matric')}}" {{ in_array(__('lang.matric'),$c_sec) ? "checked" : "" }}>
                                @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.qadeem')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.qadeem')}}" {{ in_array(__('lang.qadeem'),$c_sec) ? "checked" : "" }}>
                                @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.jadeed')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.jadeed')}}" {{ in_array(__('lang.jadeed'),$c_sec) ? "checked" : "" }}>
                                @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input {{$lang_field}}" name="n_name" placeholder="نام" value="{{ old('n_name',$app->name) }}" required />
                                <div class="custom-label">{{__('lang.name')}}</div>
                                 @include('inc.form-error',['field'=>'name'])
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input {{$lang_field}}" name="f_name" placeholder="والد کا نام" value="{{ old('f_name',$app->father_name) }}" />
                                <div class="custom-label">{{__('lang.father')}}</div>
                                 @include('inc.form-error',['field'=>'f_name'])
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                          <div class="createp_row">
                            <input type="text" class="form-control createp_input {{$lang_field}} dob" name="dob" placeholder="پیدائش کی تاریخ" value="{{ old('dob',$app->dob) }}" readonly />
                            <div class="custom-label">{{__('lang.dob')}}</div>
                            @include('inc.form-error',['field'=>'dob'])
                        </div>
                    </div>
                    <div class="form-group col-md-4 mx-auto">
                      <div class="createp_row select-row">
                          <select class="form-control createp_select" name="class_id" required>
                              <option value="">---</option>
                              @foreach($classes as $cl)
                              @if($cl->is_active == 1)
                              <option value="{{$cl->id}}"{{ $cl->id == $app->classes->id ? 'selected':'' }}>{{$cl->class_name}}</option>
                              @endif
                              @endforeach 
                          </select>
                          <div class="custom-label">{{__('lang.classes')}}</div>
                          @include('inc.form-error',['field'=>'class_id'])
                      </div>
                  </div>
                  <div class="form-group col-md-4">
                      <div class="createp_row">
                        <input type="text" class="form-control createp_input {{$lang_field}}" name="city" placeholder="شہریت" value="{{ old('city',$app->city) }}" />
                        <div class="custom-label">{{__('lang.city')}}</div>
                        @include('inc.form-error',['field'=>'city'])
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <div class="createp_row">
                      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="{{$app->phone}}" />
                      <div class="custom-label">{{__('lang.mobile')}}</div>
                      @include('inc.form-error',['field'=>'mobile_no'])
                  </div>
              </div>
              <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="present_address" placeholder="موجودہ پتہ" value="{{ old('address',$app->address) }}" />
                    <div class="custom-label">{{__('lang.present_address')}}</div>
                    @include('inc.form-error',['field'=>'present_address'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="permanent_address" placeholder="مستقل پتہ" value="{{ old('permanent_address',$app->permanent_address) }}"/>
                    <div class="custom-label">{{__('lang.permanent_address')}}</div>
                    @include('inc.form-error',['field'=>'permanent_address'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="student_cnic" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="{{ old('cnic',$app->cnic) }}"  />
                    <div class="custom-label">{{__('lang.cnic')}}</div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="islamic_education" placeholder="اسلامی تعلیم" value="{{ old('islamic_education',$app->islamic_education) }}"/>
                    <div class="custom-label">{{__('lang.islamic_education')}}</div>
                    @include('inc.form-error',['field'=>'islamic_education'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="previous_institute" placeholder="پچھلا اسکول" value="{{ old('previous_institute',$app->previous_institute_name) }}"/>
                    <div class="custom-label">{{__('lang.old_school')}}</div>
                    @include('inc.form-error',['field'=>'previous_institute'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="previous_institute_left_reason" placeholder="اسکول چھوڑنے کی وج" value="{{ old('previous_institute_left_reason',$app->previous_institute_left_reason) }}"/>
                    <div class="custom-label">{{__('lang.leave_school_reason')}}</div>
                    @include('inc.form-error',['field'=>'previous_institute_left_reason'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="basic_education" placeholder="اسکول کی تعلیم" value="{{ old('basic_education',$app->basic_education) }}" />
                    <div class="custom-label">{{__('lang.school_education')}}</div>
                    @include('inc.form-error',['field'=>'basic_education'])
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="f-sub-hd">{{__('lang.guardian_heading')}}</h3>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-3">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="u_f_name" placeholder="نام" value="{{ old('u_f_name',isset($app->gaurdians->guardian_name)?$app->gaurdians->guardian_name:'') }}" />
                    <div class="custom-label">{{__('lang.name')}}</div>
                </div>
            </div>
            <div class="form-group col-md-3">
                <div class="createp_row">
                  <input type="text" class="form-control createp_input {{$lang_field}}" name="u_father_name" placeholder="والد کا نام" value="{{ old('u_father_name', isset($app->gaurdians->guardian_f_name) ? $app->gaurdians->guardian_f_name : "") }}">
                  <div class="custom-label">{{__('lang.father_name')}}</div>
                  @include('inc.form-error',['field'=>'father_name'])
              </div>
          </div>
          <div class="form-group col-md-3">
            <div class="createp_row">
              <input type="text" class="form-control createp_input {{$lang_field}}" name="u_city" placeholder="شہریت" value="{{ old('u_city',isset($app->gaurdians->city)?$app->gaurdians->city:'') }}">
              <div class="custom-label">{{__('lang.city')}}</div>
          </div>
      </div>
      <div class="form-group col-md-3">
        <div class="createp_row">
          <input type="text" class="form-control createp_input {{$lang_field}}" name="applicant_relation" placeholder="طالب علم سے رشتہ" value="{{ old('applicant_relation',isset($app->gaurdians->applicant_relation)?$app->gaurdians->applicant_relation:'') }}" />
          <div class="custom-label">{{__('lang.relation_with_student')}}</div>
          @include('inc.form-error',['field'=>'applicant_relation'])
      </div>
  </div>
  <div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input {{$lang_field}}" name="occupation" placeholder="پیشہ" value="{{ old('occupation',isset($app->gaurdians->occupation)?$app->gaurdians->occupation:'') }}" />
      <div class="custom-label">{{__('lang.profession')}}</div>
      @include('inc.form-error',['field'=>'occupation'])
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input {{$lang_field}}" name="position" placeholder="عہدہ / پوسٹ" value="{{ old('position',isset($app->gaurdians->position)?$app->gaurdians->position:'') }}" />
      <div class="custom-label">{{__('lang.position')}}</div>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="contact_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="{{ old('contact_no',isset($app->gaurdians->phone)?$app->gaurdians->phone:'')}}" />
      <div class="custom-label">{{__('lang.guardian_mobile')}}</div>
      @include('inc.form-error',['field'=>'contact_no'])
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="guardian_cnic" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="{{ old('guardian_cnic',isset($app->gaurdians->father_cnic)?$app->gaurdians->father_cnic:'') }}" />
        <div class="custom-label">{{__('lang.cnic')}}</div>
        @include('inc.form-error',['field'=>'guardian_cnic'])
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input {{$lang_field}}" name="p_address" placeholder="پتہ" value="{{ old('p_address',isset($app->gaurdians->address)?$app->gaurdians->address:'') }}"  />
        <div class="custom-label">{{__('lang.address')}}</div>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input {{$lang_field}}" name="another_guardian_name" placeholder="Another Guardian Name"  value="{{ old('another_guardian_name',isset($app->gaurdians->another_guardian_name)?$app->gaurdians->another_guardian_name:'') }}"/>
        <div class="custom-label">{{__('lang.another_guardian')}}</div>
        @include('inc.form-error',['field'=>'another_guardian_name'])
    </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X"value="{{ old('mobile_no',isset($app->gaurdians->mobile_no)?$app->gaurdians->mobile_no:'') }}" />
      <div class="custom-label">{{__('lang.mobile_interagent')}}</div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <h3 class="f-sub-hd">{{ __('lang.other_info')}}</h3>
</div>
</div>
<div class="form-row">
  <div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">1. {{__('lang.question_1')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[0]" value="{{$app->applicant_answers[0]->applicant_answer ?? ""}}" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">2. {{__('lang.question_2')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name ="question_ans[1]" value="{{$app->applicant_answers[1]->applicant_answer ?? ""}}" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">3. {{__('lang.question_3')}}</div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[2]" value="{{$app->applicant_answers[2]->applicant_answer ?? ""}}" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">4. {{__('lang.question_4')}}</div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[3]" value="{{$app->applicant_answers[3]->applicant_answer ?? ""}}" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">5. {{__('lang.question_5')}}</div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[4]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="{{$app->applicant_answers[4]->applicant_answer ?? ""}}" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">6. {{__('lang.question_6')}}</div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[5]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="{{$app->applicant_answers[5]->applicant_answer ?? ""}}" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">7. {{__('lang.question_7')}}</div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[6]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="{{$app->applicant_answers[6]->applicant_answer ?? ""}}" />
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <p class="form-content">8. {{__('lang.instruction_1')}}</p>
    <p class="form-content">9. {{__('lang.instruction_2')}}</p>
</div>
{{-- <div class="col-md-3 d-flex">
    <span class="signature">Guardian Signature</span>
</div> --}}
</div>
@can('applicantUpdate', '25')
<button type="submit" class="btn btn-primary btn-global btn-submit mx-auto d-block">{{__('lang.submit')}}</button>
@endcan
</form>
</div>
</div>
</div>
</div>
@endsection 
@section('scripts')
@parent
<script src="{{ asset('js/yauk.min.js') }}"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
<script>
    $('.urdu-field').setUrduInput({urduNumerals: true});
    $(':input').inputmask();
    $('.dob').datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: "-100Y",
        maxDate: '-2Y',
        yearRange: "-100:-2"
    });
</script>
@endsection