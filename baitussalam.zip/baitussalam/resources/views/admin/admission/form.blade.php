@extends('layouts.app')

@section('content')

{{-- $lang_key --}}

<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>{{__('lang.admission_heading')}}</h4>
    </div>
    <div class="container admissionf-page">
        <div class="card">
            <div class="card-body">
                <form class="mt-4" method="post" action="{{url('admission-submit-form')}}">
                  <input type="text" name="lang_key" hidden>
                    @csrf
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.dars_nizami')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.dars_nizami')}}">
                                 @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.matric')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.matric')}}">
                                 @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.qadeem')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.qadeem')}}">
                                 @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx">{{__('lang.jadeed')}}
                                <input class="form-control" name="class_selection[]" type="checkbox" value="{{__('lang.jadeed')}}">
                                 @include('inc.form-error',['field'=>'class_selection'])
                                <span class="checkmark"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input {{$lang_field}}" name="name" value="{{ old('name') }}" placeholder="نام" />
                                <div class="custom-label"><span class="steric">*</span>{{ __('lang.name')}}</div>
                                @include('inc.form-error',['field'=>'name'])
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input {{$lang_field}}" name="f_name" value="{{ old('f_name') }}" placeholder="والد کا نام" />
                                <div class="custom-label"><span class="steric">*</span>{{ __('lang.father_name')}}</div>
                                @include('inc.form-error',['field'=>'f_name'])
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                          <div class="createp_row">
                            <input type="text" class="form-control createp_input {{$lang_field}} dob" name="dob" value="{{ old('dob') }}"  placeholder="پیدائش کی تاریخ" autocomplete="off" readonly />
                            <div class="custom-label"><span class="steric">*</span>{{ __('lang.dob')}}</div>
                            @include('inc.form-error',['field'=>'dob'])
                        </div>
                    </div>
                    <div class="form-group col-md-4 mx-auto">
                      <div class="createp_row select-row">
                          <select class="form-control createp_select" name="class_id">
                              <option value=""></option>
                              @foreach($classes as $cl)
                              @if($cl->is_active == 1)
                              <option value="{{$cl->id}}">{{$cl->class_name}}</option>
                              @endif
                              @endforeach 
                          </select>
                          <div class="custom-label"><span class="steric">*</span>{{ __('lang.classes')}}</div>
                          @include('inc.form-error',['field'=>'class_id'])
                      </div>
                  </div>
                  <div class="form-group col-md-4">
                      <div class="createp_row">
                        <input type="text" class="form-control createp_input {{$lang_field}}" name="city" value="{{ old('city') }}" placeholder="شہریت" />
                        <div class="custom-label"><span class="steric">*</span>{{ __('lang.city')}}</div>
                        @include('inc.form-error',['field'=>'city'])
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <div class="createp_row">
                      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" value="{{ old('mobile_no') }}" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
                      <div class="custom-label"><span class="steric">*</span>{{ __('lang.mobile')}}</div>
                      @include('inc.form-error',['field'=>'mobile_no'])
                  </div>
              </div>
              <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="present_address" value="{{ old('present_address') }}" placeholder="موجودہ پتہ" />
                    <div class="custom-label"><span class="steric">*</span>{{ __('lang.present_address')}}</div>
                    @include('inc.form-error',['field'=>'present_address'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="permanent_address" value="{{ old('permanent_address') }}" placeholder="مستقل پتہ" />
                    <div class="custom-label"><span class="steric">*</span>{{ __('lang.permanent_address')}}</div>
                    @include('inc.form-error',['field'=>'permanent_address'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="student_cnic" value="{{ old('student_cnic') }}" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
                    <div class="custom-label"><span class="steric">*</span>{{ __('lang.cnic')}}</div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="islamic_education" value="{{ old('islamic_education') }}" placeholder="اسلامی تعلیم" />
                    <div class="custom-label"><span class="steric">*</span>{{ __('lang.islamic_education')}}</div>
                    @include('inc.form-error',['field'=>'islamic_education'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="previous_institute" value="{{ old('previous_institute') }}" placeholder="پچھلا اسکول" />
                    <div class="custom-label"><span class="steric">*</span>{{ __('lang.old_school')}}</div>
                    @include('inc.form-error',['field'=>'previous_institute'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="previous_institute_left_reason" value="{{ old('previous_institute_left_reason') }}" placeholder="اسکول چھوڑنے کی وج" />
                    <div class="custom-label"><span class="steric">*</span>{{ __('lang.leave_school_reason')}}</div>
                    @include('inc.form-error',['field'=>'previous_institute_left_reason'])
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="basic_education" value="{{ old('basic_education') }}" placeholder="اسکول کی تعلیم" />
                    <div class="custom-label"><span class="steric">*</span>{{__('lang.school_education')}}</div>
                    @include('inc.form-error',['field'=>'basic_education'])
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="f-sub-hd">{{__('lang.guardian_heading')}}</h3>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-3">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input {{$lang_field}}" name="name" value="{{ old('name') }}" placeholder="نام" />
                    <div class="custom-label"><span class="steric">*</span>{{__('lang.name')}}</div>
                </div>
            </div>
            <div class="form-group col-md-3">
                <div class="createp_row">
                  <input type="text" class="form-control createp_input {{$lang_field}}" name="father_name" value="{{ old('father_name') }}" placeholder="والد کا نام">
                  <div class="custom-label"><span class="steric">*</span>{{__('lang.father_name')}}</div>
                  @include('inc.form-error',['field'=>'father_name'])
              </div>
          </div>
          <div class="form-group col-md-3">
            <div class="createp_row">
              <input type="text" class="form-control createp_input {{$lang_field}}" name="city" value="{{ old('city') }}" placeholder="شہریت">
              <div class="custom-label"><span class="steric">*</span>{{__('lang.city')}}</div>
          </div>
      </div>
      <div class="form-group col-md-3">
        <div class="createp_row">
          <input type="text" class="form-control createp_input {{$lang_field}}" name="applicant_relation" value="{{ old('applicant_relation') }}" placeholder="طالب علم سے رشتہ" />
          <div class="custom-label"><span class="steric">*</span>{{__('lang.relation_with_student')}}</div>
          @include('inc.form-error',['field'=>'applicant_relation'])
      </div>
  </div>
  <div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input {{$lang_field}}" name="occupation" value="{{ old('occupation') }}" placeholder="پیشہ" />
      <div class="custom-label"><span class="steric">*</span>{{__('lang.profession')}}</div>
      @include('inc.form-error',['field'=>'occupation'])
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input {{$lang_field}}" name="position" value="{{ old('position') }}" placeholder="عہدہ / پوسٹ" />
      <div class="custom-label"><span class="steric">*</span>{{__('lang.position')}}</div>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="contact_no" value="{{ old('contact_no') }}" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
      <div class="custom-label"><span class="steric">*</span>{{__('lang.guardian_mobile')}}</div>
      @include('inc.form-error',['field'=>'contact_no'])
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="guardian_cnic" value="{{ old('guardian_cnic') }}" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
        <div class="custom-label"><span class="steric">*</span>{{__('lang.cnic')}}</div>
        @include('inc.form-error',['field'=>'guardian_cnic'])
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input {{$lang_field}}" name="p_address" value="{{ old('p_address') }}" placeholder="پتہ" />
        <div class="custom-label"><span class="steric">*</span>{{__('lang.address')}}</div>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input {{$lang_field}}" name="another_guardian_name" value="{{ old('another_guardian_name') }}" placeholder="Another Guardian Name" />
        <div class="custom-label"><span class="steric">*</span>{{__('lang.another_guardian')}}</div>
        @include('inc.form-error',['field'=>'another_guardian_name'])
    </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" value="{{ old('mobile_no') }}" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
      <div class="custom-label"><span class="steric">*</span>{{__('lang.mobile_interagent')}}</div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <h3 class="f-sub-hd">{{ __('lang.other_info')}}</h3>
</div>
</div>
<div class="form-row">
  <div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">1. {{__('lang.question_1')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[0]" required />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">2. {{__('lang.question_2')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name ="question_ans[1]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">3. {{__('lang.question_3')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[2]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">4. {{__('lang.question_4')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[3]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">5. {{__('lang.question_5')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[4]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">6. {{__('lang.question_6')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[5]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur"required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">7. {{__('lang.question_7')}} </div>
      <input type="text" class="form-control createp_input {{$lang_field}}" name="question_ans[6]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <p class="form-content">8. {{__('lang.instruction_1')}}</p>
    <p class="form-content">9. {{__('lang.instruction_2')}}</p>
</div>
{{-- <div class="col-md-3 d-flex">
    <span class="signature">Guardian Signature</span>
</div> --}}
</div>
@can('applicantStore', '24')
<button type="submit" class="btn btn-primary btn-global btn-submit mx-auto d-block">{{__('lang.submit')}}</button>
@endcan
</form>
</div>
</div>
</div>
</div>
@endsection	
@section('scripts')
@parent
<script src="{{ asset('js/yauk.min.js') }}"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
<script>
    $('.urdu-field').setUrduInput({urduNumerals: true});
    $(':input').inputmask();
    $('.dob').datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: "-100Y",
        maxDate: '-2Y',
        yearRange: "-100:-2"
    });
</script>
@endsection 