@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head"><h4>{{ __('lang.add_class')}}</h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="{{route('class.store')}}" autocomplete="off">
                            @csrf
                            <div class="form-row">
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select {{$lang_field}}" name="class_name" required>
                                            <option value="">کلاس</option>
                                            <option value="پہلی سطح">پہلی سطح</option>
                                            <option value="دوسری سطح">دوسری سطح</option>
                                            <option value="تیسری سطح">تیسری سطح</option>
                                            <option value="چوتھی سطح">چوتھی سطح</option>
                                            <option value="پانچویں سطح">پانچویں سطح</option>
                                            <option value="چھٹی سطح">چھٹی سطح</option>
                                            <option value="ساتویں سطح">ساتویں سطح</option>
                                            <option value="آٹھویں سطح">آٹھویں سطح</option>
                                            <option value="نویں سطح">نویں سطح</option>
                                        </select>
                                        @include('inc.form-error',['field'=>'class_name'])
                                        <div class="custom-label">{{ __('lang.class_name')}}</div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select {{$lang_field}}" name="minimum_age_limit">
                                            <option value="">کم سے کم حد</option>
                                            <option value="چار سال">چار سال</option>
                                            <option value="پانچ سال">پانچ سال</option>
                                            <option value="چھ سال">چھ سال</option>
                                            <option value="سات سال">سات سال</option> 
                                        </select>
                                        <div class="custom-label">{{ __('lang.minimum_age_limit')}}</div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select {{$lang_field}}" name="maximum_age_limit">
                                            <option value="">زیادہ سے زیادہ عمر کی حد</option>
                                            <option value="آٹھ سال">آٹھ سال</option>
                                            <option value="نو سال">نو سال</option>
                                            <option value="دس سال">دس سال</option>
                                            <option value="گیارہ سال">گیارہ سال</option> 
                                        </select>
                                        <div class="custom-label">{{ __('lang.maximum_age_limit')}}</div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                     <input class="form-control" required="" type="number" name="question_limit" min="1" max="200">
                                     <div class="custom-label">Question Limit </div>
                                 </div>
                             </div>
                             <div class="form-group col-md-4 mx-auto">
                                <div class="createp_row select-row">
                                    <label>Quiz Time</label>
                                    <input type="time" name="quiz_time" value="">
                                </div>
                            </div>
                            {{-- <div class="form-group col-md-4 mx-auto">
                                <div class="createp_row select-row">
                                    <label for="allow_rand"><input type="checkbox" checked="" id="allow_rand" name="random_question">
                                    Allow Random Question</label>
                                </div>
                            </div> --}}
                        </div>
                        <div class="form-row">
                            @can('classSave', '4')
                            <button type="submit" class="btn btn-primary btn-global mx-auto">{{ __('lang.add_class')}}</button>
                        </div>
                        @endcan
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>    
@endsection	