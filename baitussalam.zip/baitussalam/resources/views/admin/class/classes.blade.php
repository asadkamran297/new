@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
  <div class="inner-head">
    <h4>{{ __('lang.class_data')}}</h4>
    @can('classCreate', '2')
    <a class="btn btn-primary btn-global" href="{{route('class.create')}}">{{ __('lang.add_class')}}</a>
    @endcan
</div>
<div class="container-fluid">
    <div class="card mb-3"> 
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th>{{ __('lang.id')}}</th>
                            <th>{{ __('lang.class_name')}}</th>
                            <th>{{ __('lang.minimum_age_limit')}}</th>
                            <th>{{ __('lang.maximum_age_limit')}}</th>
                            <th>{{ __('lang.quiz_time')}}</th>
                            <th>Quiz Questions</th>
                            <th>{{__('lang.user_status')}}</th>
                            @can('classEdit', '3')
                            <th>{{ __('lang.edit')}}</th>
                            @endcan
                            @can('classDelete','6')
                            <th>{{ __('lang.delete')}}</th>
                            @endcan
                            <th>{{ __('lang.date')}}</th>
                            {{-- <th>Quiz Options</th> --}}
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($consumerdata as $row)
                        <tr>
                            <th>{{$row->id}}</th>
                            <td>{{$row->class_name}}</td>
                            <td>{{$row->minimum_age_limit}}</td>
                            <td>{{$row->maximum_age_limit}}</td>
                            <td>{{$row->quiz_time}}</td>
                            <td>{{$row->question_limit}}</td>
                            <td>
                                @if($row->is_active==1)
                                <span class="badge badge-success">{{__('lang.active')}}</span>
                                @else 
                                <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                                @endif
                                <input type="checkbox" onclick='is_active_class("{{ $row->id }}",this)' {{(isset($row->is_active) && $row->is_active == 1 )?'checked':'' }}>
                            </td>
                            @can('classEdit', '3')
                            <td><a class="btn btn-primary btn-global-icon-outline" href="{{route('class.edit',$row->id)}}" title="{{ __('lang.edit')}}"><i class="fa fa-pencil"></i></a> </td>
                            @endcan
                            @can('classDelete', '6')
                            <td>
                                <a href="">
                                    <form action="{{route('class.destroy',$row->id)}}" method="post">{{csrf_field()}}
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="submit" class="btn btn-danger btn-global-table" onclick="return confirm('Are you sure you want to delete?')" name="submit" value="{{ __('lang.delete')}}">
                                        <i class="fa fa-trash-alt"></i>                   
                                    </form>
                                </a>
                            </td>
                            @endcan
                            {{-- <td><a href="{{ route('class.quiz_options',['class_id'=>$row->id]) }}">Quiz Options</a></td> --}}
                            <td>{{date('d-m-Y',strtotime($row->created_at))}}</td>
                        </tr>
                        @endforeach                  
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
@section('custom-scripts')
<script type="text/javascript">
    function is_active_class(class_id,instance){
        var check_val = $(instance).is(':checked');
        $.ajax({
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            type: "POST",
            url: '{{ route("class.update_class") }}',
            data: { status :check_val,class_id: class_id }, 
            success: function( msg ) {
                if(msg.status==0 || msg.status==1){
                    alert(msg.message);
                    location.reload();
                }
            }
        }); 
    }
</script>
@endsection