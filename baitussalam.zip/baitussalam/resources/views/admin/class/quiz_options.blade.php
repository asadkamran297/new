@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head"><h4>{{ __('lang.add_class')}}</h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="{{route('class.quiz_options_up')}}" autocomplete="off">
                            @csrf
                            <div class="form-row">
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <label for="allow_rand"><input type="checkbox" id="allow_rand" name="random_questions">
                                        Allow Random Question</label>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <input class="form-control" required="" type="number" name="quiz_question_limit" min="1" max="20">
                                        <div class="custom-label">Question Limit </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                {{-- @can('classSave', '4') --}}
                                <input type="hidden" name="class_id" value="{{ $class->id }}">
                                <button type="submit" class="btn btn-primary btn-global mx-auto">Update Quiz options</button>
                            </div>
                            {{-- @endcan --}}
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
@endsection	