@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">    
    <div class="inner-head">
        <div class="inner-head">
            <h4>{{__('lang.permissions_head')}}</h4>
            @can('permissionAdd', '35')
            <a class="btn btn-primary btn-global" href="{{ route('admin.permissions.create') }}">{{__('lang.add_permission')}}</a>
            @endcan
        </div>
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.id')}}</th>
                                <th>{{__('lang.title')}}</th>
                                <th>{{__('lang.permission_status')}}</th>
                                <th>{{__('lang.edit')}}</th>
                                <th>{{__('lang.permission_created_at')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($permissions) && count($permissions)>0)
                            @foreach($permissions as $key => $permission)
                            <tr>
                                <th>{{ ($permissions->currentpage()-1) * $permissions->perpage() + $key + 1 }}</th>
                                <td>{{ $permission->title }}</td>
                                <td>
                                    @if($permission->is_active==1)
                                    <span class="badge badge-success">{{__('lang.active')}}</span>
                                    @else 
                                    <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                                    @endif
                                </td>
                                @can('permissionEdit','36')
                                <td><a href="{{ route('admin.permissions.edit',['permission'=>$permission->id]) }}"><i class="fa fa-pencil" aria-hidden="true"></i></a></td>
                                @endcan
                                <td>{{ $permission->created_at }}</td>
                            </tr>
                            @endforeach
                            @else
                            <tr>{{__('lang.no_data_found')}}</tr>
                            @endif
                        </tbody>
                    </table>
                    {!! $permissions->links() !!}
                </div>
            </div>    
        </div>
    </div>
    @endsection         
