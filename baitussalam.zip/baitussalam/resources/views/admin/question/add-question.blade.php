@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head"><h4>{{__('lang.add_question')}}</h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card baitquestion">
                    <div class="card-body">
                        <form method="post" action="{{url('admin/save-question')}}" autocomplete="off">
                            <input type="hidden" name="lang_key" value="{{$lang_key}}">
                            @csrf
                            <div class="form-row">
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select" name="subject_id" required>
                                            <option value="">---</option>
                                            @foreach($subjects as $sb)
                                            <option value="{{$sb->id}}">{{$sb->title}}</option>
                                            @endforeach 
                                        </select>
                                        @include('inc.form-error',['field'=>'subject_id'])
                                        <div class="custom-label">{{__('lang.subject_name')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-8 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="question_content" placeholder="سوال" />
                                        @include('inc.form-error',['field'=>'question_content'])
                                        <div class="custom-label">{{__('lang.question_inp')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <label class="customcbx">
                                            <input class="form-control" name="content_chckbx[0]" type="checkbox">
                                            @include('inc.form-error',['field'=>'content_chckbx'])
                                            <span class="checkmark"></span>
                                        </label>
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="content[]" placeholder="جواب" required />
                                        @include('inc.form-error',['field'=>'content'])
                                        <div class="custom-label">{{__('lang.ans_inp')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <label class="customcbx">
                                            <input class="form-control" name="content_chckbx[1]" type="checkbox">
                                            @include('inc.form-error',['field'=>'content_chckbx'])
                                            <span class="checkmark"></span>
                                        </label>
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="content[]" placeholder="جواب" required/>
                                        @include('inc.form-error',['field'=>'content'])
                                        <div class="custom-label">{{__('lang.ans_inp')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <label class="customcbx">
                                            <input class="form-control" name="content_chckbx[2]" type="checkbox">
                                            @include('inc.form-error',['field'=>'content_chckbx'])
                                            <span class="checkmark"></span>
                                        </label>
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="content[]" placeholder="جواب"  required/>
                                        @include('inc.form-error',['field'=>'content'])
                                        <div class="custom-label">{{__('lang.ans_inp')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <label class="customcbx">
                                            <input class="form-control" name="content_chckbx[3]" type="checkbox">
                                            @include('inc.form-error',['field'=>'content_chckbx'])
                                            <span class="checkmark"></span>
                                        </label>
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="content[]" placeholder="جواب" required/>
                                        @include('inc.form-error',['field'=>'content'])
                                        <div class="custom-label">{{__('lang.ans_inp')}}</div>
                                    </div>
                                </div>
                            </div>                        
                            <div class="form-row">
                                <button type="submit" class="btn btn-primary btn-global mx-auto">{{__('lang.add_question')}}</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
@parent
<script src="{{ asset('js/yauk.min.js') }}"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
  $('input[type="checkbox"]').on('change', function() {
   $('input[type="checkbox"]').not(this).prop('checked', false);
});
</script>
@endsection