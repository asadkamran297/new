@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head"><h4>{{ __('lang.edit_question')}}</h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card baitquestion">
                    <div class="card-body">
                    <form method="post" action="{{url('admin/update-question')}}" autocomplete="off">
                        <input type="hidden" name="id" value="{{$id}}">
                        <input type="hidden" name="lang_key" value="{{$lang_key}}">
                           @csrf
                            <div class="form-row">
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select" name="subject_id">
                                            <option value=""></option>
                                            @if(isset($subjects))
                                            @foreach($subjects as $sb)
                                                <option value="{{$sb->id}}"{{ $sb->id == $ques->subjects->id ? 'selected':'' }}>{{$sb->title}}</option>
                                            @endforeach
                                            @endif 
                                        </select>
                                        @include('inc.form-error',['field'=>'subject_id'])
                                        <div class="custom-label">{{__('lang.subject_name')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-8 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="question_content" placeholder="سوال" value="{{$ques->question_content}}" />
                                        @include('inc.form-error',['field'=>'question_content'])
                                        <div class="custom-label">{{__('lang.question_inp')}}</div>
                                    </div>
                                </div>
                            </div>
                            @foreach($ques['answers'] as $key=>$ans)
                            <input type="hidden" name="ans_id[]" value="{{$ans->id}}">
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <label class="customcbx">
                                            <input class="form-control" name="content_chckbx[{{ $key }}]"  type="checkbox" autocomplete="off" {{  $ans->is_true=="1" ? "checked" : "" }} >
                                            @include('inc.form-error',['field'=>'content_chckbx'])
                                            <span class="checkmark"></span>
                                        </label>
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="content[]"  placeholder="جواب" value="{{ old('content',$ans->content) }}" autocomplete="off" required />
                                        @include('inc.form-error',['field'=>'content'])
                                        <div class="custom-label">{{__('lang.ans_inp')}}</div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                            <div class="form-row">
                                <button type="submit" class="btn btn-primary btn-global mx-auto">{{__('lang.update_question')}}</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
@parent
<script src="{{ asset('js/yauk.min.js') }}"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
  $('input[type="checkbox"]').on('change', function() {
   $('input[type="checkbox"]').not(this).prop('checked', false);
});
</script>
@endsection 	