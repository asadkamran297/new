@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
  <div class="inner-head">
    <div class="inner-head">
      <h4>{{__('lang.question_data')}}</h4>
      @can('questionAdd','15')
      <a class="btn btn-primary btn-global" href="{{url('admin/add-question')}}">{{__('lang.add_question')}}</a>
      @endcan
    </div>
  </div>
      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                <thead class="thead-light">
                  <tr>
                    <th>{{__('lang.id')}}</th>
                    <th>{{__('lang.question_name')}}</th>
                    <th>{{__('lang.subject_name')}}</th>
                    <th>{{__('lang.date')}}</th>
                    <th>{{__('lang.is_active_question')}}</th>
                    @can('questionEdit','23')
                    <th>{{__('lang.edit')}}</th>
                    @endcan
                    @can('questionDestroy','19')
                    <th>{{__('lang.delete')}}</th>
                    @endcan
                  </tr>
                </thead>
                <tbody>
                  @foreach($questions as $row)
                  <tr>
                    <th>{{$row->id}}</th>
                    <td>{{$row->question_content}}</td>
                    <td>{{isset($row->subjects->title)?$row->subjects->title:''}}</td>
                    <td>{{date('d-m-Y',strtotime($row->created_at))}}</td>
                    @can('questionStatusUpdate','20')
                    <td>
                      @if($row->is_active==1)
                      <span class="badge badge-success">{{__('lang.active')}}</span>
                      @else 
                      <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                      @endif
                      <input type="checkbox" id="myCheck" onclick='is_active("{{$row->id}}",this)' {{(isset($row->is_active) && $row->is_active == 1 )?'checked':'' }}></td>
                    @endcan  
                    @can('questionEdit','23 ')
                    <td><a class="btn btn-primary btn-global-icon-outline" href="edit-question/{{$row->id}}" title="{{__('lang.edit')}}"><i class="fa fa-pencil"></i></a> 
                    </td>
                    @endcan
                    @can('questionDestroy','19')
                    <td><a class="btn btn-danger btn-global-table" onclick="return confirm('Are you sure you want to delete?')" href="delete-question/{{$row->id}}">{{__('lang.delete')}}</a></td>
                    @endcan
                  </tr>
                  @endforeach                  
                </tbody>
              </table>
            </div>
          </div>    
        </div>
      </div>
@endsection         
@section('scripts')
@parent
<script>

function is_active(question_id,instance)
{     
     var checkBox = $(instance).is(':checked'); 
        $.ajax({
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      type: "GET",
      url: '{{url('/admin/is-active')}}',
      data: { status  :checkBox,question_id: question_id }, 
      success: function( msg ) {
      // alert('Updated');
       location.reload();
      }
    }); 
    
} 
</script>
@endsection  