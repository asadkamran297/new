@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>Quiz History</h4>  
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.id')}}</th>
                                <th>Attempted Date Time</th>
                                <th>View Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($quizes) && count($quizes) > 0)
                            @foreach($quizes as $key => $quiz)
                            <tr>
                                <td>{{ $key+1 }}</td>
                                <td>{{ date('d-m-Y h:i:s',strtotime($quiz->updated_at)) }}</td>
                                <td><a href="{{ route('admin.quiz.history_detail',['entry_test_id'=>$quiz->id]) }}">View Details</a></td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div>
    @endsection

