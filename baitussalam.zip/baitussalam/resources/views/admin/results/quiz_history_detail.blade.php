@extends('layouts.app')
@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>Result Summary</h4>
    </div>
    <div class="content-area">
        <div class="npage nquiz-page">
            <div class="container">
                @if(isset($attempts) && count($attempts) > 0)
                @foreach($attempts as $da)
                <div class="question-area">
                    <div class="nquiz_Q">
                        <strong>سوال نمبر {{$loop->iteration}}:</strong> {{isset($da->question->question_content) && !empty($da->question->question_content) ? $da->question->question_content : ''}}
                    </div>
                    @if(isset($da->answer) && $da->answer)
                    <div class="nquiz_A">
                        <div class="nquiz_ya mb-2">
                            <label>Submitted Answer</label>
                            @if($da['is_true']==1)
                            <p class="correct-ans">{{isset($da->answer->content) && !empty($da->answer->content) ? $da->answer->content : ''}}</p>
                            @else
                            <p class="wrong-ans">{{isset($da->answer->content) && !empty($da->answer->content) ? $da->answer->content : ''}}</p>
                            @endif
                        </div>
                        {{-- <div class="nquiz_ca">
                            <label>Correct Answer</label>
                            <p>{{isset($da['correct_answer']) && !empty($da['correct_answer']) ? $da['correct_answer'] : ''}}</p>
                        </div> --}}
                    </div>
                    @endif
                    <hr />
                </div>
                @endforeach
                @endif
            </div>
        </div>
    </div>
</div>
@endsection    
