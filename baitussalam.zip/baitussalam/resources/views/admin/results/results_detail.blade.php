@extends('layouts.app')
@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>{{__('lang.result_summary')}}</h4>
    </div>
    <div class="content-area">
        <div class="npage nquiz-page">
            <div class="container">
                @if(isset($data_arr) && count($data_arr) > 0)
                @foreach($data_arr as $da)
                <div class="question-area">
                    <div class="nquiz_Q">
                        <strong>{{__('lang.quest_no')}} {{$loop->iteration}}:</strong> {{isset($da['question']) && !empty($da['question']) ? $da['question'] : ''}}
                    </div>
                    <div class="nquiz_A">
                        <div class="nquiz_ya mb-2">
                            <label>{{__('lang.submit_ans')}}</label>
                            @if($da['is_true']==1)
                            <p class="correct-ans">{{isset($da['attempt_answer']) && !empty($da['attempt_answer']) ? $da['attempt_answer'] : ''}}</p>
                            @else
                            <p class="wrong-ans">{{isset($da['attempt_answer']) && !empty($da['attempt_answer']) ? $da['attempt_answer'] : ''}}</p>
                            @endif
                        </div>
                        <div class="nquiz_ca">
                            <label>{{__('lang.correct_ans')}}</label>
                            <p>{{isset($da['correct_answer']) && !empty($da['correct_answer']) ? $da['correct_answer'] : ''}}</p>
                        </div>
                    </div>
                    <hr />
                </div>
                @endforeach
                @endif
            </div>
        </div>
    </div>
</div>
@endsection    
