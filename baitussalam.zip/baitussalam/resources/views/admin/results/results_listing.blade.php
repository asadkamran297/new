@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>{{__('lang.result_list')}}</h4>  
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.student_name')}}</th>
                                <th>{{__('lang.result_status')}}</th>
                                <th>{{__('lang.quest_num_of_que')}}</th>
                                <th>{{__('lang.actions')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($data_arr) && count($data_arr) > 0)
                            @foreach($data_arr as $da)
                            <tr>
                                <th>{{isset($da['name']) ? $da['name'] : '---'}}</th>
                                <td>{{ isset($da['num_of_correct']) && $da['num_of_correct'] ? $da['num_of_correct'] : 0  }}</td>
                                <td>{{isset($da['total_attempts']) && isset($da['total_attempts']) ? $da['total_attempts'] . '/' . $da['total_attempts'] : '---'}}</td>
                                <td>
                                    <a class="btn btn-primary btn-global-icon-outline" href="{{url('/admin/results-detail/'.$da['entry_test_id'].'/'.$da['user_id'])}}" title=""><i class="fa fa-pencil"></i>
                                    </a>
                                    <a href="{{ route('admin.re_attempt',['entry_test_id'=>$da['entry_test_id']]) }}" class="btn btn-primary"><i class="">Allow Re-attempt quiz</i></a>
                                    <a href="{{ route('admin.quiz_history',['user_id'=>$da['user_id']]) }}" class="btn btn-primary"><i class="fa fa-eye">View quiz history</i></a>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div>
    @endsection

