@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head"><h4>{{__('lang.add_permission')}}</h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="{{ route('admin.permissions.store') }}" autocomplete="off">
                            <input type="hidden" name="lang_key" value="{{$lang_key}}">
                            @csrf
                            <div class="form-row">
                                <div class="form-group col-md-8 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input" name="title" placeholder="title" />
                                        @include('inc.form-error',['field'=>'title'])
                                        <div class="custom-label">{{__('lang.title')}}</div>
                                    </div>
                                </div>
                            </div>                        
                            <div class="form-row">
                                <button type="submit" class="btn btn-primary btn-global mx-auto">{{__('lang.add')}}</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
@parent
<script src="{{ asset('js/yauk.min.js') }}"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
@endsection