@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">    
    <div class="inner-head">
        <div class="inner-head">
            <h4>{{__('lang.role_permissions')}}</h4>
            {{-- <a class="btn btn-primary btn-global" href="{{ route('admin.permissions.create') }}">Add Permission</a> --}}
        </div>
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.id')}}</th>
                                <th>{{__('lang.role_title')}}</th>
                                <th>{{__('lang.permissions_head')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($roles) && count($roles)>0)
                            @foreach($roles as $r_key => $role)
                            <form method="POST" action="{{ route('admin.roles-permissions.update',['roles_permission'=>'$role->id']) }}">
                                @method('put')
                                @csrf
                                <input type="hidden" name="role_id" value="{{ $role->id }}">
                                <tr>
                                    <th>{{ $r_key + 1 }}</th>
                                    <td>{{ isset($role->title) ? ucwords($role->title) : "" }}</td>
                                    <td>
                                        @if(isset($permissions) && count($permissions))
                                        @foreach($permissions as $key => $permission)
                                        @php
                                        $role_permission = $role->r_permissions()->pluck('permission_id')->toArray();
                                        $checked = '';
                                        if(in_array($permission->id,$role_permission)){
                                            $checked = 'checked';
                                        }
                                        @endphp
                                        <label for="permissions-{{ $permission->id }}{{ $role->id }}"><input type="checkbox" {{ $checked }} id="permissions-{{ $permission->id }}{{ $role->id }}" name="permissions[]" value="{{ $permission->id }}"> {{ $permission->title }}</label>
                                          @endforeach
                                          @else
                                          No data available
                                          @endif
                                  
                                          <button class="btn btn-primary" type="submit">{{__('lang.update')}}</button>

                                      </td>
                                  </tr>
                              </form>
                              @endforeach
                              @else
                              <tr>{{__('lang.no_data_found')}}</tr>
                              @endif
                          </tbody>
                      </table>
                  </div>
              </div>    
          </div>
      </div>
      @endsection 
