@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">    
    <div class="inner-head">
        <div class="inner-head">
            <h4>{{__('lang.roles_head')}}</h4>
            {{-- <a class="btn btn-primary btn-global" href="{{url('admin/add-question')}}">Add User</a> --}}
        </div>
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.id')}}</th>
                                <th>{{__('lang.title')}}</th>
                                <th>{{__('lang.role_status')}}</th>
                                <th>{{__('lang.role_created_at')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($roles) && count($roles)>0)
                            @foreach($roles as $key => $role)
                            <tr>
                                <th>{{ ($roles->currentpage()-1) * $roles->perpage() + $key + 1 }}</th>
                                <td>{{ isset($role->title) ?  ucwords($role->title) : "" }}</td>
                                <td>
                                    @if($role->is_active==1)
                                    <span class="badge badge-success">{{__('lang.active')}}</span>
                                    @else 
                                    <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                                    @endif
                                    {{-- <input type="checkbox" onclick='is_active_role("{{ $role->id }}",this)' {{(isset($role->is_active) && $role->is_active == 1 )?'checked':'' }}> --}}
                                </td>
                                <td>{{ $role->created_at }}</td>
                            </tr>
                            @endforeach
                            @else
                            <tr>{{__('lang.no_data_found')}}</tr>
                            @endif
                        </tbody>
                    </table>
                    {!! $roles->links() !!}
                </div>
            </div>    
        </div>
    </div>
    @section('custom-scripts')
    <script type="text/javascript">
        function is_active_role(id,instance){
            var check_val = $(instance).is(':checked');
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                type: "POST",
                url: '{{ route("admin.roles.update_status") }}',
                data: { status :check_val,id: id }, 
                success: function( msg ) {
                    alert('Successfully updated');
                    location.reload();
                }
            }); 
        }
    </script>
    @endsection
    @endsection         
