@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head"><h4>{{__('lang.add_subject')}}</h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="{{route('subject.store')}}" autocomplete="off">
                            @csrf
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input {{$lang_field}}" name="title" placeholder="عنوان"  />
                                        <div class="custom-label">{{__('lang.subject_name')}}</div>
                                        @include('inc.form-error',['field'=>'title'])
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select" name="class_id">
                                            <option value=""></option>
                                            @foreach($classes as $cl)
                                            <option value="{{$cl->id}}">{{$cl->class_name}}</option>
                                            @endforeach 
                                        </select>
                                        @include('inc.form-error',['field'=>'class_id'])
                                        <div class="custom-label">{{__('lang.class_name')}}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                @can('subjectStore', '10')
                                <button type="submit" class="btn btn-primary btn-global mx-auto">{{__('lang.add_subject')}}</button>
                                @endcan
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection	
@section('scripts')
@parent
<script src="{{ asset('js/yauk.min.js') }}"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
@endsection