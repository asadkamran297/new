@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">
    <div class="inner-head">
        <h4>{{__('lang.subject_data')}}</h4>
        @can('subjectAdd', '8')
        <a class="btn btn-primary btn-global" href="{{route('subject.create')}}">{{__('lang.add_subject')}}</a>
        @endcan
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.id')}}</th>
                                <th>{{__('lang.subject_name')}}</th>
                                <th>{{__('lang.class_name')}}</th>
                                <th>{{__('lang.date')}}</th>
                                @can('subjectEdit', '9')
                                <th>{{__('lang.edit')}}</th>
                                @endcan
                                @can('subjectDestroy', '12')
                                <th>{{__('lang.delete')}}</th>
                                @endcan
                                <th>{{__('lang.is_active_subject')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($subjectdata as $row)
                            <tr>
                                <th>{{$row->id}}</th>
                                <td>{{$row->title}}</td>
                                <td>{{isset($row->classes->class_name)?$row->classes->class_name:''}}</td>
                                <td>{{date('d-m-Y',strtotime($row->created_at))}}</td>
                                @can('subjectEdit', '9')
                                <td>
                                    <a class="btn btn-primary btn-global-icon-outline" href="{{ route('subject.edit',$row->id) }}" title="{{__('lang.edit')}}"><i class="fa fa-pencil"></i></a> 
                                </td>
                                @endcan
                                @can('subjectDestroy', '12')
                                <td>
                                    <a href="">
                                        <form action="{{route('subject.destroy',$row->id)}}" method="post">
                                            {{csrf_field()}}
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="submit" class="btn btn-danger btn-global-table" name="submit" onclick="return confirm('Are you sure you want to delete?')" value="{{__('lang.delete')}}">
                                        </form>
                                    </a>
                                </td>
                                @endcan
                                <td>
                                    @if($row->is_active==1)
                                    <span class="badge badge-success">{{__('lang.active')}}</span>
                                    @else 
                                    <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                                    @endif
                                    @can('subjectStatusUpdate', '13')
                                    <input type="checkbox" id="myCheck" onclick='is_active("{{$row->id}}",this)' {{(isset($row->is_active) && $row->is_active == 1 )?'checked':'' }}>
                                    @endcan
                                </td>  
                            </tr>
                            @endforeach                  
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div>
    @endsection
    @section('scripts')
    @parent
    <script>
        function is_active(subject_id,instance){
            var checkBox = $(instance).is(':checked'); 
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                type: "GET",
                url: '{{ url('/admin/is-active-subject') }}',
                data: { status  :checkBox,subject_id: subject_id }, 
                success: function( msg ) {
                    if(msg.status==0){
                        alert(msg.message)
                        location.reload();
                    }
                    if(msg.status==1){
                        alert(msg.message)
                        location.reload();
                    }
                }
            }); 
        } 
    </script>
    @endsection           
