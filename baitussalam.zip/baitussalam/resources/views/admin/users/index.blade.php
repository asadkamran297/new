@extends('layouts.app')

@section('content')
<div class="enpage {{$lang_value}}">    
    <div class="inner-head">
        <div class="inner-head">
            <h4>{{__('lang.users_heading')}}</h4>
            {{-- <a class="btn btn-primary btn-global" href="{{url('admin/add-question')}}">Add User</a> --}}
        </div>
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{__('lang.id')}}</th>
                                <th>{{__('lang.name')}}</th>
                                <th>{{__('lang.email')}}</th>
                                @can('userRoleUpdate','32')
                                <th>{{__('lang.role_head')}}</th>
                                @endcan
                                @can('userStatusUpdate','31')
                                <th>{{__('lang.user_status')}}</th>
                                @endcan
                                {{-- <th>Form Details</th> --}}
                                <th>{{__('lang.user_created_at')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($users) && count($users)>0)
                            @foreach($users as $key => $user)
                            <tr>
                                <th>{{ ($users->currentpage()-1) * $users->perpage() + $key + 1 }}</th>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }} </td>
                                @can('userRoleUpdate','32')
                                <td>
                                    <select name="role" onChange='update_user_role("{{ $user->id }}",this)' class="form-control">
                                        @foreach($roles as $role)
                                            <option @if($role->id==$user->role_id) selected @endif value="{{ $role->id }}">{{ isset($role->title) ? ucwords($role->title) : "" }} </option>
                                        @endforeach
                                    </select>
                                </td>
                                @endcan
                                @can('userStatusUpdate','31')
                                <td>
                                    @if($user->is_active==1)
                                    <span class="badge badge-success">{{__('lang.active')}}</span>
                                    @else 
                                    <span class="badge badge-danger">{{__('lang.deactive')}}</span>
                                    @endif
                                    <input type="checkbox" onclick='is_active_user("{{ $user->id }}",this)' {{(isset($user->is_active) && $user->is_active == 1 )?'checked':'' }}>
                                </td>
                                @endcan
                                {{-- <td><a href="{{ route('admin.edit_admission_form',['id'=>$user->applicants->id]) }}">View Form</a></td> --}}
                                <td>{{date('d-m-Y', strtotime($user->created_at))}}</td>
                            </tr>
                            @endforeach
                            @else
                            <tr>No data found</tr>
                            @endif
                        </tbody>
                    </table>
                    {!! $users->links() !!}
                </div>
            </div>    
        </div>
    </div>
    @section('custom-scripts')
    <script type="text/javascript">
        function is_active_user(user_id,instance){
            var check_val = $(instance).is(':checked');
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                type: "POST",
                url: '{{ route("admin.users.update_status") }}',
                data: { status :check_val,user_id: user_id }, 
                success: function( msg ) {
                    location.reload();
                }
            }); 
        }
        function update_user_role(user_id,instance){
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                type: "POST",
                url: '{{ route("admin.users.update_role") }}',
                data: { role_id :instance.value,user_id: user_id }, 
                success: function( msg ) {
                    console.log(msg)
                    if(msg.status==0){
                        alert(msg.message);
                        location.reload();
                    }
                    if(msg.status==1){
                        alert(msg.message);
                        location.reload();
                    }
                }
            }); 
        }
    </script>
    @endsection
    @endsection         
