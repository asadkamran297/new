@extends('layouts.app')

@section('content')
<div class="container auth-page">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <form method="POST" action="{{ route('login') }}" autocomplete="off">
                @csrf
                <div class="form">
                    <div class="form-toggle"></div>
                    <div class="form-panel one">
                        <div class="form-header"><h1>Account Login</h1></div>
                        <div class="form-content">
                            <div class="form-group">
                                <label for="username">Email Address</label>
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus/>
                                @error('email')
                                <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">
                                @error('password')
                                <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label class="form-remember">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>Remember Me
                                </label>
                                @if (Route::has('password.request'))
                                <a class="form-recovery" href="{{ route('password.request') }}">{{ __('Forgot Your Password?') }}</a>
                                @endif
                            </div>
                            <div class="form-group"><button type="submit">Log In</button></div>
                            <div class="form-group mb-0">
                                @if (Route::has('register'))
                                <a class="form-recovery ml+-auto" href="{{ route('register') }}">{{ __('Create a new Account') }}</a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
