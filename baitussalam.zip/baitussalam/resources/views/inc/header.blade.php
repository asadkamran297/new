<header>
    <div class="footer-area d-flex">
        <a class="navbar-brand logo" href="#"><img src="{{ asset('img/logo-white.svg') }}" class="img-fluid logo-icon"></a>
        @if(auth()->user())
        <a class="btn menu-short" href="javascript:;">
            <i class="fa fa-arrow-right shortm-arrow" aria-hidden="true"></i>
        </a>
        @endif
    </div>
    <nav class="navbar navbar-expand-lg custom-navbar">
        <a class="navbar-brand logo d-md-none" href="#"><img src="{{ asset('img/logo-white.svg') }}" width="150" class="full-logo"></a>
        <div class="user-info-area">
            <div class="user-short-info">
                <div class="account-d">
                    <h4>{{(auth()->user())?auth()->user()->name:''}}</h4>
                </div>
            </div>
            <div class="account-settings ml-auto">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fwls-icon icon-14"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item full" href="{{ url('logout') }}">Logout</a>
                </div> 
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav flex-column mr-auto">
                @can('classIndex','1')
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('admin/class') }}">{{__('lang.classes')}}</a>
                </li>
                @endcan
                @can('subjectIndex','7')
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('admin/subject') }}">{{__('lang.subjects')}}</a>
                </li>
                @endcan
                @can('questionIndex','14')
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('admin/questions') }}">{{__('lang.question_head')}}</a>
                </li>
                @endcan
                @can('applicantIndex','21')
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('admin/applicants-listing') }}">{{__('lang.applicant_heading')}}</a>
                </li>
                @endcan
                @can('resultIndex','27')
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('admin/results') }}">{{__('lang.result_heading')}}</a>
                </li>
                @endcan
                <li class="nav-item">
                    @if(isset(auth()->user()->role) && (auth()->user()->role->id == 2) && isset(auth()->user()->applicants) && isset(auth()->user()->applicants->id))
                     <a class="nav-link" href="{{ route('admission_form',['id'=>auth()->user()->applicants->id]) }}">{{__('lang.applicant_user')}}</a>
                    @elseif(isset(auth()->user()->role) && (auth()->user()->role->id == 2) && isset(auth()->user()->applicants) && isset(auth()->user()->applicants->id))
                    <a class="nav-link" href="{{ url('AdmissionForm') }}">{{__('lang.applicant_user')}}</a>
                    @else

                    @endif
                    @can('quizHeaderIndex','43')
                    <a class="nav-link" href="{{ url('quiz') }}">{{__('lang.quiz_heading')}}</a>
                    @endcan
                    @can('quizHeaderIndex','43')
                    <a class="nav-link" href="{{ route('show_result') }}">{{__('lang.user_results')}}</a>
                </li>
                @endcan
                @can('userIndex','30')
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('admin.users.index')}}">{{__('lang.user_management')}}</a>
                </li>
                @endcan
                <li class="nav-item">
                    @can('roleIndex','33')
                    <a class="nav-link" href="{{ route('admin.roles.index')}}">{{__('lang.user_role_permission')}}</a>
                    @endcan
                    @can('permissionIndex','34')
                    <a class="nav-link" href="{{ route('admin.permissions.index')}}">{{__('lang.permissions')}}</a>
                    @endcan
                    @can('userroleIndex','39')
                    <a class="nav-link" href="{{ route('admin.roles-permissions.index')}}">{{__('lang.role_permission_manage')}}</a>
                    @endcan
                </li>
            </ul>
        </div>
    </nav>
</header>