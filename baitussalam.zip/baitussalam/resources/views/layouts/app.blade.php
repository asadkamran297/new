<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @section('stylesheet')
    @show
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Baitussalam') }}</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" />
    <link href="{{ asset('css/main.css') }}" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

</head>
</head>
<body class="bs-body">
    <div id="app" class="h-100">
        <main class="py-4 h-100">
            @include('inc.header')
            <div class="container-area">
                <div class="bg-light" style="width: calc(100% - 90px);position:fixed;bottom:0;padding:10px;right:0;z-index:2">
                    <div class="btn-group" style="width:max-content;margin-left:auto;display:flex;">
                        @php $locale = session()->get('locale'); @endphp
                        <button type="button" class="btn btn-secondary dropdown-toggle" style="background:transparent;color:#9357b7;border-color:#9357b7" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            @switch($locale)
                                @case('en')
                                 English
                                @break
                                @case('ur')
                                 Urdu
                                @break
                            @endswitch
                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="{{route('lang',['locale'=>'en'])}}">English</a>
                            <a class="dropdown-item" href="{{route('lang',['locale'=>'ur'])}}">Urdu</a>
                        </div>
                    </div>
                </div>
                <div class="container">
                    @include('inc.message')
                </div>
                @yield('content')
            </div>
        </main>
    </div>
    @section('scripts')
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <script src="{{ asset('js/app.js') }}" defer></script>
        <script src="{{ asset('js/main.js') }}" defer></script>
        <script src="https://use.fontawesome.com/22e73ae827.js"></script>
        @yield('custom-scripts')
    @show
</body>
</html>
