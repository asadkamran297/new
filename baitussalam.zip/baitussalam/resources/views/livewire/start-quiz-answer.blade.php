<div class="nquiz_Q">
    <strong> سوال {{++$questions_index}}:</strong>

    @if(isset($random_questions['assigned_questions']) && isset($random_questions['assigned_questions']->question_content))
    	{{$random_questions['assigned_questions']->question_content}}
    @endif
</div>

<div class="nquiz_A">
	@if(count($random_questions['answers']) > 0)
	@foreach($random_questions['answers'] as $a)
	@if(isset($a->content))
	    <label class="customcbx">
	        <input class="form-control" name="question-check" type="radio">
	        <span class="checkmark"><small class="count">{{++$loop->index}}</small> {{$a->content}}</span>
	    </label>
	@endif
    @endforeach
    @endif

    <button wire:click="next_question()">Next</button>
</div>