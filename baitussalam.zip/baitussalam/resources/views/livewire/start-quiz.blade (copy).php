<div class="nquiz_Q">
    <strong>سوال: </strong> لوریم اِپسم پرنٹنگ اور ٹائپسیٹنگ انڈسٹری کا صرف ڈمی متن ہے۔ لوریم ایپسم 1500s کے بعد سے ہی انڈسٹری کا معیاری ڈمی متن رہا ہے ، جب ایک نامعلوم پرنٹر ٹائپ کی ایک گیلی لے کر اس کو ٹکرا کر ٹائپ نمونہ کی کتاب بناتا ہے۔ یہ نہ صرف پانچ صدیوں سے زندہ بچا ہے ، بلکہ الیکٹرانک ٹائپ سیٹنگ میں بھی چھلانگ لگا سکتا ہے ، جو لازمی طور پر بدلا ہوا ہے۔ 1960 کی دہائی میں لورم ایپسم حصئوں پر مشتمل لیٹرسیٹ شیٹس کے اجراء کے ساتھ ہی ، اور حال ہی میں ایلڈس پیج میکر جیسے ڈیسک ٹاپ پبلشنگ سوفٹ ویئر کے ساتھ ، جس میں لوریم ایپسم کے ورژن شامل ہیں ، مقبول ہوا تھا؟
</div>

<div class="nquiz_A">
    <label class="customcbx">
        <input class="form-control" name="question-check" type="radio">
        <span class="checkmark"><small class="count">1</small> لورم ایپسم 1500s کے بعد سے ہی اس صنعت کا معیاری ڈمی متن رہا ہے۔</span>
    </label>
    <label class="customcbx">
        <input class="form-control" name="question-check" type="radio">
        <span class="checkmark"><small class="count">2</small> لورم ایپسم 1500s کے بعد سے ہی اس صنعت کا معیاری ڈمی متن رہا ہے۔</span>
    </label>
    <label class="customcbx">
        <input class="form-control" name="question-check" type="radio">
        <span class="checkmark"><small class="count">3</small> لورم ایپسم 1500s کے بعد سے ہی اس صنعت کا معیاری ڈمی متن رہا ہے۔</span>
    </label>
</div>