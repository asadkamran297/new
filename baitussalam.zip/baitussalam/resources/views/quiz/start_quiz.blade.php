@extends('layouts.app')

@section('stylesheet')
@parent
<style>
input,select{font-size:100%}
h1{font-size:3rem}
input{font-family:'Cutive Mono',monospace;border:0;border-radius:3px}
input:focus{outline:0}
input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
input[type=number]{-moz-appearance:textfield}
button{font-family:'Cutive Mono',monospace;color:#FFF;background:#8143a6;border:1px solid #FFF;border-radius:3px;width:90%;padding:10px;margin-left:10px}
button:focus{outline:0}
.timer{display:inline-flex;flex-direction:row;align-items:center;height:100%}
.inputs{display:flex;flex-direction:row;justify-content:space-between}
@media(max-width:768px){.inputs{display:flex;flex-direction:column;align-items:center}
}.start-time{width:100%;padding:6px;margin:5px}
@media(max-width:768px){.start-time{width:300px}
}.digits{display:flex;flex-direction:row}
.digits span{font-size:36px}
#progress{width:100%}
#bar{width:0;height:5px;background-color:#8143a6;text-align:end;line-height:5px;color:#FFF;transition:0.6s all linear}
#reset-btn{display:none}


/* Start Quiz Page Starts */
  .quiz-wrap{
    width: 100%;
    height: auto;
    position: relative;
    background: #fff;
    border-radius: 20px;
    padding: 30px 50px;  
  }
  .quiz-wrap img{
    max-height: 200px;
    margin: 10px 0 20px;
  }
  .quiz-wrap .quiz-info{
    margin: 20px 0 40px;
    font-size:14px;
    color:#666;
  }
  .quiz-wrap .quiz-info b{
    color: #333;
  }
  /* Start Quiz Page Ends */
  
</style>
@livewireStyles

@endsection

@section('content')
    <div class="enpage {{$lang_value}}">
        @livewire('start-quiz')
    </div>
@endsection 
@section('scripts')
@parent

@livewireScripts

<script src="{{ asset('js/yauk.min.js') }}"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
@endsection    