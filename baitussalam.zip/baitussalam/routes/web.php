<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/clear-all',function(){
	Artisan::call('config:clear');
	Artisan::call('config:cache');
	Artisan::call('view:clear');
	Artisan::call('route:clear');
});


Route::get('/', function () {
	return redirect()->route('login');
});

Auth::routes();
Route::group(['middleware' => 'languages'], function() {
	Route::group(['middleware' => 'auth'], function() {
		Route::get('/lang/{locale}','LocalizationController@localize')->name('lang');	
		Route::get('/home', 'HomeController@index')->name('home');
		Route::get('/logout', 'HomeController@logout')->name('logout');

		Route::group(['prefix'=>'admin','middleware'=>'admin'],function(){

			Route::get('/class', 'ClassController@index')->name('class');
			Route::get('/class/quiz-options/{class_id}', 'ClassController@quizOptions')->name('class.quiz_options');
			Route::post('/class/quiz-options', 'ClassController@quizOptionsUp')->name('class.quiz_options_up');
			Route::post('class/update-class','ClassController@updateStatus')->name('class.update_class');
			Route::get('class/edit/{id}', 'ClassController@edits')->name('class.edit');
			Route::resource('class', 'ClassController',
				['only' => ['create', 'store', 'update', 'destroy']]);

			Route::get('/subject', 'SubjectController@index')->name('subject');
			Route::get('subject/edit/{id}', 'SubjectController@edits')->name('subject.edit');
			Route::resource('subject', 'SubjectController',
				['only' => ['create', 'store', 'update', 'destroy']]);
			Route::get('is-active-subject','SubjectController@is_active_subject');

			Route::get('/questions','QuestionController@index')->name('questions');
			Route::get('is-active','QuestionController@is_active_question');
			Route::get('add-question','QuestionController@add_question');
			Route::get('quiz','QuestionController@quiz');
			Route::get('quiz-re-attempt/{entry_test_id}','QuestionController@allowReattempt')->name('admin.re_attempt');

			Route::post('save-question','QuestionController@save_question');
			Route::get('edit-question/{id}','QuestionController@edit_question');
			Route::post('update-question','QuestionController@update_question');
			Route::get('delete-question/{id}','QuestionController@destroy');

			Route::get('/applicants-listing','AdmissionController@index')->name('applicants');
			Route::get('is-allowed','AdmissionController@applicant_allowed_quiz')->name('is_allowed');
			Route::get('edit-admission-form/{id}','AdmissionController@edit_admission_form');
			Route::post('update-admission-form','AdmissionController@update_admission_form');

			Route::get('results','QuizController@results')->name('results');
			Route::get('quiz-history/{user_id}','QuizController@quizHistory')->name('admin.quiz_history');
			Route::get('quiz-history-detail/{entry_test_id}','QuizController@quizHistoryDetail')->name('admin.quiz.history_detail');
			Route::get('results-listing/{class_id}','QuizController@results_listing')->name('results-listing');
			Route::get('results-detail/{entry_test_id}/{user_id}','QuizController@results_detail')->name('results-detail');

			Route::group(['namespace'=>'Admin','middleware'=>'admin','as'=>'admin.'],function(){	
				Route::resource('users','UserController');
				Route::post('users/update_status','UserController@updateStatus')->name('users.update_status');
				Route::post('users/update_role','UserController@updateRole')->name('users.update_role');
				/*user role permission start*/
				Route::resource('roles','RoleController');
				Route::post('roles/update_status','RoleController@updateStatus')->name('roles.update_status');
				Route::resource('permissions','PermissionController');
				Route::resource('roles-permissions','RolePermissionController');
				/*user role permission end*/
			});
		});


		Route::get('AdmissionForm','AdmissionController@admission_form');
		Route::get('AdmissionForm/{id}','AdmissionController@edit_admission_form_applicant')->name('admission_form');
		Route::post('admission-submit-form','AdmissionController@admission_submit_form');
		Route::get('session-delete','QuestionController@session_flush');


		/* Quiz Controller Routes Starts */
		Route::get('quiz','QuizController@quiz')->name('quiz');
		Route::post('add-quiz','QuizController@add_quiz')->name('add-quiz');
		Route::get('start-quiz','QuizController@start_quiz')->name('start_quiz');
		Route::view('thank-you','quiz.thank_you')->name('thank-you');
		Route::get('result','ClassController@showResult')->name('show_result');
		Route::get('update-quiz-time','QuizController@updateQuizTime')->name('user.update_quiz_time');
		/* Quiz Controller Routes Ends */

	});
});