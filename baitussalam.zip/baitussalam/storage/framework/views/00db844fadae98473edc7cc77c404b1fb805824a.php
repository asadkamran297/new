<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
  <div class="inner-head">
    <div class="inner-head">
      <h4><?php echo e(__('lang.question_data')); ?></h4>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionAdd','15')): ?>
      <a class="btn btn-primary btn-global" href="<?php echo e(url('admin/add-question')); ?>"><?php echo e(__('lang.add_question')); ?></a>
      <?php endif; ?>
    </div>
  </div>
      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                <thead class="thead-light">
                  <tr>
                    <th><?php echo e(__('lang.id')); ?></th>
                    <th><?php echo e(__('lang.question_name')); ?></th>
                    <th><?php echo e(__('lang.subject_name')); ?></th>
                    <th><?php echo e(__('lang.date')); ?></th>
                    <th><?php echo e(__('lang.is_active_question')); ?></th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionEdit','23')): ?>
                    <th><?php echo e(__('lang.edit')); ?></th>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionDestroy','19')): ?>
                    <th><?php echo e(__('lang.delete')); ?></th>
                    <?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th><?php echo e($row->id); ?></th>
                    <td><?php echo e($row->question_content); ?></td>
                    <td><?php echo e(isset($row->subjects->title)?$row->subjects->title:''); ?></td>
                    <td><?php echo e(date('d-m-Y',strtotime($row->created_at))); ?></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionStatusUpdate','20')): ?>
                    <td>
                      <?php if($row->is_active==1): ?>
                      <span class="badge badge-success"><?php echo e(__('lang.active')); ?></span>
                      <?php else: ?> 
                      <span class="badge badge-danger"><?php echo e(__('lang.deactive')); ?></span>
                      <?php endif; ?>
                      <input type="checkbox" id="myCheck" onclick='is_active("<?php echo e($row->id); ?>",this)' <?php echo e((isset($row->is_active) && $row->is_active == 1 )?'checked':''); ?>></td>
                    <?php endif; ?>  
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionEdit','23 ')): ?>
                    <td><a class="btn btn-primary btn-global-icon-outline" href="edit-question/<?php echo e($row->id); ?>" title="<?php echo e(__('lang.edit')); ?>"><i class="fa fa-pencil"></i></a> 
                    </td>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionDestroy','19')): ?>
                    <td><a class="btn btn-danger btn-global-table" onclick="return confirm('Are you sure you want to delete?')" href="delete-question/<?php echo e($row->id); ?>"><?php echo e(__('lang.delete')); ?></a></td>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                </tbody>
              </table>
            </div>
          </div>    
        </div>
      </div>
<?php $__env->stopSection(); ?>         
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>

function is_active(question_id,instance)
{     
     var checkBox = $(instance).is(':checked'); 
        $.ajax({
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      type: "GET",
      url: '<?php echo e(url('/admin/is-active')); ?>',
      data: { status  :checkBox,question_id: question_id }, 
      success: function( msg ) {
      // alert('Updated');
       location.reload();
      }
    }); 
    
} 
</script>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/question/question-selection.blade.php ENDPATH**/ ?>