<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head"><h4><?php echo e(__('lang.edit_class')); ?></h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('class.update',$class->id)); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select <?php echo e($lang_field); ?>" name="class_name">
                                            <option value="پہلی سطح"<?php echo e(($class->class_name == 'پہلی سطح')?'selected':''); ?>>پہلی سطح</option>
                                            <option value="دوسری سطح"<?php echo e(($class->class_name == 'دوسری سطح')?'selected':''); ?>>دوسری سطح</option>
                                            <option value="تیسری سطح"<?php echo e(($class->class_name == 'تیسری سطح')?'selected':''); ?>>تیسری سطح</option>
                                            <option value="چوتھی سطح"<?php echo e(($class->class_name == 'چوتھی سطح')?'selected':''); ?>>چوتھی سطح</option>
                                            <option value="پانچویں سطح"<?php echo e(($class->class_name == 'پانچویں سطح')?'selected':''); ?>>پانچویں سطح</option>
                                            <option value="چھٹی سطح"<?php echo e(($class->class_name == 'چھٹی سطح')?'selected':''); ?>>چھٹی سطح</option>
                                            <option value="ساتویں سطح"<?php echo e(($class->class_name == 'ساتویں سطح')?'selected':''); ?>>ساتویں سطح</option>
                                            <option value=">آٹھویں سطح"<?php echo e(($class->class_name == '>آٹھویں سطح')?'selected':''); ?>>آٹھویں سطح</option>
                                            <option value="نویں سطح"<?php echo e(($class->class_name == 'نویں سطح')?'selected':''); ?>>نویں سطح</option>
                                        </select>
                                        <div class="custom-label"><?php echo e(__('lang.class_name')); ?></div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select <?php echo e($lang_field); ?>" name="minimum_age_limit">
                                            <option value="چار سال"<?php echo e(($class->minimum_age_limit == 'چار سال')?'selected':''); ?>>چار سال</option>
                                            <option value="پانچ سال"<?php echo e(($class->minimum_age_limit == 'پانچ سال')?'selected':''); ?>>پانچ سال</option>
                                            <option value="چھ سال"<?php echo e(($class->minimum_age_limit == 'چھ سال')?'selected':''); ?>>چھ سال</option>
                                            <option value="سات سال"<?php echo e(($class->minimum_age_limit == 'سات سال')?'selected':''); ?>>سات سال</option> 
                                        </select>
                                        <div class="custom-label"><?php echo e(__('lang.minimum_age_limit')); ?></div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select <?php echo e($lang_field); ?>" name="maximum_age_limit">
                                            <option value="آٹھ سال"<?php echo e(($class->maximum_age_limit == 'آٹھ سال')?'selected':''); ?>>آٹھ سال</option>
                                            <option value="نو سال"<?php echo e(($class->maximum_age_limit == 'نو سال')?'selected':''); ?>>نو سال</option>
                                            <option value="دس سال"<?php echo e(($class->maximum_age_limit == 'دس سال')?'selected':''); ?>>دس سال</option>
                                            <option value="گیارہ سال"<?php echo e(($class->maximum_age_limit == 'گیارہ سال')?'selected':''); ?>>گیارہ سال</option> 
                                        </select>
                                        <div class="custom-label"><?php echo e(__('lang.maximum_age_limit')); ?></div>
                                    </div>
                                </div>
                                
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <input class="form-control" required="" type="number" value="<?php echo e(old('question_limit',$class->question_limit)); ?>" name="question_limit" min="1" max="200">
                                        <div class="custom-label">Question Limit </div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <label>Quiz Time</label>
                                        <input type="time" name="quiz_time" value="<?php echo e(old('question_limit',$class->quiz_time)); ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <label for="allow_rand"><input type="checkbox" <?php if($class->random_question && $class->random_question==1): ?>checked="" <?php else: ?> <?php endif; ?> id="allow_rand" name="random_question">
                                        Manual Question Selection</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classUpdate', '5')): ?>
                                <button type="submit" class="btn btn-primary btn-global mx-auto"><?php echo e(__('lang.update_class')); ?></button>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div><br>
        <div class="container-fluid">
            <div class="card mb-3">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                            <?php
                            $class_quiz_ad = $class['quiz_questions']->pluck('question_id')->toArray();
                            ?>
                            <?php if(isset($class['subjects']) && count($class['subjects'])): ?>
                            <?php $__currentLoopData = $class['subjects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($row['questions']) && count($row['questions'])): ?>
                            <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                                <thead class="thead-light">
                                    <tr>
                                        <th> Subject:  <?php echo e($row->title ?? ""); ?></th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $row['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr>
                                        <td><label for="<?php echo e($question->id); ?>"><input id="<?php echo e($question->id); ?>" <?php if(in_array($question->id, $class_quiz_ad)): ?> checked="" <?php else: ?> <?php endif; ?> type="checkbox" name="quiz_questions[]" value="<?php echo e($question->id); ?>"> <?php echo e($question->question_content); ?> </label></td>
                                    </tr>          
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>    
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
<?php $__env->stopSection(); ?> 	
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/class/update-class.blade.php ENDPATH**/ ?>