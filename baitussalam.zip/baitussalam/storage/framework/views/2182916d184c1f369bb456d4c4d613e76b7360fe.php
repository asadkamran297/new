<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4>Quiz History</h4>  
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th><?php echo e(__('lang.id')); ?></th>
                                <th>Attempted Date Time</th>
                                <th>View Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($quizes) && count($quizes) > 0): ?>
                            <?php $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e(date('d-m-Y h:i:s',strtotime($quiz->updated_at))); ?></td>
                                <td><a href="<?php echo e(route('admin.quiz.history_detail',['entry_test_id'=>$quiz->id])); ?>">View Details</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/results/quiz_history.blade.php ENDPATH**/ ?>