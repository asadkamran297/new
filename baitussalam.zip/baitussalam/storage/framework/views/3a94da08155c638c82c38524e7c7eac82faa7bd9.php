<style type="text/css">
.invalid-feedback{
display: block !important;
}
</style>
<?php if($errors->has($field)): ?>
<span class="invalid-feedback" role="alert">
<strong><?php echo e($errors->first($field)); ?></strong>
</span>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/inc/form-error.blade.php ENDPATH**/ ?>