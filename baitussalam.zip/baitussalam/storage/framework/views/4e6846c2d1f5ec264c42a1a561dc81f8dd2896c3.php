<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head"><h4><?php echo e(__('lang.add_permission')); ?></h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" <?php if(isset($permission)): ?> action="<?php echo e(route('admin.permissions.update',['permission'=>$permission->id])); ?>" <?php else: ?> action="<?php echo e(route('admin.permissions.store')); ?>" <?php endif; ?>>
                            <?php if(isset($permission)): ?>
                            <?php echo method_field('put'); ?>
                            <?php else: ?>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-8 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="title" required="" value="<?php echo e(old('title',isset($permission->title) ? $permission->title : "")); ?>" placeholder="title" />
                                        <?php echo $__env->make('inc.form-error',['field'=>'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="custom-label"><?php echo e(__('lang.title')); ?></div>
                                    </div>
                                </div>
                            </div>                        
                            <div class="form-row">
                                <button type="submit" class="btn btn-primary btn-global mx-auto"><?php if(isset($permission)): ?> <?php echo e(__('lang.update')); ?> <?php else: ?> <?php echo e(__('lang.add')); ?> <?php endif; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/permissions/add_edit.blade.php ENDPATH**/ ?>