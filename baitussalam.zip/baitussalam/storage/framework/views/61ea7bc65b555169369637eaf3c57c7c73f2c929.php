<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4><?php echo e(__('lang.admission_heading')); ?></h4>
    </div>
    <div class="container admissionf-page">
        <div class="card">
            <div class="card-body">
                  <input type="hidden" name="applicant_id" value="<?php echo e($applicant_id); ?>">
                    <div class="form-row" readonly>
                      <?php
                      $c_sec = explode(',',$app->class_selection);
                      ?>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.dars_nizami')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.dars_nizami')); ?>" <?php echo e(in_array(__('lang.dars_nizami'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.matric')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.matric')); ?>" <?php echo e(in_array(__('lang.matric'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.qadeem')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.qadeem')); ?>" <?php echo e(in_array(__('lang.qadeem'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.jadeed')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.jadeed')); ?>" <?php echo e(in_array(__('lang.jadeed'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="name" placeholder="نام" value="<?php echo e($app->name); ?>" required readonly/>
                                <div class="custom-label"><?php echo e(__('lang.name')); ?></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="f_name" placeholder="والد کا نام" value="<?php echo e($app->father_name); ?>" readonly/>
                                <div class="custom-label"><?php echo e(__('lang.father')); ?></div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                          <div class="createp_row">
                            <input type="text" class="form-control createp_input <?php echo e($lang_field); ?> dob" name="dob" placeholder="پیدائش کی تاریخ" value="<?php echo e($app->dob); ?>" readonly/>
                            <div class="custom-label"><?php echo e(__('lang.dob')); ?></div>
                        </div>
                    </div>
                    <div class="form-group col-md-4 mx-auto">
                      <div class="createp_row select-row">
                          <select class="form-control createp_select" name="class_id" readonly>
                              <option value=""></option>
                              <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($cl->is_active == 1): ?>
                              <option value="<?php echo e($cl->id); ?>"<?php echo e($cl->id == $app->classes->id ? 'selected':''); ?>><?php echo e($cl->class_name); ?></option>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                          <div class="custom-label"><?php echo e(__('lang.classes')); ?></div>
                      </div>
                  </div>
                  <div class="form-group col-md-4">
                      <div class="createp_row">
                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="city" placeholder="شہریت" value="<?php echo e($app->city); ?>" readonly/>
                        <div class="custom-label"><?php echo e(__('lang.city')); ?></div>
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <div class="createp_row">
                      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e($app->phone); ?>" readonly/>
                      <div class="custom-label"><?php echo e(__('lang.mobile')); ?></div>
                  </div>
              </div>
              <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="present_address" placeholder="موجودہ پتہ" value="<?php echo e($app->address); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.present_address')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="permanent_address" placeholder="مستقل پتہ" value="<?php echo e($app->permanent_address); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.permanent_address')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="student_cnic" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e($app->cnic); ?>" readonly />
                    <div class="custom-label"><?php echo e(__('lang.cnic')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="islamic_education" placeholder="اسلامی تعلیم" value="<?php echo e($app->islamic_education); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.islamic_education')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="previous_institute" placeholder="پچھلا اسکول" value="<?php echo e($app->previous_institute_name); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.old_school')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="previous_institute_left_reason" placeholder="اسکول چھوڑنے کی وج" value="<?php echo e($app->previous_institute_left_reason); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.leave_school_reason')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="basic_education" placeholder="اسکول کی تعلیم" value="<?php echo e($app->basic_education); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.school_education')); ?></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="f-sub-hd"><?php echo e(__('lang.guardian_heading')); ?></h3>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-3">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="name" placeholder="نام" value="<?php echo e($app->gaurdians->guardian_name); ?>" readonly/>
                    <div class="custom-label"><?php echo e(__('lang.name')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-3">
                <div class="createp_row">
                  <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="father_name" placeholder="والد کا نام" value="<?php echo e($app->gaurdians->guardian_f_name); ?>" readonly/>
                  <div class="custom-label"><?php echo e(__('lang.father_name')); ?></div>
              </div>
          </div>
          <div class="form-group col-md-3">
            <div class="createp_row">
              <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="city" placeholder="شہریت" value="<?php echo e($app->gaurdians->city); ?>" readonly/>
              <div class="custom-label"><?php echo e(__('lang.city')); ?></div>
          </div>
      </div>
      <div class="form-group col-md-3">
        <div class="createp_row">
          <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="applicant_relation" placeholder="طالب علم سے رشتہ" value="<?php echo e($app->gaurdians->applicant_relation); ?>" readonly/>
          <div class="custom-label"><?php echo e(__('lang.relation_with_student')); ?></div>
      </div>
  </div>
  <div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="occupation" placeholder="پیشہ" value="<?php echo e($app->gaurdians->occupation); ?>" readonly/>
      <div class="custom-label"><?php echo e(__('lang.profession')); ?></div>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="position" placeholder="عہدہ / پوسٹ" value="<?php echo e($app->gaurdians->position); ?>" readonly/>
      <div class="custom-label"><?php echo e(__('lang.position')); ?></div>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="contact_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e($app->gaurdians->phone); ?>" readonly/>
      <div class="custom-label"><?php echo e(__('lang.guardian_mobile')); ?></div>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="guardian_cnic" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e($app->gaurdians->father_cnic); ?>" readonly/>
        <div class="custom-label"><?php echo e(__('lang.cnic')); ?></div>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="p_address" placeholder="پتہ" value="<?php echo e($app->gaurdians->address); ?>" readonly />
        <div class="custom-label"><?php echo e(__('lang.address')); ?></div>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="another_guardian_name" placeholder="Another Guardian Name"  value="<?php echo e($app->gaurdians->another_guardian_name); ?>" readonly/>
        <div class="custom-label"><?php echo e(__('lang.another_guardian')); ?></div>
    </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X"value="<?php echo e($app->gaurdians->mobile_no); ?>" readonly/>
      <div class="custom-label"><?php echo e(__('lang.mobile_interagent')); ?></div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <h3 class="f-sub-hd"><?php echo e(__('lang.other_info')); ?></h3>
</div>
</div>
<div class="form-row">
  <div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">1. <?php echo e(__('lang.question_1')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[0]" value="<?php echo e($app->applicant_answers[0]->applicant_answer ?? ""); ?>" readonly/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">2. <?php echo e(__('lang.question_2')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name ="question_ans[1]" value="<?php echo e($app->applicant_answers[1]->applicant_answer ?? ""); ?>" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" readonly />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">3. <?php echo e(__('lang.question_3')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[2]" value="<?php echo e($app->applicant_answers[2]->applicant_answer ?? ""); ?>" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" readonly/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">4. <?php echo e(__('lang.question_4')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[3]" value="<?php echo e($app->applicant_answers[3]->applicant_answer ?? ""); ?>" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" readonly/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">5. <?php echo e(__('lang.question_5')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[4]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="<?php echo e($app->applicant_answers[4]->applicant_answer ?? ""); ?>" readonly/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">6. <?php echo e(__('lang.question_6')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[5]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="<?php echo e($app->applicant_answers[5]->applicant_answer ?? ""); ?>" readonly/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">7. <?php echo e(__('lang.question_7')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[6]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="<?php echo e($app->applicant_answers[6]->applicant_answer ?? ""); ?>" readonly/>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <p class="form-content">8. <?php echo e(__('lang.instruction_1')); ?></p>
    <p class="form-content">9. <?php echo e(__('lang.instruction_2')); ?></p>
</div>

</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
<script>
    $('.urdu-field').setUrduInput({urduNumerals: true});
    $(':input').inputmask();
    $('.dob').datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: "-100Y",
        maxDate: '-2Y',
        yearRange: "-100:-2"
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/admission/edit-admission-form-applicant.blade.php ENDPATH**/ ?>