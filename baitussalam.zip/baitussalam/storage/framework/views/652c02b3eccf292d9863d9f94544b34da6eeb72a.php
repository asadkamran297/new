<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4><?php echo e(__('lang.applicant_data')); ?></h4>
        
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th><?php echo e(__('lang.id')); ?></th>
                                <th><?php echo e(__('lang.class_name')); ?></th>
                                <th><?php echo e(__('lang.name')); ?></th>
                                <th><?php echo e(__('lang.father_name')); ?></th>
                                <th><?php echo e(__('lang.city')); ?></th>
                                <th><?php echo e(__('lang.phone_number')); ?></th>
                                <th><?php echo e(__('lang.cnic')); ?></th>
                                <th><?php echo e(__('lang.date')); ?></th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantStatusUpdate','26')): ?>
                                <th><?php echo e(__('lang.allow_applicant')); ?></th>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantEdit', '23')): ?>
                                <th></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e(isset($row->id)?$row->id:''); ?></th>
                                <td><?php echo e(isset($row->classes->class_name)?$row->classes->class_name:''); ?></td>
                                <td><?php echo e(isset($row->name)?$row->name:''); ?></td>
                                <td><?php echo e(isset($row->father_name)?$row->father_name:''); ?></td>
                                <td><?php echo e(isset($row->city)?$row->city:''); ?></td>
                                <td><?php echo e(isset($row->phone)?$row->phone:''); ?></td>
                                <td><?php echo e(isset($row->cnic)?$row->cnic:''); ?></td>
                                <td><?php echo e(date('d-m-Y',strtotime($row->created_at))); ?></td>
                                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantStatusUpdate','26')): ?>
                                <td>
                                    <?php if($row->is_allowed==1): ?>
                                    <span class="badge badge-success"><?php echo e(__('lang.active')); ?></span>
                                    <?php else: ?> 
                                    <span class="badge badge-danger"><?php echo e(__('lang.deactive')); ?></span>
                                    <?php endif; ?>
                                    <input type="checkbox" id="myCheck" onclick='is_allowed("<?php echo e($row->id); ?>",this)' <?php echo e((isset($row->is_allowed) && $row->is_allowed == 1 )?'checked':''); ?>>
                                </td>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantEdit', '23')): ?>
                                <td>
                                    <a class="btn btn-primary btn-global-icon-outline" href="edit-admission-form/<?php echo e($row->id); ?>" title="<?php echo e(__('lang.edit')); ?>"><i class="fa fa-pencil"></i></a> 
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    function is_allowed(applicant_id,instance){
        var checkBox = $(instance).is(':checked'); 
        $.ajax({
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            type: "GET",
            url: '<?php echo e(url('/admin/is-allowed')); ?>',
            data: { status  :checkBox,applicant_id: applicant_id }, 
            success: function( msg ) {
                location.reload();
            }
        }); 
    } 
</script>
<?php $__env->stopSection(); ?>         

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/admission/applicant-listing.blade.php ENDPATH**/ ?>