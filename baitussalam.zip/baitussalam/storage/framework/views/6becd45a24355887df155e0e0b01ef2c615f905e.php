<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4>Result Summary</h4>
    </div>
    <div class="content-area">
        <div class="npage nquiz-page">
            <div class="container">
                <?php if(isset($attempts) && count($attempts) > 0): ?>
                <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="question-area">
                    <div class="nquiz_Q">
                        <strong>سوال نمبر <?php echo e($loop->iteration); ?>:</strong> <?php echo e(isset($da->question->question_content) && !empty($da->question->question_content) ? $da->question->question_content : ''); ?>

                    </div>
                    <?php if(isset($da->answer) && $da->answer): ?>
                    <div class="nquiz_A">
                        <div class="nquiz_ya mb-2">
                            <label>Submitted Answer</label>
                            <?php if($da['is_true']==1): ?>
                            <p class="correct-ans"><?php echo e(isset($da->answer->content) && !empty($da->answer->content) ? $da->answer->content : ''); ?></p>
                            <?php else: ?>
                            <p class="wrong-ans"><?php echo e(isset($da->answer->content) && !empty($da->answer->content) ? $da->answer->content : ''); ?></p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <?php endif; ?>
                    <hr />
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/results/quiz_history_detail.blade.php ENDPATH**/ ?>