<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
  <div class="inner-head">
    <h4><?php echo e(__('lang.result_heading')); ?></h4>
  </div>
  <div class="container-fluid">
    <div class="card mb-3">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
            <thead class="thead-light">
              <tr>
                <th><?php echo e(__('lang.id')); ?></th>
                <th><?php echo e(__('lang.class_name')); ?></th>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('resultEdit', '28')): ?>
                <th><i class="fa fa-pencil"></i></th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
              <?php if(isset($classes) && count($classes) > 0): ?>
              <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e(isset($cl->id) ? $cl->id : '---'); ?></th>
                <td><?php echo e(isset($cl->class_name) ? $cl->class_name : '---'); ?></td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('resultEdit', '28')): ?>
                <td><a class="btn btn-primary btn-global-icon-outline" href="<?php echo e(url('/admin/results-listing/'.$cl->id)); ?>" title=""><i class="fa fa-pencil"></i></a></td>
                <?php endif; ?>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>         

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/results/results.blade.php ENDPATH**/ ?>