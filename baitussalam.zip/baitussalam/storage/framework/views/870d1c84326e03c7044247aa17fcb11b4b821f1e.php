<header>
    <div class="footer-area d-flex">
        <a class="navbar-brand logo" href="#"><img src="<?php echo e(asset('img/logo-white.svg')); ?>" class="img-fluid logo-icon"></a>
        <?php if(auth()->user()): ?>
        <a class="btn menu-short" href="javascript:;">
            <i class="fa fa-arrow-right shortm-arrow" aria-hidden="true"></i>
        </a>
        <?php endif; ?>
    </div>
    <nav class="navbar navbar-expand-lg custom-navbar">
        <a class="navbar-brand logo d-md-none" href="#"><img src="<?php echo e(asset('img/logo-white.svg')); ?>" width="150" class="full-logo"></a>
        <div class="user-info-area">
            <div class="user-short-info">
                <div class="account-d">
                    <h4><?php echo e((auth()->user())?auth()->user()->name:''); ?></h4>
                </div>
            </div>
            <div class="account-settings ml-auto">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fwls-icon icon-14"></i>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item full" href="<?php echo e(url('logout')); ?>">Logout</a>
                </div> 
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav flex-column mr-auto">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classIndex','1')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/class')); ?>"><?php echo e(__('lang.classes')); ?></a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subjectIndex','7')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/subject')); ?>"><?php echo e(__('lang.subjects')); ?></a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('questionIndex','14')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/questions')); ?>"><?php echo e(__('lang.question_head')); ?></a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantIndex','21')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/applicants-listing')); ?>"><?php echo e(__('lang.applicant_heading')); ?></a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('resultIndex','27')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('admin/results')); ?>"><?php echo e(__('lang.result_heading')); ?></a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <?php if(isset(auth()->user()->role) && (auth()->user()->role->id == 2) && isset(auth()->user()->applicants) && isset(auth()->user()->applicants->id)): ?>
                     <a class="nav-link" href="<?php echo e(route('admission_form',['id'=>auth()->user()->applicants->id])); ?>"><?php echo e(__('lang.applicant_user')); ?></a>
                    <?php elseif(isset(auth()->user()->role) && (auth()->user()->role->id == 2) && isset(auth()->user()->applicants) && isset(auth()->user()->applicants->id)): ?>
                    <a class="nav-link" href="<?php echo e(url('AdmissionForm')); ?>"><?php echo e(__('lang.applicant_user')); ?></a>
                    <?php else: ?>

                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quizHeaderIndex','43')): ?>
                    <a class="nav-link" href="<?php echo e(url('quiz')); ?>"><?php echo e(__('lang.quiz_heading')); ?></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quizHeaderIndex','43')): ?>
                    <a class="nav-link" href="<?php echo e(route('show_result')); ?>"><?php echo e(__('lang.user_results')); ?></a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('userIndex','30')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('lang.user_management')); ?></a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roleIndex','33')): ?>
                    <a class="nav-link" href="<?php echo e(route('admin.roles.index')); ?>"><?php echo e(__('lang.user_role_permission')); ?></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissionIndex','34')): ?>
                    <a class="nav-link" href="<?php echo e(route('admin.permissions.index')); ?>"><?php echo e(__('lang.permissions')); ?></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('userroleIndex','39')): ?>
                    <a class="nav-link" href="<?php echo e(route('admin.roles-permissions.index')); ?>"><?php echo e(__('lang.role_permission_manage')); ?></a>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </nav>
</header><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/inc/header.blade.php ENDPATH**/ ?>