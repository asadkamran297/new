<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4><?php echo e(__('lang.admission_heading')); ?></h4>
    </div>
    <div class="container admissionf-page">
        <div class="card">
            <div class="card-body">
                <form method="post" action="<?php echo e(url('admin/update-admission-form')); ?>" autocomplete="off">
                  <input type="hidden" name="applicant_id" value="<?php echo e($applicant_id); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                      <?php
                      $c_sec = explode(',',$app->class_selection);
                      ?>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.dars_nizami')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.dars_nizami')); ?>" <?php echo e(in_array(__('lang.dars_nizami'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.matric')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.matric')); ?>" <?php echo e(in_array(__('lang.matric'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.qadeem')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.qadeem')); ?>" <?php echo e(in_array(__('lang.qadeem'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.jadeed')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.jadeed')); ?>" <?php echo e(in_array(__('lang.jadeed'),$c_sec) ? "checked" : ""); ?>>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="n_name" placeholder="نام" value="<?php echo e(old('n_name',$app->name)); ?>" required />
                                <div class="custom-label"><?php echo e(__('lang.name')); ?></div>
                                 <?php echo $__env->make('inc.form-error',['field'=>'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="f_name" placeholder="والد کا نام" value="<?php echo e(old('f_name',$app->father_name)); ?>" />
                                <div class="custom-label"><?php echo e(__('lang.father')); ?></div>
                                 <?php echo $__env->make('inc.form-error',['field'=>'f_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                          <div class="createp_row">
                            <input type="text" class="form-control createp_input <?php echo e($lang_field); ?> dob" name="dob" placeholder="پیدائش کی تاریخ" value="<?php echo e(old('dob',$app->dob)); ?>" />
                            <div class="custom-label"><?php echo e(__('lang.dob')); ?></div>
                            <?php echo $__env->make('inc.form-error',['field'=>'dob'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group col-md-4 mx-auto">
                      <div class="createp_row select-row">
                          <select class="form-control createp_select" name="class_id" required>
                              <option value="">---</option>
                              <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($cl->id); ?>"<?php echo e($cl->id == $app->classes->id ? 'selected':''); ?>><?php echo e($cl->class_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                          <div class="custom-label"><?php echo e(__('lang.classes')); ?></div>
                          <?php echo $__env->make('inc.form-error',['field'=>'class_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </div>
                  </div>
                  <div class="form-group col-md-4">
                      <div class="createp_row">
                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="city" placeholder="شہریت" value="<?php echo e(old('city',$app->city)); ?>" />
                        <div class="custom-label"><?php echo e(__('lang.city')); ?></div>
                        <?php echo $__env->make('inc.form-error',['field'=>'city'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <div class="createp_row">
                      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e($app->phone); ?>" />
                      <div class="custom-label"><?php echo e(__('lang.mobile')); ?></div>
                      <?php echo $__env->make('inc.form-error',['field'=>'mobile_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
              </div>
              <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="present_address" placeholder="موجودہ پتہ" value="<?php echo e(old('address',$app->address)); ?>" />
                    <div class="custom-label"><?php echo e(__('lang.present_address')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'present_address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="permanent_address" placeholder="مستقل پتہ" value="<?php echo e(old('permanent_address',$app->permanent_address)); ?>"/>
                    <div class="custom-label"><?php echo e(__('lang.permanent_address')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'permanent_address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="student_cnic" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e(old('cnic',$app->cnic)); ?>"  />
                    <div class="custom-label"><?php echo e(__('lang.cnic')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="islamic_education" placeholder="اسلامی تعلیم" value="<?php echo e(old('islamic_education',$app->islamic_education)); ?>"/>
                    <div class="custom-label"><?php echo e(__('lang.islamic_education')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'islamic_education'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="previous_institute" placeholder="پچھلا اسکول" value="<?php echo e(old('previous_institute',$app->previous_institute_name)); ?>"/>
                    <div class="custom-label"><?php echo e(__('lang.old_school')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'previous_institute'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="previous_institute_left_reason" placeholder="اسکول چھوڑنے کی وج" value="<?php echo e(old('previous_institute_left_reason',$app->previous_institute_left_reason)); ?>"/>
                    <div class="custom-label"><?php echo e(__('lang.leave_school_reason')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'previous_institute_left_reason'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="basic_education" placeholder="اسکول کی تعلیم" value="<?php echo e(old('basic_education',$app->basic_education)); ?>" />
                    <div class="custom-label"><?php echo e(__('lang.school_education')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'basic_education'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="f-sub-hd"><?php echo e(__('lang.guardian_heading')); ?></h3>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-3">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="u_f_name" placeholder="نام" value="<?php echo e(old('u_f_name',isset($app->gaurdians->guardian_name)?$app->gaurdians->guardian_name:'')); ?>" />
                    <div class="custom-label"><?php echo e(__('lang.name')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-3">
                <div class="createp_row">
                  <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="u_father_name" placeholder="والد کا نام" value="<?php echo e(old('u_father_name', isset($app->gaurdians->guardian_f_name) ? $app->gaurdians->guardian_f_name : "")); ?>">
                  <div class="custom-label"><?php echo e(__('lang.father_name')); ?></div>
                  <?php echo $__env->make('inc.form-error',['field'=>'father_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
          </div>
          <div class="form-group col-md-3">
            <div class="createp_row">
              <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="u_city" placeholder="شہریت" value="<?php echo e(old('u_city',isset($app->gaurdians->city)?$app->gaurdians->city:'')); ?>">
              <div class="custom-label"><?php echo e(__('lang.city')); ?></div>
          </div>
      </div>
      <div class="form-group col-md-3">
        <div class="createp_row">
          <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="applicant_relation" placeholder="طالب علم سے رشتہ" value="<?php echo e(old('applicant_relation',isset($app->gaurdians->applicant_relation)?$app->gaurdians->applicant_relation:'')); ?>" />
          <div class="custom-label"><?php echo e(__('lang.relation_with_student')); ?></div>
          <?php echo $__env->make('inc.form-error',['field'=>'applicant_relation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  </div>
  <div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="occupation" placeholder="پیشہ" value="<?php echo e(old('occupation',isset($app->gaurdians->occupation)?$app->gaurdians->occupation:'')); ?>" />
      <div class="custom-label"><?php echo e(__('lang.profession')); ?></div>
      <?php echo $__env->make('inc.form-error',['field'=>'occupation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="position" placeholder="عہدہ / پوسٹ" value="<?php echo e(old('position',isset($app->gaurdians->position)?$app->gaurdians->position:'')); ?>" />
      <div class="custom-label"><?php echo e(__('lang.position')); ?></div>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="contact_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e(old('contact_no',isset($app->gaurdians->phone)?$app->gaurdians->phone:'')); ?>" />
      <div class="custom-label"><?php echo e(__('lang.guardian_mobile')); ?></div>
      <?php echo $__env->make('inc.form-error',['field'=>'contact_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="guardian_cnic" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" value="<?php echo e(old('guardian_cnic',isset($app->gaurdians->father_cnic)?$app->gaurdians->father_cnic:'')); ?>" />
        <div class="custom-label"><?php echo e(__('lang.cnic')); ?></div>
        <?php echo $__env->make('inc.form-error',['field'=>'guardian_cnic'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="p_address" placeholder="پتہ" value="<?php echo e(old('p_address',isset($app->gaurdians->address)?$app->gaurdians->address:'')); ?>"  />
        <div class="custom-label"><?php echo e(__('lang.address')); ?></div>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="another_guardian_name" placeholder="Another Guardian Name"  value="<?php echo e(old('another_guardian_name',isset($app->gaurdians->another_guardian_name)?$app->gaurdians->another_guardian_name:'')); ?>"/>
        <div class="custom-label"><?php echo e(__('lang.another_guardian')); ?></div>
        <?php echo $__env->make('inc.form-error',['field'=>'another_guardian_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X"value="<?php echo e(old('mobile_no',isset($app->gaurdians->mobile_no)?$app->gaurdians->mobile_no:'')); ?>" />
      <div class="custom-label"><?php echo e(__('lang.mobile_interagent')); ?></div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <h3 class="f-sub-hd"><?php echo e(__('lang.other_info')); ?></h3>
</div>
</div>
<div class="form-row">
  <div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">1. <?php echo e(__('lang.question_1')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[0]" value="<?php echo e($app->applicant_answers[0]->applicant_answer ?? ""); ?>" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">2. <?php echo e(__('lang.question_2')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name ="question_ans[1]" value="<?php echo e($app->applicant_answers[1]->applicant_answer ?? ""); ?>" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">3. <?php echo e(__('lang.question_3')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[2]" value="<?php echo e($app->applicant_answers[2]->applicant_answer ?? ""); ?>" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">4. <?php echo e(__('lang.question_4')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[3]" value="<?php echo e($app->applicant_answers[3]->applicant_answer ?? ""); ?>" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">5. <?php echo e(__('lang.question_5')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[4]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="<?php echo e($app->applicant_answers[4]->applicant_answer ?? ""); ?>" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">6. <?php echo e(__('lang.question_6')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[5]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="<?php echo e($app->applicant_answers[5]->applicant_answer ?? ""); ?>" />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">7. <?php echo e(__('lang.question_7')); ?></div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[6]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" value="<?php echo e($app->applicant_answers[6]->applicant_answer ?? ""); ?>" />
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <p class="form-content">8. <?php echo e(__('lang.instruction_1')); ?></p>
    <p class="form-content">9. <?php echo e(__('lang.instruction_2')); ?></p>
</div>

</div>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantUpdate', '25')): ?>
<button type="submit" class="btn btn-primary btn-global btn-submit mx-auto d-block"><?php echo e(__('lang.submit')); ?></button>
<?php endif; ?>
</form>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
<script>
    $('.urdu-field').setUrduInput({urduNumerals: true});
    $(':input').inputmask();
    $('.dob').datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: "-100Y",
        maxDate: '-2Y',
        yearRange: "-100:-2"
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/admission/edit-admission-form.blade.php ENDPATH**/ ?>