<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">    
    <div class="inner-head">
        <div class="inner-head">
            <h4><?php echo e(__('lang.role_permissions')); ?></h4>
            
        </div>
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th><?php echo e(__('lang.id')); ?></th>
                                <th><?php echo e(__('lang.role_title')); ?></th>
                                <th><?php echo e(__('lang.permissions_head')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($roles) && count($roles)>0): ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form method="POST" action="<?php echo e(route('admin.roles-permissions.update',['roles_permission'=>'$role->id'])); ?>">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="role_id" value="<?php echo e($role->id); ?>">
                                <tr>
                                    <th><?php echo e($r_key + 1); ?></th>
                                    <td><?php echo e(isset($role->title) ? ucwords($role->title) : ""); ?></td>
                                    <td>
                                        <?php if(isset($permissions) && count($permissions)): ?>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $role_permission = $role->r_permissions()->pluck('permission_id')->toArray();
                                        $checked = '';
                                        if(in_array($permission->id,$role_permission)){
                                            $checked = 'checked';
                                        }
                                        ?>
                                        <label for="permissions-<?php echo e($permission->id); ?><?php echo e($role->id); ?>"><input type="checkbox" <?php echo e($checked); ?> id="permissions-<?php echo e($permission->id); ?><?php echo e($role->id); ?>" name="permissions[]" value="<?php echo e($permission->id); ?>"> <?php echo e($permission->title); ?></label>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php else: ?>
                                          No data available
                                          <?php endif; ?>
                                  
                                          <button class="btn btn-primary" type="submit"><?php echo e(__('lang.update')); ?></button>

                                      </td>
                                  </tr>
                              </form>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                              <tr><?php echo e(__('lang.no_data_found')); ?></tr>
                              <?php endif; ?>
                          </tbody>
                      </table>
                  </div>
              </div>    
          </div>
      </div>
      <?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/role_permissions/index.blade.php ENDPATH**/ ?>