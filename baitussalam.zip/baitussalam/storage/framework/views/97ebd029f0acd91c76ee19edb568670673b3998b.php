<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4><?php echo e(__('lang.result_summary')); ?></h4>
    </div>
    <div class="content-area">
        <div class="npage nquiz-page">
            <div class="container">
                <?php if(isset($data_arr) && count($data_arr) > 0): ?>
                <?php $__currentLoopData = $data_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="question-area">
                    <div class="nquiz_Q">
                        <strong><?php echo e(__('lang.quest_no')); ?> <?php echo e($loop->iteration); ?>:</strong> <?php echo e(isset($da['question']) && !empty($da['question']) ? $da['question'] : ''); ?>

                    </div>
                    <div class="nquiz_A">
                        <div class="nquiz_ya mb-2">
                            <label><?php echo e(__('lang.submit_ans')); ?></label>
                            <?php if($da['is_true']==1): ?>
                            <p class="correct-ans"><?php echo e(isset($da['attempt_answer']) && !empty($da['attempt_answer']) ? $da['attempt_answer'] : ''); ?></p>
                            <?php else: ?>
                            <p class="wrong-ans"><?php echo e(isset($da['attempt_answer']) && !empty($da['attempt_answer']) ? $da['attempt_answer'] : ''); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="nquiz_ca">
                            <label><?php echo e(__('lang.correct_ans')); ?></label>
                            <p><?php echo e(isset($da['correct_answer']) && !empty($da['correct_answer']) ? $da['correct_answer'] : ''); ?></p>
                        </div>
                    </div>
                    <hr />
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/results/results_detail.blade.php ENDPATH**/ ?>