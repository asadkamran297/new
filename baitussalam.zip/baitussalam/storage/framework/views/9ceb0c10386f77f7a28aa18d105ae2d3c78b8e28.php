<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php $__env->startSection('stylesheet'); ?>
    <?php echo $__env->yieldSection(); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Baitussalam')); ?></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" />
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">

</head>
</head>
<body class="bs-body">
    <div id="app" class="h-100">
        <main class="py-4 h-100">
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-area">
                <div class="bg-light" style="width: calc(100% - 90px);position:fixed;bottom:0;padding:10px;right:0;z-index:2">
                    <div class="btn-group" style="width:max-content;margin-left:auto;display:flex;">
                        <?php $locale = session()->get('locale'); ?>
                        <button type="button" class="btn btn-secondary dropdown-toggle" style="background:transparent;color:#9357b7;border-color:#9357b7" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php switch($locale):
                                case ('en'): ?>
                                 English
                                <?php break; ?>
                                <?php case ('ur'): ?>
                                 Urdu
                                <?php break; ?>
                            <?php endswitch; ?>
                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('lang',['locale'=>'en'])); ?>">English</a>
                            <a class="dropdown-item" href="<?php echo e(route('lang',['locale'=>'ur'])); ?>">Urdu</a>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
        <script src="https://use.fontawesome.com/22e73ae827.js"></script>
        <?php echo $__env->yieldContent('custom-scripts'); ?>
    <?php echo $__env->yieldSection(); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/layouts/app.blade.php ENDPATH**/ ?>