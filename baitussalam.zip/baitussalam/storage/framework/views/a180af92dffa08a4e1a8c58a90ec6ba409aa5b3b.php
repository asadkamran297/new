<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">    
    <div class="inner-head">
        <div class="inner-head">
            <h4><?php echo e(__('lang.users_heading')); ?></h4>
            
        </div>
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th><?php echo e(__('lang.id')); ?></th>
                                <th><?php echo e(__('lang.name')); ?></th>
                                <th><?php echo e(__('lang.email')); ?></th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('userRoleUpdate','32')): ?>
                                <th><?php echo e(__('lang.role_head')); ?></th>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('userStatusUpdate','31')): ?>
                                <th><?php echo e(__('lang.user_status')); ?></th>
                                <?php endif; ?>
                                
                                <th><?php echo e(__('lang.user_created_at')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($users) && count($users)>0): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e(($users->currentpage()-1) * $users->perpage() + $key + 1); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?> </td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('userRoleUpdate','32')): ?>
                                <td>
                                    <select name="role" onChange='update_user_role("<?php echo e($user->id); ?>",this)' class="form-control">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($role->id==$user->role_id): ?> selected <?php endif; ?> value="<?php echo e($role->id); ?>"><?php echo e(isset($role->title) ? ucwords($role->title) : ""); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('userStatusUpdate','31')): ?>
                                <td>
                                    <?php if($user->is_active==1): ?>
                                    <span class="badge badge-success"><?php echo e(__('lang.active')); ?></span>
                                    <?php else: ?> 
                                    <span class="badge badge-danger"><?php echo e(__('lang.deactive')); ?></span>
                                    <?php endif; ?>
                                    <input type="checkbox" onclick='is_active_user("<?php echo e($user->id); ?>",this)' <?php echo e((isset($user->is_active) && $user->is_active == 1 )?'checked':''); ?>>
                                </td>
                                <?php endif; ?>
                                
                                <td><?php echo e(date('d-m-Y', strtotime($user->created_at))); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>No data found</tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo $users->links(); ?>

                </div>
            </div>    
        </div>
    </div>
    <?php $__env->startSection('custom-scripts'); ?>
    <script type="text/javascript">
        function is_active_user(user_id,instance){
            var check_val = $(instance).is(':checked');
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                type: "POST",
                url: '<?php echo e(route("admin.users.update_status")); ?>',
                data: { status :check_val,user_id: user_id }, 
                success: function( msg ) {
                    location.reload();
                }
            }); 
        }
        function update_user_role(user_id,instance){
            $.ajax({
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                type: "POST",
                url: '<?php echo e(route("admin.users.update_role")); ?>',
                data: { role_id :instance.value,user_id: user_id }, 
                success: function( msg ) {
                    console.log(msg)
                    if(msg.status==0){
                        alert(msg.message);
                        location.reload();
                    }
                    if(msg.status==1){
                        alert(msg.message);
                        location.reload();
                    }
                }
            }); 
        }
    </script>
    <?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>         

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/users/index.blade.php ENDPATH**/ ?>