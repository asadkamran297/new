<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head"><h4><?php echo e(__('lang.edit_question')); ?></h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card baitquestion">
                    <div class="card-body">
                    <form method="post" action="<?php echo e(url('admin/update-question')); ?>" autocomplete="off">
                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                        <input type="hidden" name="lang_key" value="<?php echo e($lang_key); ?>">
                           <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-4 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select" name="subject_id">
                                            <option value=""></option>
                                            <?php if(isset($subjects)): ?>
                                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sb->id); ?>"<?php echo e($sb->id == $ques->subjects->id ? 'selected':''); ?>><?php echo e($sb->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?> 
                                        </select>
                                        <?php echo $__env->make('inc.form-error',['field'=>'subject_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="custom-label"><?php echo e(__('lang.subject_name')); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-8 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_content" placeholder="سوال" value="<?php echo e($ques->question_content); ?>" />
                                        <?php echo $__env->make('inc.form-error',['field'=>'question_content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="custom-label"><?php echo e(__('lang.question_inp')); ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php $__currentLoopData = $ques['answers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="ans_id[]" value="<?php echo e($ans->id); ?>">
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <label class="customcbx">
                                            <input class="form-control" name="content_chckbx[<?php echo e($key); ?>]"  type="checkbox" autocomplete="off" <?php echo e($ans->is_true=="1" ? "checked" : ""); ?>>
                                            <?php echo $__env->make('inc.form-error',['field'=>'content_chckbx'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <span class="checkmark"></span>
                                        </label>
                                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="content[]"  placeholder="جواب" value="<?php echo e(old('content',$ans->content)); ?>" autocomplete="off"/>
                                        <?php echo $__env->make('inc.form-error',['field'=>'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="custom-label"><?php echo e(__('lang.ans_inp')); ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-row">
                                <button type="submit" class="btn btn-primary btn-global mx-auto"><?php echo e(__('lang.update_question')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
  $('input[type="checkbox"]').on('change', function() {
   $('input[type="checkbox"]').not(this).prop('checked', false);
});
</script>
<?php $__env->stopSection(); ?> 	
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/question/edit-question.blade.php ENDPATH**/ ?>