<?php $__env->startSection('content'); ?>



<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4><?php echo e(__('lang.admission_heading')); ?></h4>
    </div>
    <div class="container admissionf-page">
        <div class="card">
            <div class="card-body">
                <form class="mt-4" method="post" action="<?php echo e(url('admission-submit-form')); ?>">
                  <input type="text" name="lang_key" hidden>
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.dars_nizami')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.dars_nizami')); ?>">
                                 <?php echo $__env->make('inc.form-error',['field'=>'class_selection'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.matric')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.matric')); ?>">
                                 <?php echo $__env->make('inc.form-error',['field'=>'class_selection'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.qadeem')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.qadeem')); ?>">
                                 <?php echo $__env->make('inc.form-error',['field'=>'class_selection'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="customcbx"><?php echo e(__('lang.jadeed')); ?>

                                <input class="form-control" name="class_selection[]" type="checkbox" value="<?php echo e(__('lang.jadeed')); ?>">
                                 <?php echo $__env->make('inc.form-error',['field'=>'class_selection'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <span class="checkmark"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="نام" />
                                <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.name')); ?></div>
                                <?php echo $__env->make('inc.form-error',['field'=>'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="createp_row">
                                <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="f_name" value="<?php echo e(old('f_name')); ?>" placeholder="والد کا نام" />
                                <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.father_name')); ?></div>
                                <?php echo $__env->make('inc.form-error',['field'=>'f_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                          <div class="createp_row">
                            <input type="text" class="form-control createp_input <?php echo e($lang_field); ?> dob" name="dob" value="<?php echo e(old('dob')); ?>"  placeholder="پیدائش کی تاریخ" autocomplete="off" readonly />
                            <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.dob')); ?></div>
                            <?php echo $__env->make('inc.form-error',['field'=>'dob'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="form-group col-md-4 mx-auto">
                      <div class="createp_row select-row">
                          <select class="form-control createp_select" name="class_id">
                              <option value=""></option>
                              <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($cl->is_active == 1): ?>
                              <option value="<?php echo e($cl->id); ?>"><?php echo e($cl->class_name); ?></option>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                          <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.classes')); ?></div>
                          <?php echo $__env->make('inc.form-error',['field'=>'class_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </div>
                  </div>
                  <div class="form-group col-md-4">
                      <div class="createp_row">
                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="city" value="<?php echo e(old('city')); ?>" placeholder="شہریت" />
                        <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.city')); ?></div>
                        <?php echo $__env->make('inc.form-error',['field'=>'city'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <div class="createp_row">
                      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" type = "number" value="<?php echo e(old('mobile_no')); ?>" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
                      <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.mobile')); ?></div>
                      <?php echo $__env->make('inc.form-error',['field'=>'mobile_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
              </div>
              <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="present_address" value="<?php echo e(old('present_address')); ?>" placeholder="موجودہ پتہ" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.present_address')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'present_address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="permanent_address" value="<?php echo e(old('permanent_address')); ?>" placeholder="مستقل پتہ" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.permanent_address')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'permanent_address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="student_cnic" value="<?php echo e(old('student_cnic')); ?>" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.cnic')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="islamic_education" value="<?php echo e(old('islamic_education')); ?>" placeholder="اسلامی تعلیم" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.islamic_education')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'islamic_education'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="previous_institute" value="<?php echo e(old('previous_institute')); ?>" placeholder="پچھلا اسکول" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.old_school')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'previous_institute'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="previous_institute_left_reason" value="<?php echo e(old('previous_institute_left_reason')); ?>" placeholder="اسکول چھوڑنے کی وج" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.leave_school_reason')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'previous_institute_left_reason'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="form-group col-md-12">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="basic_education" value="<?php echo e(old('basic_education')); ?>" placeholder="اسکول کی تعلیم" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.school_education')); ?></div>
                    <?php echo $__env->make('inc.form-error',['field'=>'basic_education'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="f-sub-hd"><?php echo e(__('lang.guardian_heading')); ?></h3>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-3">
                <div class="createp_row">
                    <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="نام" />
                    <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.name')); ?></div>
                </div>
            </div>
            <div class="form-group col-md-3">
                <div class="createp_row">
                  <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="father_name" value="<?php echo e(old('father_name')); ?>" placeholder="والد کا نام">
                  <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.father_name')); ?></div>
                  <?php echo $__env->make('inc.form-error',['field'=>'father_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
          </div>
          <div class="form-group col-md-3">
            <div class="createp_row">
              <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="city" value="<?php echo e(old('city')); ?>" placeholder="شہریت">
              <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.city')); ?></div>
          </div>
      </div>
      <div class="form-group col-md-3">
        <div class="createp_row">
          <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="applicant_relation" value="<?php echo e(old('applicant_relation')); ?>" placeholder="طالب علم سے رشتہ" />
          <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.relation_with_student')); ?></div>
          <?php echo $__env->make('inc.form-error',['field'=>'applicant_relation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
  </div>
  <div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="occupation" value="<?php echo e(old('occupation')); ?>" placeholder="پیشہ" />
      <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.profession')); ?></div>
      <?php echo $__env->make('inc.form-error',['field'=>'occupation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="position" value="<?php echo e(old('position')); ?>" placeholder="عہدہ / پوسٹ" />
      <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.position')); ?></div>
  </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="contact_no" value="<?php echo e(old('contact_no')); ?>" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
      <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.guardian_mobile')); ?></div>
      <?php echo $__env->make('inc.form-error',['field'=>'contact_no'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" data-inputmask="'mask': '99999-9999999-9'" name="guardian_cnic" value="<?php echo e(old('guardian_cnic')); ?>" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
        <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.cnic')); ?></div>
        <?php echo $__env->make('inc.form-error',['field'=>'guardian_cnic'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="p_address" value="<?php echo e(old('p_address')); ?>" placeholder="پتہ" />
        <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.address')); ?></div>
    </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="another_guardian_name" value="<?php echo e(old('another_guardian_name')); ?>" placeholder="Another Guardian Name" />
        <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.another_guardian')); ?></div>
        <?php echo $__env->make('inc.form-error',['field'=>'another_guardian_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="form-group col-md-4">
    <div class="createp_row">
      <input type="text" data-inputmask="'mask': '0399-99999999'" name="mobile_no" value="<?php echo e(old('mobile_no')); ?>" type = "number" maxlength = "12" class="form-control createp_input" placeholder="XXXXX-XXXXXXX-X" />
      <div class="custom-label"><span class="steric">*</span><?php echo e(__('lang.mobile_interagent')); ?></div>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <h3 class="f-sub-hd"><?php echo e(__('lang.other_info')); ?></h3>
</div>
</div>
<div class="form-row">
  <div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">1. <?php echo e(__('lang.question_1')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[0]" required />
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">2. <?php echo e(__('lang.question_2')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name ="question_ans[1]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">3. <?php echo e(__('lang.question_3')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[2]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">4. <?php echo e(__('lang.question_4')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[3]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">5. <?php echo e(__('lang.question_5')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[4]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">6. <?php echo e(__('lang.question_6')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[5]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur"required/>
  </div>
</div>
<div class="form-group col-md-12">
    <div class="createp_row">
      <div class="large-label">7. <?php echo e(__('lang.question_7')); ?> </div>
      <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" name="question_ans[6]" placeholder="Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur" required/>
  </div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <p class="form-content">8. <?php echo e(__('lang.instruction_1')); ?></p>
    <p class="form-content">9. <?php echo e(__('lang.instruction_2')); ?></p>
</div>

</div>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applicantStore', '24')): ?>
<button type="submit" class="btn btn-primary btn-global btn-submit mx-auto d-block"><?php echo e(__('lang.submit')); ?></button>
<?php endif; ?>
</form>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>	
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
<script>
    $('.urdu-field').setUrduInput({urduNumerals: true});
    $(':input').inputmask();
    $('.dob').datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: "-100Y",
        maxDate: '-2Y',
        yearRange: "-100:-2"
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/admission/form.blade.php ENDPATH**/ ?>