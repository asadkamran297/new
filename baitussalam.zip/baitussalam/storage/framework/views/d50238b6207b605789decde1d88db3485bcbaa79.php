<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head"><h4><?php echo e(__('lang.edit_subject')); ?></h4></div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('subject.update',$subjects->id)); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-row">
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row">
                                        <input type="text" class="form-control createp_input <?php echo e($lang_field); ?>" value="<?php echo e($subjects->title); ?>" name="title" placeholder="عنوان" />
                                        <?php echo $__env->make('inc.form-error',['field'=>'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="custom-label"><?php echo e(__('lang.subject_name')); ?></div>
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mx-auto">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select" name="class_id">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cl->id); ?>"<?php echo e($cl->id == $subjects->classes->id ? 'selected':''); ?>><?php echo e($cl->class_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </select>
                                        <?php echo $__env->make('inc.form-error',['field'=>'class_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="custom-label"><?php echo e(__('lang.class_name')); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subjectUpdate', '11')): ?>
                                <button type="submit" class="btn btn-primary btn-global mx-auto"><?php echo e(__('lang.update_subject')); ?></button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/subject/update-subject.blade.php ENDPATH**/ ?>