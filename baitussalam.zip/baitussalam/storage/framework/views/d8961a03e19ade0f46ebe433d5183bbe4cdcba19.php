<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head">
        <h4><?php echo e(__('lang.result_list')); ?></h4>  
    </div>
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th><?php echo e(__('lang.student_name')); ?></th>
                                <th><?php echo e(__('lang.result_status')); ?></th>
                                <th><?php echo e(__('lang.quest_num_of_que')); ?></th>
                                <th><?php echo e(__('lang.actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($data_arr) && count($data_arr) > 0): ?>
                            <?php $__currentLoopData = $data_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e(isset($da['name']) ? $da['name'] : '---'); ?></th>
                                <td><?php echo e(isset($da['num_of_correct']) && $da['num_of_correct'] ? $da['num_of_correct'] : 0); ?></td>
                                <td><?php echo e(isset($da['total_attempts']) && isset($da['total_attempts']) ? $da['total_attempts'] . '/' . $da['total_attempts'] : '---'); ?></td>
                                <td>
                                    <a class="btn btn-primary btn-global-icon-outline" href="<?php echo e(url('/admin/results-detail/'.$da['entry_test_id'].'/'.$da['user_id'])); ?>" title=""><i class="fa fa-pencil"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.re_attempt',['entry_test_id'=>$da['entry_test_id']])); ?>" class="btn btn-primary"><i class="">Allow Re-attempt quiz</i></a>
                                    <a href="<?php echo e(route('admin.quiz_history',['user_id'=>$da['user_id']])); ?>" class="btn btn-primary"><i class="fa fa-eye">View quiz history</i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/results/results_listing.blade.php ENDPATH**/ ?>