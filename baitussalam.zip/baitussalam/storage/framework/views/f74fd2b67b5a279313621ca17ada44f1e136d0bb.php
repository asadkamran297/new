<?php $__env->startSection('stylesheet'); ?>
##parent-placeholder-220d19d1bc706bb369de96ef5d33b4398c5314ef##
<style>
  input,select{font-size:100%}
  h1{font-size:3rem}
  input{font-family:'Cutive Mono',monospace;border:0;border-radius:3px}
  input:focus{outline:0}
  input::-webkit-outer-spin-button,input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
  input[type=number]{-moz-appearance:textfield}
  button{font-family:'Cutive Mono',monospace;color:#FFF;background:#8143a6;border:1px solid #FFF;border-radius:3px;width:90%;padding:10px;margin-left:10px}
  button:focus{outline:0}
  .timer{display:inline-flex;flex-direction:row;align-items:center;height:100%}
  .inputs{display:flex;flex-direction:row;justify-content:space-between}
  @media(max-width:768px){.inputs{display:flex;flex-direction:column;align-items:center}
  }.start-time{width:100%;padding:6px;margin:5px}
  @media(max-width:768px){.start-time{width:300px}
  }.digits{display:flex;flex-direction:row}
  .digits span{font-size:36px}
  #progress{width:100%}
  #bar{width:0;height:5px;background-color:#8143a6;text-align:end;line-height:5px;color:#FFF;transition:0.6s all linear}
  #reset-btn{display:none}


  /* Start Quiz Page Starts */
  .quiz-wrap{
    width: 100%;
    height: auto;
    position: relative;
    background: #fff;
    border-radius: 20px;
    padding: 30px 50px;  
}
.quiz-wrap img{
    max-height: 200px;
    margin: 10px 0 20px;
}
.quiz-wrap .quiz-info{
    margin: 20px 0 40px;
    font-size:14px;
    color:#666;
}
.quiz-wrap .quiz-info b{
    color: #333;
}
/* Start Quiz Page Ends */

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
    <div class="inner-head"></div>
    <div class="content-area">
        <div class="npage nquiz-page">
            <div class="container">
                <div class="quiz-wrap">
                    <div class="row">
                        <div class="col-md-12 mx-auto px-0">
                            <img src="<?php echo e(asset('img/start-quiz.svg')); ?>" alt="" srcset="">
                        </div>
                        <?php if(isset($is_allowed) && $is_allowed==1): ?>
                        <?php if(isset($classes) && $classes->is_active==1): ?>
                        <div class="col-md-12 mx-auto px-0 text-center">
                            <form action="<?php echo e(url('/add-quiz')); ?>" method="post" class="mt-5 mx-auto" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <div class="form-group col-md-4 pl-0 d-inline-block">
                                    <div class="createp_row select-row">
                                        <select class="form-control createp_select " name="class" required>
                                            <option value="" selected>---</option>
                                            <?php if(isset($classes) && isset($classes->id) && !is_null($classes)): ?>
                                            <option value="<?php echo e($classes->id); ?>" selected=""><?php echo e($classes->class_name); ?></option>
                                            <?php endif; ?>
                                        </select>
                                        <div class="custom-label"><?php echo e(__('lang.classes')); ?></div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-global" style="height: 45px"><?php echo e(__('lang.start_quiz')); ?></button>
                            </form>
                        </div>
                        <?php else: ?>
                        <label class="badge badge-danger">You class is disabled by admin contact with admin</label>
                        <?php endif; ?>
                        <?php else: ?>
                        <label class="badge badge-danger">You are not allowed to attempt quiz contact with admin</label>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<script src="<?php echo e(asset('js/yauk.min.js')); ?>"></script>
<script>
  $('.urdu-field').setUrduInput({urduNumerals: true});
</script>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/quiz/quiz.blade.php ENDPATH**/ ?>