<?php $__env->startSection('content'); ?>
<div class="enpage <?php echo e($lang_value); ?>">
  <div class="inner-head">
    <h4><?php echo e(__('lang.class_data')); ?></h4>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classCreate', '2')): ?>
    <a class="btn btn-primary btn-global" href="<?php echo e(route('class.create')); ?>"><?php echo e(__('lang.add_class')); ?></a>
    <?php endif; ?>
</div>
<div class="container-fluid">
    <div class="card mb-3"> 
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-striped mb-0" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th><?php echo e(__('lang.id')); ?></th>
                            <th><?php echo e(__('lang.class_name')); ?></th>
                            <th><?php echo e(__('lang.minimum_age_limit')); ?></th>
                            <th><?php echo e(__('lang.maximum_age_limit')); ?></th>
                            <th><?php echo e(__('lang.quiz_time')); ?></th>
                            <th>Quiz Questions</th>
                            <th><?php echo e(__('lang.user_status')); ?></th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classEdit', '3')): ?>
                            <th><?php echo e(__('lang.edit')); ?></th>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classDelete','6')): ?>
                            <th><?php echo e(__('lang.delete')); ?></th>
                            <?php endif; ?>
                            <th><?php echo e(__('lang.date')); ?></th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $consumerdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($row->id); ?></th>
                            <td><?php echo e($row->class_name); ?></td>
                            <td><?php echo e($row->minimum_age_limit); ?></td>
                            <td><?php echo e($row->maximum_age_limit); ?></td>
                            <td><?php echo e($row->quiz_time); ?></td>
                            <td><?php echo e($row->question_limit); ?></td>
                            <td>
                                <?php if($row->is_active==1): ?>
                                <span class="badge badge-success"><?php echo e(__('lang.active')); ?></span>
                                <?php else: ?> 
                                <span class="badge badge-danger"><?php echo e(__('lang.deactive')); ?></span>
                                <?php endif; ?>
                                <input type="checkbox" onclick='is_active_class("<?php echo e($row->id); ?>",this)' <?php echo e((isset($row->is_active) && $row->is_active == 1 )?'checked':''); ?>>
                            </td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classEdit', '3')): ?>
                            <td><a class="btn btn-primary btn-global-icon-outline" href="<?php echo e(route('class.edit',$row->id)); ?>" title="<?php echo e(__('lang.edit')); ?>"><i class="fa fa-pencil"></i></a> </td>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('classDelete', '6')): ?>
                            <td>
                                <a href="">
                                    <form action="<?php echo e(route('class.destroy',$row->id)); ?>" method="post"><?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="submit" class="btn btn-danger btn-global-table" onclick="return confirm('Are you sure you want to delete?')" name="submit" value="<?php echo e(__('lang.delete')); ?>">
                                        <i class="fa fa-trash-alt"></i>                   
                                    </form>
                                </a>
                            </td>
                            <?php endif; ?>
                            
                            <td><?php echo e(date('d-m-Y',strtotime($row->created_at))); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-scripts'); ?>
<script type="text/javascript">
    function is_active_class(class_id,instance){
        var check_val = $(instance).is(':checked');
        $.ajax({
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            type: "POST",
            url: '<?php echo e(route("class.update_class")); ?>',
            data: { status :check_val,class_id: class_id }, 
            success: function( msg ) {
                if(msg.status==0 || msg.status==1){
                    alert(msg.message);
                    location.reload();
                }
            }
        }); 
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/baitussalam/resources/views/admin/class/classes.blade.php ENDPATH**/ ?>